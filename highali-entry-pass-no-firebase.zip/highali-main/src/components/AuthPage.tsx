/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo, useState } from 'react';
import {
  Atom,
  Hexagon,
  IdCard,
  Fingerprint,
  Hash,
  Lock,
  Globe,
  ChevronDown,
  Check,
  AlertTriangle
} from 'lucide-react';
import { motion } from 'motion/react';
import { LanguageType } from '../locales';
import { authWithNameAndPin } from '../lib/firestoreApi';

interface AuthPageProps {
  onLoginSuccess: (user: any) => void;
  lang: LanguageType;
  setLang: (lang: LanguageType) => void;
  t: any;
}

// Deterministic 6-character badge code derived from the typed name, purely
// cosmetic (reinforces the "you are being issued a personal pass" idea).
function badgeCode(name: string): string {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = (hash * 31 + name.charCodeAt(i)) >>> 0;
  }
  return hash.toString(16).toUpperCase().padStart(6, '0').slice(0, 6);
}

export default function AuthPage({ onLoginSuccess, lang, setLang, t }: AuthPageProps) {
  const [isLangDropdownOpen, setIsLangDropdownOpen] = useState(false);

  // Username + PIN entry: no email, no password, no Google.
  const [fullName, setFullName] = useState('');
  const [pin, setPin] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const languages: { code: LanguageType; name: string }[] = [
    { code: 'ar', name: 'العربية' },
    { code: 'en', name: 'English' },
    { code: 'de', name: 'Deutsch' },
    { code: 'es', name: 'Español' }
  ];

  // Must be a full English name made of 4+ parts (e.g. "Ali Ahmed Kadhim Al-Basri")
  // so that two different students essentially never collide on the same identifier.
  const namePattern = /^[A-Za-z]+(?:['-][A-Za-z]+)*(?:\s[A-Za-z]+(?:['-][A-Za-z]+)*){3,}$/;

  const trimmedPreview = fullName.trim().replace(/\s+/g, ' ');
  const isNameValid = namePattern.test(trimmedPreview);
  const code = useMemo(() => (trimmedPreview ? badgeCode(trimmedPreview.toLowerCase()) : '------'), [trimmedPreview]);

  const handleEntrySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const trimmed = fullName.trim().replace(/\s+/g, ' ');
    if (!trimmed) {
      setErrorMsg(lang === 'ar' ? 'الرجاء إدخال اسمك الرباعي الكامل' : 'Please enter your full name.');
      return;
    }
    if (!namePattern.test(trimmed)) {
      setErrorMsg(
        lang === 'ar'
          ? 'يجب إدخال الاسم الرباعي الكامل بأحرف إنكليزية فقط (مثال: Ali Ahmed Kadhim Al-Basri)، بدون أرقام أو رموز أو حروف عربية.'
          : 'Please enter your full 4-part name using English letters only (e.g. Ali Ahmed Kadhim Al-Basri).'
      );
      return;
    }
    if (!/^\d{4}$/.test(pin)) {
      setErrorMsg(
        lang === 'ar'
          ? 'يجب إدخال رمز مكوّن من 4 أرقام بالضبط.'
          : 'Please enter a 4-digit PIN.'
      );
      return;
    }

    setIsLoading(true);
    try {
      // No Firebase, no Express server — a single Netlify Function backed by
      // Netlify Blobs handles registration/login and logs every entry.
      const slug = trimmed.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'user';
      const user = await authWithNameAndPin(trimmed, pin);
      onLoginSuccess({ id: user.id, email: `${slug}@highali.local`, ...user });
    } catch (err: any) {
      if (err?.message === 'wrong_pin') {
        setErrorMsg(
          lang === 'ar'
            ? 'هذا الاسم مسجل مسبقاً والرمز الذي أدخلته غير صحيح.'
            : 'This name is already registered and the PIN is incorrect.'
        );
      } else {
        setErrorMsg(
          lang === 'ar'
            ? `تعذّر الاتصال بخدمة تسجيل الدخول: ${err.message || 'خطأ غير معروف'}`
            : `Login service error: ${err.message || 'unknown error'}`
        );
      }
    } finally {
      setIsLoading(false);
    }
  };

  const isRtl = t.dir === 'rtl';

  return (
    <div
      className="min-h-screen relative overflow-hidden font-sans flex items-center justify-center px-4 py-10 md:py-16"
      dir={t.dir}
      style={{ background: 'radial-gradient(120% 140% at 15% -10%, #123F3A 0%, #0A1F1D 45%, #071614 100%)' }}
    >
      {/* Engineering blueprint grid backdrop */}
      <svg className="absolute inset-0 w-full h-full opacity-[0.07]" aria-hidden="true">
        <defs>
          <pattern id="blueprintGrid" width="42" height="42" patternUnits="userSpaceOnUse">
            <path d="M 42 0 L 0 0 0 42" fill="none" stroke="#7FD9C9" strokeWidth="0.6" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#blueprintGrid)" />
      </svg>

      {/* Refinery skyline silhouette + flare */}
      <svg
        className="absolute bottom-0 left-0 w-full h-32 md:h-44 opacity-[0.16]"
        viewBox="0 0 1200 200"
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <rect x="40" y="90" width="30" height="110" fill="#7FD9C9" />
        <rect x="90" y="60" width="18" height="140" fill="#7FD9C9" />
        <rect x="150" y="110" width="46" height="90" fill="#7FD9C9" />
        <circle cx="173" cy="100" r="16" fill="#7FD9C9" />
        <rect x="240" y="40" width="14" height="160" fill="#7FD9C9" />
        <rect x="900" y="70" width="20" height="130" fill="#7FD9C9" />
        <rect x="960" y="100" width="40" height="100" fill="#7FD9C9" />
        <circle cx="980" cy="90" r="14" fill="#7FD9C9" />
        <rect x="1040" y="50" width="14" height="150" fill="#7FD9C9" />
      </svg>
      <div
        className="auth-flare-glow absolute bottom-24 md:bottom-36 rounded-full blur-2xl pointer-events-none"
        style={{
          [isRtl ? 'right' : 'left']: '18%',
          width: '90px',
          height: '90px',
          background: 'radial-gradient(circle, rgba(224,164,88,0.9) 0%, rgba(224,164,88,0) 70%)'
        } as React.CSSProperties}
        aria-hidden="true"
      />

      {/* Floating Language Switcher */}
      <div className={`absolute top-5 ${isRtl ? 'left-5' : 'right-5'} z-40`}>
        <div className="relative">
          <button
            onClick={() => setIsLangDropdownOpen(!isLangDropdownOpen)}
            className="rounded-full bg-white/[0.06] border border-white/15 backdrop-blur-md hover:bg-white/[0.1] px-3.5 py-2 text-xs font-semibold text-teal-50 flex items-center gap-2 transition cursor-pointer"
          >
            <Globe className="h-3.5 w-3.5 text-[#E0A458]" />
            <span>{languages.find(l => l.code === lang)?.name}</span>
            <ChevronDown className="h-3.5 w-3.5 text-teal-200/70" />
          </button>

          {isLangDropdownOpen && (
            <div className={`absolute ${isRtl ? 'left-0' : 'right-0'} mt-1.5 rounded-xl bg-[#0F2A27] border border-white/10 shadow-2xl py-1 z-50 w-36 overflow-hidden`}>
              {languages.map((l) => (
                <button
                  key={l.code}
                  onClick={() => {
                    setLang(l.code);
                    setIsLangDropdownOpen(false);
                  }}
                  className={`w-full text-right px-4 py-2.5 text-xs font-semibold flex items-center justify-between transition cursor-pointer ${
                    lang === l.code
                      ? 'bg-white/10 text-[#E0A458]'
                      : 'text-teal-100/80 hover:bg-white/5'
                  }`}
                >
                  <span>{l.name}</span>
                  {lang === l.code && <Check className="h-3.5 w-3.5" />}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Content: brand story + entry pass */}
      <div className="relative z-10 w-full max-w-5xl grid md:grid-cols-2 gap-10 md:gap-16 items-center">

        {/* Brand story */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="text-center md:text-right space-y-6 px-2"
        >
          <div className="inline-flex items-center gap-2.5 justify-center md:justify-start">
            <span className="relative flex items-center justify-center h-11 w-11 rounded-full border border-[#E0A458]/40 bg-white/[0.04]">
              <Hexagon className="h-6 w-6 text-[#E0A458]" strokeWidth={1.4} />
              <Atom className="h-3.5 w-3.5 text-teal-200 absolute" strokeWidth={1.6} />
            </span>
            <span className="font-extrabold text-xs md:text-sm tracking-tight uppercase text-teal-50">
              {t.appName}
            </span>
          </div>

          <h1 className="text-3xl md:text-[2.75rem] font-black leading-[1.15] text-white">
            {t.home.title}
          </h1>
          <p className="text-sm text-teal-100/70 font-light leading-relaxed max-w-md mx-auto md:mx-0">
            {t.home.subtitle}
          </p>

          <div className="hidden md:flex items-center gap-2 text-[11px] text-teal-200/50 font-mono pt-6 border-t border-white/10 max-w-md">
            <span>ENG. ALI SAIF ALDIN HAIDER — AL-NAWFAL © 2026</span>
            <span className="mx-1">·</span>
            <span>BASRA, IRAQ</span>
          </div>
        </motion.div>

        {/* Entry Pass Card */}
        <motion.div
          initial={{ opacity: 0, y: 18, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.6, ease: 'easeOut', delay: 0.1 }}
          className="relative mx-auto w-full max-w-sm"
        >
          {/* Perforation notches along the top edge */}
          <div className="absolute -top-[7px] left-0 right-0 flex justify-between px-6 z-20 pointer-events-none">
            {Array.from({ length: 11 }).map((_, i) => (
              <span
                key={i}
                className="h-3.5 w-3.5 rounded-full"
                style={{ background: '#0A1F1D' }}
              />
            ))}
          </div>

          <div className="rounded-[26px] bg-[#F4F6F4] shadow-[0_30px_60px_-15px_rgba(0,0,0,0.55)] border border-black/5 overflow-hidden">
            {/* Badge header strip */}
            <div className="px-7 pt-7 pb-5 bg-gradient-to-l from-[#123F3A] to-[#0A1F1D] text-teal-50">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono tracking-[0.25em] uppercase text-teal-200/70">
                  {lang === 'ar' ? 'بطاقة دخول رقمية' : 'Digital Entry Pass'}
                </span>
                <IdCard className="h-4 w-4 text-[#E0A458]" />
              </div>
              <div className="mt-3 min-h-[28px]">
                <span className="text-[10px] font-mono text-teal-300/60 block mb-0.5">
                  {lang === 'ar' ? 'صادرة باسم:' : 'ISSUED TO'}
                </span>
                <span
                  dir="ltr"
                  className={`block text-lg font-black tracking-tight truncate ${
                    trimmedPreview ? 'text-white' : 'text-teal-300/30'
                  }`}
                >
                  {trimmedPreview || 'YOUR FULL NAME'}
                </span>
              </div>
            </div>

            {/* Dashed tear line */}
            <div className="border-t border-dashed border-black/10 mx-7" />

            {/* Form body */}
            <div className="p-7 space-y-5">
              <p className="text-xs text-slate-500 leading-relaxed">
                {lang === 'ar'
                  ? 'أدخل اسمك الرباعي الكامل بأحرف إنكليزية ورمز 4 أرقام تختاره بنفسك لتصدر بطاقتك مباشرة، بدون بريد إلكتروني أو كلمة مرور أو حساب Google.'
                  : 'Enter your full 4-part name in English and a 4-digit PIN you choose — your pass is issued instantly. No email, password, or Google account needed.'}
              </p>

              {errorMsg && (
                <motion.div
                  initial={{ scale: 0.95 }}
                  animate={{ scale: 1 }}
                  className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs font-bold flex items-start gap-2"
                >
                  <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                  <span>{errorMsg}</span>
                </motion.div>
              )}

              <form onSubmit={handleEntrySubmit} className="space-y-4 text-right">
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-500 flex items-center gap-1.5">
                    <Fingerprint className="h-3.5 w-3.5 text-[#B9793A]" />
                    {lang === 'ar' ? 'الاسم الرباعي الكامل (بالإنكليزية)' : 'Full name (4 parts, English)'}
                  </label>
                  <input
                    type="text"
                    required
                    autoFocus
                    dir="ltr"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Ali Ahmed Kadhim Al-Basri"
                    className="w-full rounded-xl border border-slate-200 bg-white py-3 px-4 text-xs outline-none focus:border-[#E0A458] focus:ring-2 focus:ring-[#E0A458]/20 text-left font-mono text-slate-800 transition"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-500 flex items-center gap-1.5">
                    <Lock className="h-3.5 w-3.5 text-[#B9793A]" />
                    {lang === 'ar' ? 'رمز مكوّن من 4 أرقام (اختره أنت)' : '4-digit PIN (you choose it)'}
                  </label>
                  <input
                    type="password"
                    inputMode="numeric"
                    required
                    maxLength={4}
                    dir="ltr"
                    value={pin}
                    onChange={(e) => setPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                    placeholder="••••"
                    className="w-full rounded-xl border border-slate-200 bg-white py-3 px-4 text-sm outline-none focus:border-[#E0A458] focus:ring-2 focus:ring-[#E0A458]/20 text-left tracking-[0.5em] font-mono text-slate-800 transition"
                  />
                  <p className="text-[10px] text-slate-400 pt-0.5">
                    {lang === 'ar'
                      ? 'أول مرة تدخل فيها هذا الاسم، الرمز ينحفظ لك تلقائياً. استخدمه نفسه في كل مرة للرجوع لحسابك.'
                      : 'The first time you use this name, the PIN is saved for you. Use it again next time to get back in.'}
                  </p>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full rounded-xl bg-[#0A1F1D] hover:bg-[#123F3A] disabled:bg-slate-300 py-3.5 text-xs font-bold text-white shadow-lg transition cursor-pointer flex items-center justify-center gap-2"
                >
                  {isLoading ? (
                    t.auth.loading
                  ) : (
                    <>
                      <span>{lang === 'ar' ? 'إصدار البطاقة والدخول' : 'Issue My Pass & Enter'}</span>
                      <span className="text-[#E0A458]">→</span>
                    </>
                  )}
                </button>
              </form>
            </div>

            {/* Barcode-style footer */}
            <div className="px-7 pb-6 flex items-center justify-between border-t border-black/5 pt-4">
              <div className="flex items-center gap-1 opacity-70" aria-hidden="true">
                {Array.from({ length: 24 }).map((_, i) => (
                  <span
                    key={i}
                    style={{ width: (i % 5 === 0) ? '2.5px' : '1px', height: '16px', background: '#0A1F1D' }}
                  />
                ))}
              </div>
              <span className="flex items-center gap-1 text-[11px] font-mono text-slate-400">
                <Hash className="h-3 w-3" />
                {isNameValid ? code : '------'}
              </span>
            </div>
          </div>

          <p className="text-center text-[10px] text-teal-200/40 font-light mt-5">
            {t.auth.agreeDetails}
          </p>
        </motion.div>
      </div>
    </div>
  );
}
