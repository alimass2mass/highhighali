import React, { useState, useEffect } from 'react';
import { Shield, Smartphone, Key, Lock, CheckCircle2, AlertTriangle, RefreshCw, QrCode } from 'lucide-react';
import { User } from '../types';
import { motion } from 'motion/react';
import { generateBase32Secret, buildTotpUri, verifyTotpCode } from '../lib/totp';
import { getGeminiKey, setGeminiKey, hasGeminiKey } from '../lib/gemini';
import { logAudit, updateUserFields } from '../lib/firestoreApi';
import { triggerToast } from './ToastContainer';
import QRCode from 'qrcode';

interface SecuritySettingsProps {
  currentUser: User | null;
  onUpdateCurrentUser: (user: User) => void;
  lang: 'ar' | 'en' | 'de' | 'es';
}

export default function SecuritySettingsSection({
  currentUser,
  onUpdateCurrentUser,
  lang
}: SecuritySettingsProps) {
  const isRtl = lang === 'ar';
  const [loading, setLoading] = useState(false);
  const [setupStep, setSetupStep] = useState<'idle' | 'showing_qr'>('idle');
  
  // Setup workflow data
  const [tempSecret, setTempSecret] = useState('');
  const [tempQrCode, setTempQrCode] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Teardown settings
  const [disableCode, setDisableCode] = useState('');
  const [disableError, setDisableError] = useState('');

  if (!currentUser) return null;

  // Initialize Setup — generate a real RFC 6238 TOTP secret entirely in the browser
  const handleStartSetup = async () => {
    setLoading(true);
    setErrorMessage('');
    try {
      const secret = generateBase32Secret();
      const uri = buildTotpUri(secret, currentUser.name);
      const qrCodeUrl = await QRCode.toDataURL(uri);
      setTempSecret(secret);
      setTempQrCode(qrCodeUrl);
      setSetupStep('showing_qr');
    } catch (err) {
      setErrorMessage('فشلت عملية إنشاء مفتاح الدوران الآمن.');
    } finally {
      setLoading(false);
    }
  };

  // Submit confirmation code to secure lock
  const handleVerifyAndEnable = async () => {
    if (!verificationCode || verificationCode.length !== 6) {
      setErrorMessage('يرجى إدخال الرمز المكون من 6 أرقام بشكل كامل.');
      return;
    }
    setLoading(true);
    setErrorMessage('');
    try {
      const isValid = await verifyTotpCode(tempSecret, verificationCode);
      if (!isValid) {
        setErrorMessage('رمز التحقق غير صحيح أو انتهت صلاحيته.');
        return;
      }

      await updateUserFields(currentUser.id, {
        twoFactorEnabled: true,
        twoFactorSecret: tempSecret
      });

      const updatedUser = { ...currentUser, twoFactorEnabled: true, twoFactorSecret: tempSecret };
      localStorage.setItem('gce_basra_user', JSON.stringify(updatedUser));
      onUpdateCurrentUser(updatedUser);
      logAudit('2FA_ENABLED', currentUser.id, currentUser.name, currentUser.email, 'تفعيل درع الأمان الثنائي (TOTP)');

      triggerToast({
        title: "تم تفعيل درع الأمان بنجاح",
        titleEn: "2FA Activated successfully",
        description: "تم قفل حسابك بترميز الأمان الثنائي. سيُطلب منك الرمز في كل عملية تسجيل دخول مستقبلاً.",
        descriptionEn: "Your profile is now locked under two-factor security rules.",
        type: "success"
      });

      // Reset state
      setSetupStep('idle');
      setTempSecret('');
      setTempQrCode('');
      setVerificationCode('');
    } catch (err: any) {
      setErrorMessage(err.message || 'خطأ أثناء المحاولة.');
    } finally {
      setLoading(false);
    }
  };

  // Disable 2FA with current verification challenge
  const handleDisable2Fa = async () => {
    if (!disableCode || disableCode.length !== 6) {
      setDisableError('الرجاء إدخال كود المصادقة المكون من 6 خانات للتعطيل.');
      return;
    }
    if (!currentUser.twoFactorSecret) {
      setDisableError('لا يوجد مفتاح أمان محفوظ لهذا الحساب.');
      return;
    }
    setLoading(true);
    setDisableError('');
    try {
      const isValid = await verifyTotpCode(currentUser.twoFactorSecret, disableCode);
      if (!isValid) {
        setDisableError('فشل التعطيل، كود التحقق غير صحيح.');
        return;
      }

      await updateUserFields(currentUser.id, {
        twoFactorEnabled: false,
        twoFactorSecret: ''
      });

      const updatedUser = { ...currentUser, twoFactorEnabled: false, twoFactorSecret: '' };
      localStorage.setItem('gce_basra_user', JSON.stringify(updatedUser));
      onUpdateCurrentUser(updatedUser);
      logAudit('2FA_DISABLED', currentUser.id, currentUser.name, currentUser.email, 'تعطيل درع الأمان الثنائي (TOTP)');

      triggerToast({
        title: "تم عطل درع الأمان",
        titleEn: "2FA Deactivated",
        description: "تم إضعاف حماية حسابك. لم يعد الحساب محصناً بالتحقق ثنائي الخطوات.",
        descriptionEn: "Two-factor authentication is now turned off.",
        type: "success"
      });
      setDisableCode('');
    } catch (err: any) {
      setDisableError(err.message || 'فشل التعطيل.');
    } finally {
      setLoading(false);
    }
  };

  // Gemini API key (this deployment has no backend, so AI features run
  // directly from the browser using each person's own free key)
  const [geminiKeyInput, setGeminiKeyInput] = useState(getGeminiKey());
  const [geminiKeySaved, setGeminiKeySaved] = useState(hasGeminiKey());
  const handleSaveGeminiKey = () => {
    setGeminiKey(geminiKeyInput);
    setGeminiKeySaved(!!geminiKeyInput.trim());
    triggerToast({
      title: "تم حفظ مفتاح الذكاء الاصطناعي",
      titleEn: "AI key saved",
      description: "تم حفظ مفتاح Gemini في هذا المتصفح فقط، ولن يُشارك مع أي خادم آخر.",
      descriptionEn: "Your Gemini key is stored only in this browser.",
      type: "success"
    });
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto font-sans" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Visual Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-5">
        <div>
          <h2 className="text-xl font-extrabold text-slate-800 dark:text-slate-100 flex items-center gap-2.5">
            <Shield className="h-6 w-6 text-teal-500 animate-pulse" />
            {isRtl ? 'إعدادات درع الأمان والمصادقة (2FA)' : 'Security Shield & Dual Verification (2FA)'}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {isRtl 
              ? 'تأمين الحساب الأكاديمي والمهني للكلية عن طريق ربط الحساب بتطبيق التوثيق Google Authenticator.'
              : 'Safeguard your collegiate account using timed dynamic TOTP locks.'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Core Control card */}
        <div className="lg:col-span-8 space-y-6">
          
          {currentUser.twoFactorEnabled ? (
            /* ACTIVE SECURE STATE */
            <div className="bg-gradient-to-br from-teal-50/50 to-emerald-50/20 dark:from-teal-950/20 dark:to-slate-900 border border-teal-200/60 dark:border-teal-900 rounded-3xl p-6 md:p-8 space-y-6 text-right">
              <div className="flex items-start gap-4">
                <div className="bg-teal-100 dark:bg-teal-900/50 p-3.5 rounded-full text-teal-600 dark:text-teal-300">
                  <CheckCircle2 className="h-7 w-7" />
                </div>
                <div className="space-y-1">
                  <span className="rounded-md bg-teal-600 text-white font-bold text-[9px] px-2 py-0.5 uppercase">
                    {isRtl ? 'نشط ومؤمن جداً' : 'Fully Secured'}
                  </span>
                  <h3 className="text-lg font-bold text-slate-850 dark:text-slate-100">درع الأمان الخاص بك مفعل حالياً</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    حسابك كطالب/مهندس مسجل في الهيئة الكيمياوية بالبصرة يخضع لقواعد الحماية المشددة ومقاومة هجمات brute force.
                  </p>
                </div>
              </div>

              <div className="border-t border-slate-200 dark:border-slate-800 pt-6 space-y-4">
                <div className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-2xl p-4">
                  <p className="text-xs text-red-650 dark:text-red-400 font-bold flex items-center gap-1.5 mb-2">
                    <AlertTriangle className="h-4 w-4 shrink-0" />
                    هل ترغب في تعطيل مصادقة درع الأمان؟
                  </p>
                  <p className="text-[11px] text-slate-500 leading-relaxed mb-4">
                    ملاحظة أمنية: تعطيل درع التحقق سيعرض حسابك لخطر التخمين ومحاولات انتحال الشخصية. في حال المتابعة، يرجى كتابة الرمز الحالي من تطبيق التوثيق:
                  </p>

                  {disableError && (
                    <div className="p-3 mb-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-650 font-bold text-center">
                      {disableError}
                    </div>
                  )}

                  <div className="flex flex-col sm:flex-row gap-3">
                    <input
                      type="text"
                      maxLength={6}
                      value={disableCode}
                      onChange={(e) => setDisableCode(e.target.value.replace(/\D/g, ''))}
                      placeholder="000000"
                      className="flex-1 sm:max-w-[200px] rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3 text-center tracking-widest text-sm font-bold font-mono outline-none focus:bg-white dark:focus:bg-slate-900 focus:border-red-500 text-slate-800 dark:text-slate-100"
                    />
                    <button
                      onClick={handleDisable2Fa}
                      disabled={loading}
                      className="rounded-xl px-5 py-3 bg-red-600 hover:bg-red-700 text-white font-bold text-xs transition cursor-pointer flex items-center justify-center gap-1"
                    >
                      {loading ? 'جاري التعطيل...' : 'إيقاف درع الأمان (تعطيل 2FA)'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* INACTIVE SETUP STATE */
            <div className="border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-3xl p-6 md:p-8 space-y-6">
              
              {setupStep === 'idle' ? (
                // Step 0: Welcome / Setup Intro
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="bg-slate-100 dark:bg-slate-800 p-3 rounded-full text-slate-600 dark:text-slate-300">
                      <Smartphone className="h-6 w-6" />
                    </div>
                    <div className="space-y-1 text-right">
                      <h3 className="text-base font-bold text-slate-850 dark:text-slate-100">خطوات تفعيل طبقة الحماية المزدوجة</h3>
                      <p className="text-xs text-slate-505 dark:text-slate-400 leading-relaxed">
                        تقوم برمجية 2FA بإجبار الحساب على إدخال رمز ديناميكي متغير كل 30 ثانية يتم الحصول عليه من تطبيق خاص بهاتفك، مما يضمن استحالة دخول أي طرف آخر لحسابك حتى لو تسربت كلمة مرورك.
                      </p>
                    </div>
                  </div>

                  {errorMessage && (
                    <div className="p-4 bg-red-50 border border-red-200 text-red-600 rounded-xl text-xs font-bold text-center">
                      {errorMessage}
                    </div>
                  )}

                  <div className="bg-slate-50 dark:bg-slate-950/40 p-5 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 space-y-3 text-right">
                    <h4 className="text-xs font-bold text-teal-600">متطلبات التشغيل الأساسية:</h4>
                    <ul className="text-xs text-slate-500 dark:text-slate-400 space-y-2 list-none pr-0">
                      <li className="flex items-center gap-2">
                        <span className="h-1.5 w-1.5 bg-teal-500 rounded-full shrink-0" />
                        هاتف ذكي يعمل بنظام Android أو iOS.
                      </li>
                      <li className="flex items-center gap-2">
                        <span className="h-1.5 w-1.5 bg-teal-500 rounded-full shrink-0" />
                        تطبيق <strong>Google Authenticator</strong> أو <strong>Microsoft Authenticator</strong> مثبت مسبقاً.
                      </li>
                    </ul>
                  </div>

                  <button
                    onClick={handleStartSetup}
                    disabled={loading}
                    className="w-full text-center py-3.5 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-lg transition duration-200 cursor-pointer flex items-center justify-center gap-2"
                  >
                    {loading ? (
                      <RefreshCw className="h-4 w-4 animate-spin" />
                    ) : (
                      <Lock className="h-4 w-4" />
                    )}
                    بدء عملية توليد وتفعيل درع الأمان (2FA)
                  </button>
                </div>
              ) : (
                // Step 1: Scan QR or copy private Secret code
                <div className="space-y-6">
                  <div className="text-right space-y-2">
                    <span className="text-[10px] font-bold text-teal-600 uppercase">الخطوة الثانية: عملية المسح والمزامنة</span>
                    <h3 className="text-base font-bold text-slate-850 dark:text-slate-100">اربط حسابك بتطبيق التوثيق</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                      افتح تطبيق التوثيق في هاتفك واختر <strong>مسح رمز الاستجابة السريعة (Scan QR Code)</strong>، أو أدخل المفتاح السري المكتوب أدناه يدوياً:
                    </p>
                  </div>

                  <div className="flex flex-col md:flex-row items-center justify-center gap-6 bg-slate-50 dark:bg-slate-950/30 p-6 rounded-2xl border border-slate-200/50 dark:border-slate-800">
                    {tempQrCode ? (
                      <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-inner flex items-center justify-center shrink-0">
                        <img src={tempQrCode} alt="Security 2FA QR Code" className="h-40 w-40 select-none referrer-no-referrer" referrerPolicy="no-referrer" />
                      </div>
                    ) : (
                      <div className="h-40 w-40 bg-slate-200 animate-pulse rounded-xl" />
                    )}

                    <div className="space-y-4 text-right flex-1">
                      <div className="space-y-1.5">
                        <label className="text-[11px] font-bold text-slate-500">المفتاح السري الاحتياطي:</label>
                        <div className="flex items-center gap-2">
                          <code className="bg-white dark:bg-slate-950 p-3 rounded-lg border border-slate-205 dark:border-slate-800 text-center font-mono font-black text-xs block flex-1 break-all select-all tracking-wider text-slate-800 dark:text-slate-200">
                            {tempSecret}
                          </code>
                        </div>
                      </div>

                      <div className="text-[11px] text-gray-500 leading-relaxed space-y-1">
                        <p>💡 <strong>اسم الخدمة بالمنصة:</strong> GCE_Basra_Platform</p>
                        <p>⚠️ <strong>تحذير هام:</strong> لا تشارك هذا الرمز أو الصورة مع أي شخص؛ فهو يمثل المفتاح الأساسي لتوليد رموز الدخول لحسابك.</p>
                      </div>
                    </div>
                  </div>

                  {errorMessage && (
                    <div className="p-3 bg-red-50 border border-red-200 text-red-650 rounded-xl text-xs font-bold text-center">
                      {errorMessage}
                    </div>
                  )}

                  <div className="border-t border-slate-100 dark:border-slate-800 pt-6 space-y-3 text-right">
                    <label className="text-xs font-black text-slate-800 dark:text-slate-200 block mb-1">
                      الخطوة الثالثة: أدخل كود التوثيق ذو الـ 6 أرقام لتأكيد المزامنة:
                    </label>
                    <div className="flex gap-3">
                      <input
                        type="text"
                        maxLength={6}
                        value={verificationCode}
                        onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, ''))}
                        placeholder="000000"
                        className="flex-1 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3 text-center tracking-widest text-lg font-mono font-bold outline-none focus:bg-white dark:focus:bg-slate-900 focus:border-teal-500 text-slate-850 dark:text-slate-100"
                      />
                      <button
                        onClick={handleVerifyAndEnable}
                        disabled={loading}
                        className="rounded-xl px-6 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs transition duration-200 cursor-pointer text-center"
                      >
                        تأكيد وتفعيل درع الأمان الآن 🛡️
                      </button>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setSetupStep('idle');
                      setTempSecret('');
                      setTempQrCode('');
                      setVerificationCode('');
                    }}
                    className="w-full text-center py-2.5 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-550 dark:text-slate-350 font-bold text-xs border border-slate-200 dark:border-slate-800 rounded-xl transition cursor-pointer"
                  >
                    إلغاء والعودة
                  </button>
                </div>
              )}

            </div>
          )}

        </div>

        {/* Security guidelines sidebar */}
        <div className="lg:col-span-4 space-y-6">
          <div className="border border-slate-150 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900 rounded-3xl p-6 text-right space-y-4">
            <h3 className="text-sm font-black text-slate-800 dark:text-slate-100 flex items-center gap-2">
              <Key className="h-4.5 w-4.5 text-teal-500" />
              مفتاح الذكاء الاصطناعي (Gemini)
            </h3>
            <p className="text-[11px] text-slate-550 dark:text-slate-400 leading-relaxed">
              هذا النشر لا يملك خادماً خلفياً، فأدوات الذكاء الاصطناعي (ذاكر، المقابلات، البوت) تعمل مباشرة من متصفحك بمفتاحك الخاص. المفتاح يُخزَّن في هذا المتصفح فقط ولا يُرسل لأي خادم آخر.
            </p>
            <div className="flex gap-2">
              <input
                type="password"
                value={geminiKeyInput}
                onChange={(e) => setGeminiKeyInput(e.target.value)}
                placeholder="AIza..."
                className="flex-1 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 p-2.5 text-xs font-mono outline-none focus:border-teal-500 text-slate-800 dark:text-slate-100"
              />
              <button
                onClick={handleSaveGeminiKey}
                className="rounded-xl px-4 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs transition cursor-pointer"
              >
                حفظ
              </button>
            </div>
            <p className="text-[10px] text-slate-400">
              {geminiKeySaved ? '✅ يوجد مفتاح محفوظ حالياً.' : '⚠️ لا يوجد مفتاح محفوظ بعد.'} احصل على مفتاح مجاني من{' '}
              <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener noreferrer" className="text-teal-600 underline">
                Google AI Studio
              </a>.
            </p>
          </div>

          <div className="border border-slate-150 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900 rounded-3xl p-6 text-right space-y-4">
            <h3 className="text-sm font-black text-slate-800 dark:text-slate-100 flex items-center gap-2">
              <Key className="h-4.5 w-4.5 text-teal-500" />
              إرشادات الأمان الرقمية
            </h3>
            
            <p className="text-[11px] text-slate-550 dark:text-slate-400 leading-relaxed">
              تلتزم الهيئة العامة للتأهيل والتدريب الهندسي بالبصرة بتطبيق أعلى معايير أمن المعلومات والخصوصية لتفادي محاولات التهكير والتزييف وسرقة المناهج العلمية.
            </p>

            <div className="border-t border-slate-200 dark:border-slate-800 pt-4 space-y-3">
              <div className="space-y-1">
                <span className="text-[10px] font-bold text-teal-600 dark:text-teal-400 block">انقضاء الجلسة التلقائي</span>
                <p className="text-[10px] text-slate-500 leading-relaxed">
                  تنتهي جلسة دخولك التفاعلية تلقائياً بعد مرور 30 دقيقة من الخمول التام حماية لبياناتك من المتطفلين.
                </p>
              </div>

              <div className="space-y-1">
                <span className="text-[10px] font-bold text-teal-600 dark:text-teal-400 block">التحقق من البريد الإلكتروني</span>
                <p className="text-[10px] text-slate-500 leading-relaxed">
                  لا يُسمح لأي حساب غير موثق بالبريد بقراءة المصادر المنهجية أو معاينة روابط الكورسات نهائياً لمنع الهجمات المجهولة.
                </p>
              </div>

              <div className="space-y-1">
                <span className="text-[10px] font-bold text-red-500 block">مكافحة ثغرات XSS / CSRF</span>
                <p className="text-[10px] text-slate-500 leading-relaxed">
                  تعتمد المنصة آليات معقمة قوية لتصفية المدخلات والنصوص البرمجية ومكافحة التضمينات الأجنبية تماماً.
                </p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
