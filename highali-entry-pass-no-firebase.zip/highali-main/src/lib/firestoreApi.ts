/**
 * Client for the single Netlify Function backend (netlify/functions/api.mjs).
 * This fully replaces Firebase/Firestore — no external account, no console,
 * no security rules to configure. Data lives in Netlify Blobs, which is
 * built into every Netlify site automatically.
 */
import {
  DigitalPlatform,
  Course,
  EngineeringResource,
  AuthorityAccounts,
  AppNotification,
  NewsActivity,
  NewsComment,
  ActivityPingPayload,
  HeartbeatPayload,
  UserTrackLog
} from '../types';

async function call<T = any>(action: string, payload: any = {}): Promise<T> {
  const res = await fetch('/.netlify/functions/api', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action, payload })
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data?.error === 'wrong_pin' ? 'wrong_pin' : (data?.message || data?.error || `Request failed (${res.status})`));
  }
  return data as T;
}

// ---------------------------------------------------------------------------
// Auth (replaces Firebase Auth entirely — plain name + 4-digit PIN)
// ---------------------------------------------------------------------------
export async function authWithNameAndPin(name: string, pin: string, adminInviteCode?: string) {
  const { user } = await call<{ user: any }>('auth', { name, pin, adminInviteCode });
  return user;
}

export async function changePin(id: string, currentPin: string, newPin: string) {
  await call('change_pin', { id, currentPin, newPin });
}

export async function updateUserFields(id: string, updates: Record<string, any>) {
  const { user } = await call<{ user: any }>('update_user', { id, updates });
  return user;
}

// ---------------------------------------------------------------------------
// Platforms / Courses / Resources
// ---------------------------------------------------------------------------
export const fetchPlatforms = () => call<DigitalPlatform[]>('fetch_platforms');
export const fetchCourses = () => call<Course[]>('fetch_courses');
export const fetchResources = () => call<EngineeringResource[]>('fetch_resources');

export async function fetchAccounts(): Promise<AuthorityAccounts | null> {
  return call<AuthorityAccounts>('fetch_accounts');
}
export async function updateAccounts(acc: AuthorityAccounts) {
  await call('update_accounts', acc);
}

export async function createPlatform(p: { name: string; url: string; image?: string; description?: string }) {
  await call('create_platform', p);
}
export async function updatePlatform(id: string, updated: Partial<DigitalPlatform>) {
  await call('update_platform', { id, updated });
}
export async function deletePlatform(id: string) {
  await call('delete_platform', { id });
}
export async function reorderPlatforms(ids: string[]) {
  await call('reorder_platforms', { ids });
}

export async function createCourse(c: { title: string; url: string; description?: string; instructor?: string }) {
  await call('create_course', c);
}
export async function updateCourse(id: string, updated: Partial<Course>) {
  await call('update_course', { id, updated });
}
export async function deleteCourse(id: string) {
  await call('delete_course', { id });
}
export async function reorderCourses(ids: string[]) {
  await call('reorder_courses', { ids });
}

export async function createResource(r: { title: string; category: string; description: string; url: string; fileName: string; fileSize: number }) {
  await call('create_resource', r);
}
export async function updateResource(id: string, updated: Partial<EngineeringResource>) {
  await call('update_resource', { id, updated });
}
export async function deleteResource(id: string) {
  await call('delete_resource', { id });
}
export async function reorderResources(ids: string[]) {
  await call('reorder_resources', { ids });
}

// ---------------------------------------------------------------------------
// Activity tracking — every entry/action is logged so admin can always see
// how many people are registered and what they've been doing.
// ---------------------------------------------------------------------------
export async function logActivity(currentUserName: string, currentUserEmail: string, role: 'admin' | 'student', payload: ActivityPingPayload) {
  await call('log_activity', { userId: payload.userId, userName: currentUserName, userEmail: currentUserEmail, role, action: payload.action, details: payload.details });
}
export async function logHeartbeat(payload: HeartbeatPayload) {
  await call('log_heartbeat', payload);
}
export async function fetchTrackingLogs(): Promise<UserTrackLog[]> {
  return call<UserTrackLog[]>('fetch_tracking_logs');
}

// ---------------------------------------------------------------------------
// Audit logs — permanent record of every registration / login (who entered
// the platform and when), viewable by admins.
// ---------------------------------------------------------------------------
export async function logAudit(action: string, userId: string, userName: string, userEmail: string, details: string) {
  try {
    await call('log_audit', { userId, userName, userEmail, action, details, userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : '' });
  } catch (err) {
    console.warn('Audit log write failed:', err);
  }
}
export async function fetchAuditLogs(max = 300) {
  return call('fetch_audit_logs', { max });
}
export async function fetchPermanentEntries() {
  return call<{ total: number; entries: any[] }>('fetch_permanent_entries');
}

// ---------------------------------------------------------------------------
// Admin dashboard stats — total registered users, active today/this week,
// registration trend, etc.
// ---------------------------------------------------------------------------
export async function fetchAdminStats() {
  return call('fetch_admin_stats');
}

// ---------------------------------------------------------------------------
// Notifications
// ---------------------------------------------------------------------------
export async function fetchNotifications(): Promise<AppNotification[]> {
  return call<AppNotification[]>('fetch_notifications');
}
export async function createNotification(data: Omit<AppNotification, 'id' | 'createdAt'>) {
  await call('create_notification', data);
}
export async function deleteNotification(id: string) {
  await call('delete_notification', { id });
}
export async function markNotificationRead(id: string, userId: string) {
  await call('mark_notification_read', { id, userId });
}
export async function markAllNotificationsRead(ids: string[], userId: string) {
  await call('mark_all_notifications_read', { ids, userId });
}

// ---------------------------------------------------------------------------
// News + comments
// ---------------------------------------------------------------------------
export async function fetchNews(): Promise<NewsActivity[]> {
  return call<NewsActivity[]>('fetch_news');
}
export async function createNews(data: { title: string; content: string; imageUrl?: string; videoUrl?: string }) {
  await call('create_news', data);
}
export async function deleteNews(id: string) {
  await call('delete_news', { id });
}
export async function addNewsComment(postId: string, comment: { userName: string; userEmail: string; content: string }): Promise<NewsComment> {
  return call<NewsComment>('add_news_comment', { postId, comment });
}
export async function deleteNewsComment(postId: string, commentId: string) {
  await call('delete_news_comment', { postId, commentId });
}
