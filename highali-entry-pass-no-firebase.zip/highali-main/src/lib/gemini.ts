/**
 * Client-side Gemini calls. There is no backend to hold a shared server
 * secret, so each visitor supplies their own free Gemini API key (get one
 * at https://aistudio.google.com/apikey), stored only in their own browser.
 */
import { GoogleGenAI } from '@google/genai';

const STORAGE_KEY = 'gce_basra_gemini_key';
const MODEL = 'gemini-3.5-flash';

export function getGeminiKey(): string {
  try { return localStorage.getItem(STORAGE_KEY) || ''; } catch { return ''; }
}
export function setGeminiKey(key: string) {
  try { localStorage.setItem(STORAGE_KEY, key.trim()); } catch { /* ignore */ }
}
export function hasGeminiKey(): boolean {
  return !!getGeminiKey();
}

class NoApiKeyError extends Error {
  constructor() { super('NO_API_KEY'); }
}

function client(): GoogleGenAI {
  const apiKey = getGeminiKey();
  if (!apiKey) throw new NoApiKeyError();
  return new GoogleGenAI({ apiKey });
}

export async function summarizeText(text: string): Promise<string> {
  const ai = client();
  const systemInstruction = `
    أنت رائد تكنولوجيا ومهندس كيميائي متميز تعمل كخبير محتوى لمنصة "الهيئة العامة للمهندسين الكيميائيين في البصرة".
    مهمتك هي تلخيص النص الهندسي الكيميائي المدخل باللغة العربية بأسلوب علمي رصين ومرتب جداً ومفيد للطلبة.
    قم بتقسيمه إلى:
    1. الخلاصة العامة (بفقرة أو فقرتين).
    2. المصطلحات والرموز الكيميائية الرئيسية المذكورة ومعانيها.
    3. أهم المعادلات والقواعد أو الخطوات الصناعية الموضحة في النص.
    4. استنتاجات هندسية ونصائح للعمليات الكيميائية أو السلامة المهنية.
    إذا كان النص غير مرتبط بالهندسة الكيميائية أو الكيمياء أو العلوم التطبيقية، فقم مع ذلك بتلخيصه بأناقة، لكن ركّز على صياغة المنظور العلمي المناسب.
  `;
  const response = await ai.models.generateContent({
    model: MODEL,
    contents: [{ role: 'user', parts: [{ text: `${systemInstruction}\n\nالنص المطلوب تلخيصه:\n${text}` }] }]
  });
  return response.text || '';
}

export async function interviewReply(topic: string, messages: { role: 'user' | 'assistant'; content: string }[]): Promise<string> {
  const ai = client();
  const formattedHistory = messages.map(m => `${m.role === 'user' ? 'المرشح (الطالب)' : 'المقابل المهندس'}: ${m.content}`).join('\n');
  const prompt = `
    أنت مهندس مقابلات كيميائي رئيسي في لجنة التوظيف في "الهيئة العامة للمهندسين الكيميائيين في البصرة".
    أنت تجري مقابلة عمل تقنية علمية صارمة ولكنها تدريبية وتفاعلية لطالب أو خريج هندسة كيميائية بالبصرة.
    الموضوع المختار للمقابلة: "${topic}".

    تاريخ الحوار الحالي حتى الآن:
    ${formattedHistory}

    المهمة المطلوبة منك:
    1. قم بالرد على إجابة المرشح الأخيرة (إذا وجد حوار سابق). قيّم مهاراته ومستواه بكل احترام ومهنية واذكر الإجابة الصحيحة أو الإضافات العلمية الهامة بلغة عربية سليمة.
    2. اسأل المرشح سؤالاً علمياً كيميائياً واحداً فقط يتعلق بموضوع المقابلة "${topic}"، واجعل السؤال مناسباً لمستوى المقابلات في الشركات العالمية والمحلية بالبصرة مثل شركة غاز البصرة BGC أو شركة مصافي الجنوب أو شركة الاستكشافات النفطية.
    3. اجعل الأسلوب تشجيعياً، تفاعلياً، وبناءً لتعلم الطلبة، واختم الحديث بالسؤال دائماً.
  `;
  const response = await ai.models.generateContent({ model: MODEL, contents: [{ role: 'user', parts: [{ text: prompt }] }] });
  return response.text || '';
}

export async function generateText(prompt: string): Promise<string> {
  const ai = client();
  const response = await ai.models.generateContent({ model: MODEL, contents: [{ role: 'user', parts: [{ text: prompt }] }] });
  return response.text || '';
}

export function isNoApiKeyError(err: any): boolean {
  return err instanceof NoApiKeyError || err?.message === 'NO_API_KEY';
}
