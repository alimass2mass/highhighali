/**
 * Minimal client-side TOTP (RFC 6238) implementation using the browser's
 * Web Crypto API. Works with Google Authenticator / Microsoft Authenticator
 * exactly like a server-generated secret would — no backend required.
 */
const BASE32_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

export function generateBase32Secret(length = 32): string {
  const bytes = new Uint8Array(20);
  crypto.getRandomValues(bytes);
  let bits = '';
  bytes.forEach(b => { bits += b.toString(2).padStart(8, '0'); });
  let secret = '';
  for (let i = 0; i + 5 <= bits.length; i += 5) {
    secret += BASE32_ALPHABET[parseInt(bits.substring(i, i + 5), 2)];
  }
  return secret.slice(0, length);
}

function base32ToBytes(base32: string): Uint8Array {
  const clean = base32.toUpperCase().replace(/[^A-Z2-7]/g, '');
  let bits = '';
  for (const ch of clean) {
    const val = BASE32_ALPHABET.indexOf(ch);
    if (val === -1) continue;
    bits += val.toString(2).padStart(5, '0');
  }
  const bytes = new Uint8Array(Math.floor(bits.length / 8));
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(bits.substring(i * 8, i * 8 + 8), 2);
  }
  return bytes;
}

async function hmacSha1(keyBytes: Uint8Array, msgBytes: Uint8Array): Promise<Uint8Array> {
  const key = await crypto.subtle.importKey('raw', keyBytes as BufferSource, { name: 'HMAC', hash: 'SHA-1' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, msgBytes as BufferSource);
  return new Uint8Array(sig);
}

export async function generateTotpCode(secret: string, timestampMs = Date.now(), timeStepSeconds = 30, digits = 6): Promise<string> {
  const counter = Math.floor(timestampMs / 1000 / timeStepSeconds);
  const counterBytes = new Uint8Array(8);
  let temp = counter;
  for (let i = 7; i >= 0; i--) {
    counterBytes[i] = temp & 0xff;
    temp = Math.floor(temp / 256);
  }
  const hmac = await hmacSha1(base32ToBytes(secret), counterBytes);
  const offset = hmac[hmac.length - 1] & 0x0f;
  const binCode =
    ((hmac[offset] & 0x7f) << 24) |
    ((hmac[offset + 1] & 0xff) << 16) |
    ((hmac[offset + 2] & 0xff) << 8) |
    (hmac[offset + 3] & 0xff);
  return (binCode % 10 ** digits).toString().padStart(digits, '0');
}

// Accepts a code generated up to `window` steps (±30s each) away from now,
// to tolerate small clock drift between the phone and the browser.
export async function verifyTotpCode(secret: string, code: string, window = 1): Promise<boolean> {
  const now = Date.now();
  for (let step = -window; step <= window; step++) {
    const candidate = await generateTotpCode(secret, now + step * 30000);
    if (candidate === code) return true;
  }
  return false;
}

export function buildTotpUri(secret: string, accountName: string, issuer = 'GCE_Basra_Platform'): string {
  return `otpauth://totp/${encodeURIComponent(issuer)}:${encodeURIComponent(accountName)}?secret=${secret}&issuer=${encodeURIComponent(issuer)}&digits=6&period=30`;
}
