/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import crypto from 'crypto';
import qrcode from 'qrcode';
import { initializeApp } from 'firebase/app';
import { getFirestore, doc, getDocs, setDoc, deleteDoc, collection } from 'firebase/firestore';
import admin from 'firebase-admin';

dotenv.config();

// Initialize firebase-admin so we can verify real Google Sign-In tokens
// server-side. Uses Application Default Credentials — this works
// automatically on Google Cloud (Cloud Run/Functions) and elsewhere if
// GOOGLE_APPLICATION_CREDENTIALS points to a service account key file.
let firebaseAdminReady = false;
try {
  if (admin.apps.length === 0) {
    admin.initializeApp();
  }
  firebaseAdminReady = true;
} catch (err) {
  console.warn('firebase-admin could not initialize (no credentials found). Google Sign-In verification will be disabled until GOOGLE_APPLICATION_CREDENTIALS is configured:', err);
}

// Define port and runtime constants
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const DATABASE_FILE = path.join(process.cwd(), 'database.json');
const CONFIG_FILE = path.join(process.cwd(), 'firebase-applet-config.json');

// Initialize Firebase server connection if credentials are configured
let firebaseApp: any = null;
let firebaseDB: any = null;
let isFirebaseServerActive = false;

try {
  if (fs.existsSync(CONFIG_FILE)) {
    const configContent = fs.readFileSync(CONFIG_FILE, 'utf-8');
    const config = JSON.parse(configContent);
    if (config && config.apiKey && !config.apiKey.includes('Dummy')) {
      firebaseApp = initializeApp(config);
      firebaseDB = getFirestore(firebaseApp, config.firestoreDatabaseId || undefined);
      isFirebaseServerActive = true;
      console.log('Firebase Server initialized successfully for durable persistence in the cloud.');
    }
  }
} catch (err) {
  console.warn('Firebase server initialization skipped or deferred:', err);
}

// Initialize Gemini SDK with telemetry header
const geminiApiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey: geminiApiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// Interface for backend stored database
interface DBStructure {
  platforms: any[];
  courses: any[];
  resources: any[];
  accounts: {
    telegram: string;
    instagram: string;
    facebook: string;
    whatsapp: string;
    youtube: string;
    linkedin: string;
    website: string;
    telegramGot: string;
    instagramGot: string;
    telegramTrainee: string;
  };
  news?: any[];
  users: any[];
  trackingLogs: Record<string, any>;
  notifications: any[];
  auditLogs?: any[];
  sessions?: Record<string, { userId: string; createdAt: number; lastSeen: number }>;
}

// Default pre-seeded database
const defaultDB: DBStructure = {
  platforms: [
    {
      id: 'detergents-lab',
      name: 'مختبر انتاج المنظفات',
      url: 'https://ais-pre-oz2lnw2v5izn7sw74dre7l-501029547945.europe-west1.run.app/',
      image: 'https://images.unsplash.com/photo-1607613009820-a29f7bb81c04?w=500&auto=format&fit=crop&q=60',
      description: 'دليل عملي وتفاعلي لشرح كيمياء السطح وتصنيع الصابون السائل والمطهرات والمعقمات التجارية وفق المواصفة العراقية.',
      isSystem: true
    },
    {
      id: 'hplc-sim-lab',
      name: 'مختبر محاكي جهاز HPLC',
      url: 'https://taupe-liger-42ce91.netlify.app/',
      image: 'https://images.unsplash.com/photo-1532187863486-abf9d39d66e8?w=500&auto=format&fit=crop&q=60',
      description: 'تطبيق محاكاة هندسي كيميائي تفاعلي لفهم خطوات تشغيل جهاز الكروماتوغرافيا السائلة عالية الأداء HPLC، برمجة الضخ، وقراءة الكروماتوغرام.',
      isSystem: true
    },
    {
      id: 'cosmetics-lab',
      name: 'مختبر علوم التجميل',
      url: 'https://statuesque-speculoos-eca636.netlify.app/',
      image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=500&auto=format&fit=crop&q=60',
      description: 'دراسة وتطبيق تراكيب المستحلبات، الكريمات المرطبة، السيروم المغذي والمستحضرات التجميلية المتطورة.',
      isSystem: true
    },
    {
      id: 'uv-vis-lab',
      name: 'مختبر جهاز Uv visible',
      url: 'https://magnificent-tarsier-50e394.netlify.app/',
      image: 'https://images.unsplash.com/photo-1576086213369-97a306dca665?w=500&auto=format&fit=crop&q=60',
      description: 'محاكاة وإرشادات لإجراء الفحوصات الطيفية وامتصاص السوائل وقياس متبقيات المواد الكيميائية بدقة.',
      isSystem: true
    },
    {
      id: 'assistant-bot',
      name: 'البوت الرقمي',
      url: 'https://share.google/4NvoZbQlQnklDfQdb',
      image: 'https://images.unsplash.com/photo-1531747118685-ca8fa6e08806?w=500&auto=format&fit=crop&q=60',
      description: 'مساعد ذكي مخصص للإجابة على تساؤلات المهندسين الكيميائيين في البصرة وحل المسائل الهندسية الرياضية.',
      isSystem: true
    },
    {
      id: 'thaker-summarizer',
      name: 'منصة ذاكر الهندسية لتلخيص الملفات',
      url: 'https://spiffy-pie-2f4a6c.netlify.app/',
      image: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=500&auto=format&fit=crop&q=60',
      description: 'نظام مدعوم بالذكاء الاصطناعي لتلخيص الأبحاث الهندية والكتب الكيميائية الضخمة وصياغة ملخصات احترافية.',
      isSystem: true
    },
    {
      id: 'interview-prep',
      name: 'منصة المقابلات الهندسية',
      url: 'embedded',
      image: 'https://images.unsplash.com/photo-1521791136368-1a46827d52bf?w=500&auto=format&fit=crop&q=60',
      description: 'تساعد الطلبة على التحضير لمقابلات العمل في شركات جولات التراخيص والشركات النفطية والإنشائية بالبصرة.',
      isSystem: true
    }
  ],
  courses: [
    {
      id: 'course-1',
      title: 'دورة هندسة الغاز الطبيعي وعمليات تسييل الغاز LNG',
      url: 'https://gce-basra.org/courses/gas-engineering',
      description: 'تغطي الدورة عمليات المعالجة، إزالة الشوائب، وعمليات التجفيف والتبريد في منصات غاز البصرة.',
      instructor: 'أ. د. كريم جابر البصري',
      addedAt: '2026-06-01T10:00:00Z'
    },
    {
      id: 'course-2',
      title: 'تصنيع وتطوير المنظفات الكيميائية والمطهرات المنزلية',
      url: 'https://gce-basra.org/courses/detergent-manufacturing',
      description: 'دورة عملية شاملة لتركيب وتصنيع مختلف أنواع الشامبو والصابون السائل بطرق علمية آمنة.',
      instructor: 'م. علي السعدي',
      addedAt: '2026-06-03T11:30:00Z'
    },
    {
      id: 'course-3',
      title: 'تطبيقات الكروماتوغرافيا السائلة وفحوصات الدواء والمياه',
      url: 'https://gce-basra.org/courses/hplc-analysis',
      description: 'مبادئ التحليل الكروماتوغرافي وطرق معايرة الأجهزة الكيميائية الحساسة.',
      instructor: 'د. ليلى شاكر محمد',
      addedAt: '2026-06-05T09:12:00Z'
    }
  ],
  resources: [
    {
      id: 'resource-1',
      title: 'Perry\'s Chemical Engineers\' Handbook (9th Edition)',
      category: 'كتب ومناهج أساسية',
      description: 'المرجع الأهم والشامل لكافة العمليات الكيميائية وموازين المادة والمصطلحات الأساسية للمهندس.',
      url: 'https://gce-basra.org/storage/perry-handbook-9e.pdf',
      fileName: 'perrys_chemical_handbook_9th.pdf',
      fileSize: 256870912, // ~245 MB
      addedAt: '2026-06-02T14:20:00Z'
    },
    {
      id: 'resource-2',
      title: 'Chemical Engineering Volume 6: Design - Sinnott',
      category: 'تصميم المصانع والمفاعلات',
      description: 'كتاب منهجي لتصميم المبادلات الحرارية، أبراج التقطير والمفاعلات الكيميائية وفق المعايير القياسية.',
      url: 'https://gce-basra.org/storage/chemical-design-v6.pdf',
      fileName: 'chem_engineering_design_sinnott.pdf',
      fileSize: 196083712, // ~187 MB
      addedAt: '2026-06-04T16:30:00Z'
    },
    {
      id: 'resource-3',
      title: 'مذكرة تدريبية: تكرير النفط ووحدات التصفية في مصفى الشعيبة',
      category: 'تقنيات النفط والغاز',
      description: 'كتيب تدريبي مفصل لوحدات التقطير الجوي والخلط الكيميائي والمعالجة في مصافي النفط الجنوبية بفروعها.',
      url: 'https://gce-basra.org/storage/shaiba-refinery-training.pdf',
      fileName: 'shaiba_refinery_training.pdf',
      fileSize: 48580000, // ~46 MB
      addedAt: '2026-06-08T10:00:00Z'
    }
  ],
  accounts: {
    telegram: 'https://t.me/chemicallyengineer',
    instagram: 'https://www.instagram.com/chemical_authority?igsh=MTNxaTI0eGVsajdnaw==',
    facebook: 'https://facebook.com/GeneralChemBAS',
    whatsapp: '',
    youtube: 'https://youtube.com/@GeneralChemBAS',
    linkedin: 'https://www.linkedin.com/in/chemical-engineer-trainee-engineer-241630373?utm_source=share_via&utm_content=profile&utm_medium=member_ios',
    website: 'https://gce-basra.org',
    telegramGot: 'https://t.me/GoT_information',
    instagramGot: 'https://www.instagram.com/chemically_information?igsh=MW55Ynk4MWVzdHd1NQ==',
    telegramTrainee: 'https://t.me/chemicaltrainee'
  },
  news: [],
  users: [
    {
      id: 'u-admin-seeded-1',
      name: 'ENG.ALI SAIF ALDIN',
      email: 'alisaifaldeen12@gmail.com',
      // Placeholder strong password, hashed (salted scrypt) — never store plain text.
      // Change this immediately after first login via account settings.
      // Default (pre-rotation) password: 2vC2J$HRDsK!vML9
      password: '69661d3cba4a5520f9710639f02c55c6:2f134c0dd3ff8ebe3dee40a8f2c9a1205f2b6caeaba6cb288af3f38cc596b46444c3909be7628ee0f185f51b286201aa1a18537e884c1cd628a0394229148fa8',
      role: 'admin',
      emailVerified: true,
      createdAt: '2026-05-15T08:00:00Z'
    },
    {
      id: 'u-admin-seeded-2',
      name: 'Oil Information Admin',
      email: 'oilinformation12333@gmail.com',
      // Default (pre-rotation) password: pE4Zvb%W8z8jCKLP — change on first login.
      password: 'a1c6329e3b837b356aa01716720b1436:95f60e3306997a616949635513080a9b211b91e7b697c8832b8a7b04cc88817b7b386401bf96bdfa11f1a7f134d26b27f284d1f6d59f3a508b37ad8bf6e2559e',
      role: 'admin',
      emailVerified: true,
      createdAt: '2026-05-15T08:00:00Z'
    },
    {
      id: 'u-demo1',
      name: 'أحمد البصري',
      email: 'ahmed@gmail.com',
      // Demo/fixture account — delete before going to production.
      // Default (pre-rotation) password: tYVq337mf45pLkRk
      password: '25402eb95651e7bbe1b7ebe38ec0372d:2617cbc23547bb571e05a8ac26cad00e031dfab787aa150dea23bc85ff13edbdb91c003de191ea4908d977dadd98ecaf82ff971b0e182f433b37fbbf6ea2a0c1',
      role: 'student',
      academicYear: 'المرحلة الرابعة - جامعة البصرة',
      createdAt: '2026-06-01T12:00:00Z'
    },
    {
      id: 'u-demo2',
      name: 'سجاد علي',
      email: 'sajjad@gmail.com',
      password: '25402eb95651e7bbe1b7ebe38ec0372d:2617cbc23547bb571e05a8ac26cad00e031dfab787aa150dea23bc85ff13edbdb91c003de191ea4908d977dadd98ecaf82ff971b0e182f433b37fbbf6ea2a0c1',
      role: 'student',
      academicYear: 'المرحلة الثالثة - كلية الهندسة الكيميائية',
      createdAt: '2026-06-03T15:22:00Z'
    },
    {
      id: 'u-demo3',
      name: 'فاطمة محمد',
      email: 'fatima@gmail.com',
      password: '25402eb95651e7bbe1b7ebe38ec0372d:2617cbc23547bb571e05a8ac26cad00e031dfab787aa150dea23bc85ff13edbdb91c003de191ea4908d977dadd98ecaf82ff971b0e182f433b37fbbf6ea2a0c1',
      role: 'student',
      academicYear: 'خريجة هندسة كيميائية وبتروكيماويات',
      createdAt: '2026-06-05T09:40:00Z'
    }
  ],
  trackingLogs: {
    'u-demo1': {
      userId: 'u-demo1',
      userName: 'أحمد البصري',
      userEmail: 'ahmed@gmail.com',
      role: 'student',
      registrationDate: '2026-06-01T12:00:00Z',
      lastActive: '2026-06-11T11:45:00-07:00',
      dailyUsageCount: 42,
      totalActiveTimeSeconds: 5820, // ~1.6 hours
      platformStays: {
        'detergents-lab': {
          platformId: 'detergents-lab',
          platformName: 'مختبر انتاج المنظفات',
          entriesCount: 8,
          durationSeconds: 1540
        },
        'thaker-summarizer': {
          platformId: 'thaker-summarizer',
          platformName: 'منصة ذاكر الهندسية لتلخيص الملفات',
          entriesCount: 5,
          durationSeconds: 2180
        },
        'interview-prep': {
          platformId: 'interview-prep',
          platformName: 'منصة المقابلات الهندسية',
          entriesCount: 4,
          durationSeconds: 2100
        }
      },
      activityTimeline: [
        { action: 'تسجيل دخول للمرة الأولى', timestamp: '2026-06-01T12:00:00Z', details: 'تأكيد الحساب المدرسي' },
        { action: 'زيارة قسم المصادر الهندسية', timestamp: '2026-06-11T09:15:00-07:00', details: 'تحميل كتاب Perry\'s Handbook' },
        { action: 'الدخول للمنصات الرقمية', timestamp: '2026-06-11T10:10:00-07:00', details: 'مختبر انتاج المنظفات' },
        { action: 'استخدام منصة ذاكر الهندسية', timestamp: '2026-06-11T11:30:00-07:00', details: 'تلخيص تقرير الكيمياء العضوية' }
      ]
    },
    'u-demo2': {
      userId: 'u-demo2',
      userName: 'سجاد علي',
      userEmail: 'sajjad@gmail.com',
      role: 'student',
      registrationDate: '2026-06-03T15:22:00Z',
      lastActive: '2026-06-11T10:20:00-07:00',
      dailyUsageCount: 29,
      totalActiveTimeSeconds: 3120, // ~52 min
      platformStays: {
        'cosmetics-lab': {
          platformId: 'cosmetics-lab',
          platformName: 'مختبر علوم التجميل',
          entriesCount: 4,
          durationSeconds: 1400
        },
        'uv-vis-lab': {
          platformId: 'uv-vis-lab',
          platformName: 'مختبر جهاز Uv visible',
          entriesCount: 3,
          durationSeconds: 1720
        }
      },
      activityTimeline: [
        { action: 'تسجيل دخول للمرة الأولى', timestamp: '2026-06-03T15:22:00Z', details: 'تأكيد حساب سجاد علي' },
        { action: 'تصفح الدورات المتوفرة', timestamp: '2026-06-11T10:05:00-07:00', details: 'الاستعلام عن دورة المنظفات' },
        { action: 'الدخول للجهاز العلمي', timestamp: '2026-06-11T10:12:00-07:00', details: 'مختبر جهاز Uv visible' }
      ]
    },
    'u-demo3': {
      userId: 'u-demo3',
      userName: 'فاطمة محمد',
      userEmail: 'fatima@gmail.com',
      role: 'student',
      registrationDate: '2026-06-05T09:40:00Z',
      lastActive: '2026-06-11T12:10:00-07:00',
      dailyUsageCount: 65,
      totalActiveTimeSeconds: 9420, // ~2.6 hours
      platformStays: {
        'interview-prep': {
          platformId: 'interview-prep',
          platformName: 'منصة المقابلات الهندسية',
          entriesCount: 15,
          durationSeconds: 6120
        },
        'thaker-summarizer': {
          platformId: 'thaker-summarizer',
          platformName: 'منصة ذاكر الهندسية لتلخيص الملفات',
          entriesCount: 8,
          durationSeconds: 3300
        }
      },
      activityTimeline: [
        { action: 'تسجيل دخول للمرة الأولى', timestamp: '2026-06-05T09:40:00Z', details: 'تأكيد الحساب كخريجة' },
        { action: 'محاكاة مقابلة عمل', timestamp: '2026-06-11T11:45:00-07:00', details: 'اختبار مهارات تكرير النفط' },
        { action: 'تلخيص ورقة بحثية', timestamp: '2026-06-11T12:05:00-07:00', details: 'ذاكر لتلخيص بحوث التحلية المائية' }
      ]
    }
  },
  notifications: [
    {
      id: "notif-seeded-1",
      title: "فرصة تدريبية مميزة في حقل غرب القرنة النفطي لعام 2026",
      titleEn: "Exclusive training opportunity in West Qurna oil field",
      description: "تعلن الهيئة الكيميائية للبصرة بالتعاون مع شركة نفط البصرة عن توفير 5 مقاعد تدريبية لحديثي التخرج في معالجة وفصل المركبات الغازية والنفطية والتعرف على هندسة التكرير العملية.",
      descriptionEn: "The Chemical Association of Basra, in coordination with BOC, offers 5 training spots for fresh chemistry grads in petroleum refining operations.",
      type: "course",
      createdAt: "2026-06-10T12:00:00Z"
    },
    {
      id: "notif-seeded-2",
      title: "تم توفير كتاب بيري للهندسة الكيميائية النسخة التاسعة",
      titleEn: "Perry's Chemical Manual (9th Edition) now available",
      description: "تم إضافة رابط تحميل مباشر وعالي السرعة من غوغل درايف لكتاب بيري الكامل (بحجم 400 ميغابايت) للتحميل الفوري وتلافي مشاكل الحجم للمتصفحات.",
      descriptionEn: "We added a high-speed GDrive mirror link for Perry's core handbook inside the resources panel to support fast downloads.",
      type: "resource",
      createdAt: "2026-06-09T15:30:00Z"
    }
  ]
};

// Security Cryptographic and Utility Primitives
//
// Passwords are hashed with a per-password random salt using scrypt (Node's
// built-in KDF). Stored format is "salt:hash" so every password gets a
// unique hash even if two users pick the same password.
function hashPassword(pwd: string, existingSalt?: string): string {
  if (!pwd) return '';
  const salt = existingSalt || crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(pwd, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

function verifyPassword(pwd: string, stored: string): boolean {
  if (!pwd || !stored) return false;
  // Legacy accounts created before the salted-hash upgrade stored a plain
  // sha256 hex digest with no salt. Support verifying those once, then the
  // caller should re-hash and persist the upgraded value.
  if (!stored.includes(':')) {
    return crypto.createHash('sha256').update(pwd).digest('hex') === stored;
  }
  const [salt, hash] = stored.split(':');
  const derived = crypto.scryptSync(pwd, salt, 64).toString('hex');
  // Constant-time comparison to avoid timing attacks.
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(derived, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// In-memory session store: random opaque token -> userId. Tokens are never
// derived from or equal to the user's database ID, so they cannot be guessed
// or forged from public data (unlike the previous "Bearer <user.id>" scheme).
// Sessions are cached in-memory for speed, but always mirrored to the JSON
// database file so a server restart, redeploy, or a Cloud Run instance
// cycling doesn't silently log everyone out.
const sessions: Record<string, { userId: string; createdAt: number; lastSeen: number }> = {};
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days of inactivity before a session is forcibly dropped
let sessionsLoadedFromDisk = false;

function ensureSessionsLoaded() {
  if (sessionsLoadedFromDisk) return;
  sessionsLoadedFromDisk = true;
  try {
    if (fs.existsSync(DATABASE_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(DATABASE_FILE, 'utf-8'));
      if (parsed && parsed.sessions) {
        Object.assign(sessions, parsed.sessions);
      }
    }
  } catch {
    // If the database file is unreadable here, readDB() elsewhere will
    // surface the error; sessions just start empty for this run.
  }
}

function persistSessions() {
  const db = readDB();
  db.sessions = sessions;
  writeDB(db);
}

function createSession(userId: string): string {
  ensureSessionsLoaded();
  const token = crypto.randomBytes(32).toString('hex');
  sessions[token] = { userId, createdAt: Date.now(), lastSeen: Date.now() };
  persistSessions();
  return token;
}

function getUserIdFromToken(token: string): string | null {
  ensureSessionsLoaded();
  const session = sessions[token];
  if (!session) return null;
  if (Date.now() - session.lastSeen > SESSION_TTL_MS) {
    delete sessions[token];
    persistSessions();
    return null;
  }
  // Sliding expiration: any authenticated request keeps the session alive,
  // so an actively-used account is never logged out mid-use.
  session.lastSeen = Date.now();
  return session.userId;
}

function base32Decode(base32: string): Buffer {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = '';
  for (let i = 0; i < base32.length; i++) {
    const val = alphabet.indexOf(base32[i].toUpperCase());
    if (val >= 0) {
      bits += val.toString(2).padStart(5, '0');
    }
  }
  const bytes: number[] = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) {
    bytes.push(parseInt(bits.substr(i, 8), 2));
  }
  return Buffer.from(bytes);
}

function verifyTOTP(secret: string, code: string): boolean {
  if (!code || code.length !== 6) return false;
  const cleanedSecret = secret.toUpperCase().replace(/[^A-Z2-7]/g, '');
  if (!cleanedSecret) return false;

  const currentCounter = Math.floor(Date.now() / 1000 / 30);
  for (let drift = -1; drift <= 1; drift++) {
    const counter = currentCounter + drift;
    const buffer = Buffer.alloc(8);
    buffer.writeUInt32BE(0, 0);
    buffer.writeUInt32BE(counter, 4);

    const key = base32Decode(cleanedSecret);
    const hmac = crypto.createHmac('sha1', key).update(buffer).digest();

    const offset = hmac[hmac.length - 1] & 0xf;
    const binCode = ((hmac[offset] & 0x7f) << 24) |
                    ((hmac[offset + 1] & 0xff) << 16) |
                    ((hmac[offset + 2] & 0xff) << 8) |
                    (hmac[offset + 3] & 0xff);

    const otpVal = (binCode % 1000000).toString().padStart(6, '0');
    if (otpVal === code) {
      return true;
    }
  }
  return false;
}

function sanitizeInput(val: any): any {
  if (typeof val === 'string') {
    return val
      .replace(/<script[^>]*>([\s\S]*?)<\/script>/gi, '')
      .replace(/<[^>]*>/g, '')
      .replace(/javascript:/gi, '')
      .replace(/data:text\/html/gi, '')
      .replace(/\son\w+\s*=/gi, ' ')
      .trim();
  }
  if (Array.isArray(val)) {
    return val.map(sanitizeInput);
  }
  if (val && typeof val === 'object') {
    const cleaned: any = {};
    for (const key of Object.keys(val)) {
      cleaned[key] = sanitizeInput(val[key]);
    }
    return cleaned;
  }
  return val;
}

// Failed login attempts tracker for the Rate-Limiter (max 5 fails inside 15 mins)
const loginAttempts: Record<string, { count: number; lockUntil: number }> = {};

// Initialize database helper with password auto-hashing migration
function readDB(): DBStructure {
  try {
    if (fs.existsSync(DATABASE_FILE)) {
      const content = fs.readFileSync(DATABASE_FILE, 'utf-8');
      const parsed = JSON.parse(content);

      // NOTE: A previous version of this function hardcoded a fixed list of
      // "admin emails" directly in source, force-promoted any account using
      // those emails to admin on every single read, force-demoted any other
      // admin back to student, and auto-created those accounts with the
      // literal password "admin" if they didn't exist yet. Since this source
      // file ships with the app, that was a full authentication backdoor —
      // anyone with a copy of the code could become admin on any deployment.
      //
      // Roles are now only ever set at registration time (gated behind the
      // ADMIN_INVITE_CODE environment variable) or by an existing admin
      // through the admin API. Nothing here silently changes anyone's role.
      if (parsed && !parsed.auditLogs) {
        parsed.auditLogs = [];
      }

      if (parsed && !parsed.notifications) {
        parsed.notifications = [
          {
            id: "notif-seeded-1",
            title: "فرصة تدريبية مميزة في حقل غرب القرنة النفطي لعام 2026",
            titleEn: "Exclusive training opportunity in West Qurna oil field",
            description: "تعلن الهيئة الكيميائية للبصرة بالتعاون مع شركة نفط البصرة عن توفير 5 مقاعد تدريبية لحديثي التخرج في معالجة وفصل المركبات الغازية والنفطية والتعرف على هندسة التكرير العملية.",
            descriptionEn: "The Chemical Association of Basra, in coordination with BOC, offers 5 training spots for fresh chemistry grads in petroleum refining operations.",
            type: "course",
            createdAt: "2026-06-10T12:00:00Z"
          },
          {
            id: "notif-seeded-2",
            title: "تم توفير كتاب بيري للهندسة الكيميائية النسخة التاسعة",
            titleEn: "Perry's Chemical Manual (9th Edition) now available",
            description: "تم إضافة رابط تحميل مباشر وعالي السرعة من غوغل درايف لكتاب بيري الكامل (بحجم 400 ميغابايت) للتحميل الفوري وتلافي مشاكل الحجم للمتصفحات.",
            descriptionEn: "We added a high-speed GDrive mirror link for Perry's core handbook inside the resources panel to support fast downloads.",
            type: "resource",
            createdAt: "2026-06-09T15:30:00Z"
          }
        ];
        fs.writeFileSync(DATABASE_FILE, JSON.stringify(parsed, null, 2), 'utf-8');
      }

      if (parsed && !parsed.news) {
        parsed.news = defaultDB.news || [];
        fs.writeFileSync(DATABASE_FILE, JSON.stringify(parsed, null, 2), 'utf-8');
      }

      return parsed;
    }
  } catch (err) {
    console.error('Error reading database file:', err);
  }
  // Write default db if not existing or error
  writeDB(defaultDB);
  return defaultDB;
}

async function persistToFirestore(data: any) {
  if (!isFirebaseServerActive || !firebaseDB) return;
  const collectionsToSync = ['platforms', 'courses', 'resources', 'users', 'auditLogs'];
  for (const colName of collectionsToSync) {
    try {
      // NOTE: auditLogs (the login/activity history) must never be capped or
      // pruned here. A previous version only synced the newest 50 entries
      // and then deleted every older Firestore document as an "orphan" —
      // and on the next server restart, syncFromFirestore() would load that
      // now-truncated Firestore copy back over the full local history,
      // permanently losing everything older than the last 50 events. Login
      // and activity history is kept in full and is never auto-deleted.
      const list = data[colName] || [];
      const currentIds = new Set(list.map((item: any) => item.id).filter(Boolean));

      // Save current items
      for (const item of list) {
        if (item.id) {
          await setDoc(doc(firebaseDB, colName, item.id), item);
        }
      }

      // Prune orphans (documents removed locally, e.g. via the admin panel)
      // — but never for auditLogs, which is an append-only history log.
      if (colName !== 'auditLogs') {
        const snap = await getDocs(collection(firebaseDB, colName));
        for (const fDoc of snap.docs) {
          if (!currentIds.has(fDoc.id)) {
            await deleteDoc(doc(firebaseDB, colName, fDoc.id));
            console.log(`[Firestore Sync] Pruned deleted orphan document: ${colName}/${fDoc.id}`);
          }
        }
      }
    } catch (colErr) {
      console.warn(`[Firestore Sync] Error syncing collection ${colName}:`, colErr);
    }
  }
}

function writeDB(data: any) {
  try {
    fs.writeFileSync(DATABASE_FILE, JSON.stringify(data, null, 2), 'utf-8');
    if (isFirebaseServerActive) {
      persistToFirestore(data).catch(err => {
        console.error('Background Firestore state save failed:', err);
      });
    }
  } catch (err) {
    console.error('Error writing database file:', err);
  }
}

async function syncFromFirestore() {
  if (!isFirebaseServerActive || !firebaseDB) return;
  console.log('Initiating synchronization with Firestore durable cloud storage...');
  try {
    const memoryDB = readDB();
    const collectionsToSync = ['platforms', 'courses', 'resources', 'users', 'auditLogs'];
    let updatedAny = false;

    for (const colName of collectionsToSync) {
      try {
        const colRef = collection(firebaseDB, colName);
        const snap = await getDocs(colRef);
        
        if (!snap.empty) {
          const items: any[] = [];
          snap.forEach(fDoc => {
            items.push({ id: fDoc.id, ...fDoc.data() });
          });
          
          // Update local memory
          (memoryDB as any)[colName] = items;
          updatedAny = true;
          console.log(`Loaded ${items.length} items from Firestore for collection: ${colName}`);
        } else {
          // Firestore collection is empty, seed it with local data!
          console.log(`Firestore collection '${colName}' is empty. Seeding with local pre-seeded database items...`);
          const list = (memoryDB as any)[colName] || [];
          for (const item of list) {
            if (item.id) {
              await setDoc(doc(firebaseDB, colName, item.id), item);
            }
          }
        }
      } catch (colErr) {
        console.error(`Error loading or seeding category ${colName} from Firestore:`, colErr);
      }
    }

    if (updatedAny) {
      // Save merged database to database.json
      fs.writeFileSync(DATABASE_FILE, JSON.stringify(memoryDB, null, 2), 'utf-8');
      console.log('Successfully completed Firestore state import into database.json.');
    }
  } catch (err) {
    console.error('Failed to sync from Firestore at startup:', err);
  }
}

// Ensure database file is initialized on load
readDB();

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '10mb' }));

  // Run startup synchronization with Firestore
  if (isFirebaseServerActive) {
    await syncFromFirestore();
  }

  // Secure Admin-Only Authorization Middleware
  const requireAdmin = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const authHeader = req.headers['authorization'];
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'غير مصرح: يجب تسجيل الدخول كمشرف لتعديل البيانات' });
    }
    const token = authHeader.substring(7).trim(); // Remove 'Bearer '
    if (!token) {
      return res.status(401).json({ error: 'عنصر المصادقة مفقود أو غير فعال' });
    }
    const userId = getUserIdFromToken(token);
    if (!userId) {
      return res.status(401).json({ error: 'الجلسة منتهية أو غير صالحة، الرجاء تسجيل الدخول من جديد' });
    }
    const db = readDB();
    const user = db.users.find(u => u.id === userId);
    if (!user) {
      return res.status(401).json({ error: 'عنصر الأمان غير صالح أو تم حذفه' });
    }
    if (user.role !== 'admin') {
      return res.status(403).json({ error: 'محاولة اختراق أو صلاحيات غير كافية لإجراء التغييرات' });
    }
    (req as any).currentUser = user;
    next();
  };

  // Require any signed-in user (not necessarily admin) - used for endpoints
  // that act on the caller's own data.
  const requireAuth = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const authHeader = req.headers['authorization'];
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'غير مصرح: الرجاء تسجيل الدخول' });
    }
    const token = authHeader.substring(7).trim();
    const userId = getUserIdFromToken(token);
    if (!userId) {
      return res.status(401).json({ error: 'الجلسة منتهية أو غير صالحة، الرجاء تسجيل الدخول من جديد' });
    }
    const db = readDB();
    const user = db.users.find(u => u.id === userId);
    if (!user) {
      return res.status(401).json({ error: 'عنصر الأمان غير صالح أو تم حذفه' });
    }
    (req as any).currentUser = user;
    next();
  };

  // API Route - Get all platforms
  app.get('/api/platforms', (req, res) => {
    const db = readDB();
    res.json(db.platforms);
  });

  // API Route - Add dynamic platform
  app.post('/api/platforms', requireAdmin, (req, res) => {
    const { name, url, image, description } = req.body;
    if (!name || !url) {
      return res.status(400).json({ error: 'الاسم والرابط مطلوبان' });
    }
    const db = readDB();
    const newPlatform = {
      id: 'p-' + Date.now(),
      name,
      url,
      image: image || 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=500&auto=format&fit=crop&q=60',
      description: description || 'منصة مضافة من قبل إدارة الهيئة.',
      isSystem: false
    };
    db.platforms.push(newPlatform);

    // Auto-generate official platform addition notification
    if (!db.notifications) db.notifications = [];
    db.notifications.push({
      id: 'notif-' + Date.now(),
      title: `إضافة منصة رقمية جديدة: ${name}`,
      titleEn: `New digital platform: ${name}`,
      description: `تم إطلاق منصة رقمية تفاعلية جديدة تحت عنوان "${name}". يمكنك استكشافها وتجربتها الآن.`,
      descriptionEn: `A brand-new interactive simulator platform "${name}" was uploaded to the dashboard. Click to explore now!`,
      type: 'platform',
      createdAt: new Date().toISOString()
    });

    writeDB(db);
    res.json(newPlatform);
  });

  // API Route - Edit platform
  app.put('/api/platforms/:id', requireAdmin, (req, res) => {
    const { id } = req.params;
    const { name, url, image, description } = req.body;
    const db = readDB();
    const index = db.platforms.findIndex(p => p.id === id);
    if (index === -1) {
      return res.status(404).json({ error: 'المنصة غير موجودة' });
    }
    const oldPlat = db.platforms[index];
    db.platforms[index] = {
      ...db.platforms[index],
      name: name || db.platforms[index].name,
      url: url || db.platforms[index].url,
      image: image || db.platforms[index].image,
      description: description !== undefined ? description : db.platforms[index].description
    };

    // Auto-generate official update announcement
    if (!db.notifications) db.notifications = [];
    db.notifications.push({
      id: 'notif-' + Date.now(),
      title: `تحديث بيانات منصة: ${db.platforms[index].name}`,
      titleEn: `Platform updated: ${db.platforms[index].name}`,
      description: `تم إجراء تعديلات وتحديثات رسمية لبيانات ورابط المنصة الرقمية "${db.platforms[index].name}".`,
      descriptionEn: `Official updates and refinements were applied to the "${db.platforms[index].name}" simulator platform details.`,
      type: 'platform',
      createdAt: new Date().toISOString()
    });

    writeDB(db);
    res.json(db.platforms[index]);
  });

  // API Route - Delete platform
  app.delete('/api/platforms/:id', requireAdmin, (req, res) => {
    const { id } = req.params;
    const db = readDB();
    const deletedPlat = db.platforms.find(p => p.id === id);
    db.platforms = db.platforms.filter(p => p.id !== id);

    if (deletedPlat) {
      if (!db.notifications) db.notifications = [];
      db.notifications.push({
        id: 'notif-' + Date.now(),
        title: `إزالة منصة رقمية: ${deletedPlat.name}`,
        titleEn: `Platform removed: ${deletedPlat.name}`,
        description: `قامت الإدارة بإزالة المنصة الرقمية "${deletedPlat.name}" من الواجهة لأغراض التحديث والتصليح الهيكلي.`,
        descriptionEn: `The digital platform "${deletedPlat.name}" has been removed from the platform listing for structural optimization.`,
        type: 'platform',
        createdAt: new Date().toISOString()
      });
    }

    writeDB(db);
    res.json({ success: true });
  });

  // API Route - Get courses
  app.get('/api/courses', (req, res) => {
    const db = readDB();
    res.json(db.courses);
  });

  // API Route - Add course
  app.post('/api/courses', requireAdmin, (req, res) => {
    const { title, url, description, instructor } = req.body;
    if (!title || !url) {
      return res.status(400).json({ error: 'العنوان والرابط مطلوبان' });
    }
    const db = readDB();
    const newCourse = {
      id: 'c-' + Date.now(),
      title,
      url,
      description: description || '',
      instructor: instructor || 'الهيئة الكيميائية بالبصرة',
      addedAt: new Date().toISOString()
    };
    db.courses.push(newCourse);
    
    // Auto-generate notification
    if (!db.notifications) db.notifications = [];
    db.notifications.push({
      id: 'notif-' + Date.now(),
      title: `طرح دورة هندسية جديدة: ${title}`,
      titleEn: `New course released: ${title}`,
      description: `تم إطلاق البرنامج التدريبي الجديد الحامل لعنوان "${title}" تحت إشراف م. ${newCourse.instructor}. يمكنك التقديم الآن.`,
      descriptionEn: `We just launched a premier training course: "${title}" by Eng. ${newCourse.instructor}. Find more details inside the Courses board.`,
      type: 'course',
      createdAt: new Date().toISOString()
    });

    writeDB(db);
    res.json(newCourse);
  });

  // API Route - Edit course
  app.put('/api/courses/:id', requireAdmin, (req, res) => {
    const { id } = req.params;
    const { title, url, description, instructor } = req.body;
    const db = readDB();
    const index = db.courses.findIndex(c => c.id === id);
    if (index === -1) {
      return res.status(404).json({ error: 'الدورة غير موجودة' });
    }
    db.courses[index] = {
      ...db.courses[index],
      title: title || db.courses[index].title,
      url: url || db.courses[index].url,
      description: description !== undefined ? description : db.courses[index].description,
      instructor: instructor || db.courses[index].instructor
    };

    // Auto-generate official course update alert
    if (!db.notifications) db.notifications = [];
    db.notifications.push({
      id: 'notif-' + Date.now(),
      title: `تعديل منهج حقيبة: ${db.courses[index].title}`,
      titleEn: `Course updated: ${db.courses[index].title}`,
      description: `تم تحديث المنهج والمخطط التفصيلي للحقيبة التدريبية "${db.courses[index].title}" تحت إشراف المنصة الكيميائية بالبصرة.`,
      descriptionEn: `Syllabus contents or instructor guidelines for training course "${db.courses[index].title}" have been officially updated.`,
      type: 'course',
      createdAt: new Date().toISOString()
    });

    writeDB(db);
    res.json(db.courses[index]);
  });

  // API Route - Reorder courses
  app.post('/api/courses/reorder', requireAdmin, (req, res) => {
    const { courseIds } = req.body;
    if (!Array.isArray(courseIds)) {
      return res.status(400).json({ error: 'الترتيب غير صحيح' });
    }
    const db = readDB();
    const ordered: any[] = [];
    courseIds.forEach(cid => {
      const found = db.courses.find(c => c.id === cid);
      if (found) ordered.push(found);
    });
    // Add missing ones just in case
    db.courses.forEach(c => {
      if (!ordered.some(o => o.id === c.id)) {
        ordered.push(c);
      }
    });
    db.courses = ordered;
    writeDB(db);
    res.json(db.courses);
  });

  // API Route - Reorder platforms
  app.post('/api/platforms/reorder', requireAdmin, (req, res) => {
    const { platformIds } = req.body;
    if (!Array.isArray(platformIds)) {
      return res.status(400).json({ error: 'الترتيب غير صحيح للمنصات' });
    }
    const db = readDB();
    const ordered: any[] = [];
    platformIds.forEach(pid => {
      const found = db.platforms.find(p => p.id === pid);
      if (found) ordered.push(found);
    });
    db.platforms.forEach(p => {
      if (!ordered.some(o => o.id === p.id)) {
        ordered.push(p);
      }
    });
    db.platforms = ordered;
    writeDB(db);
    res.json(db.platforms);
  });

  // API Route - Delete course
  app.delete('/api/courses/:id', requireAdmin, (req, res) => {
    const { id } = req.params;
    const db = readDB();
    const deletedCourse = db.courses.find(c => c.id === id);
    db.courses = db.courses.filter(c => c.id !== id);

    if (deletedCourse) {
      if (!db.notifications) db.notifications = [];
      db.notifications.push({
        id: 'notif-' + Date.now(),
        title: `إيقاف وحذف حقيبة تدريبية: ${deletedCourse.title}`,
        titleEn: `Course retired: ${deletedCourse.title}`,
        description: `تمت أرشفة وإيقاف التسجيل في الملف التدريبي "${deletedCourse.title}" من قبل اللجنة العلمية التابعة للهيئة.`,
        descriptionEn: `The training course folder "${deletedCourse.title}" has been retired or archived by the general science board.`,
        type: 'course',
        createdAt: new Date().toISOString()
      });
    }

    writeDB(db);
    res.json({ success: true });
  });

  // API Route - Get resources
  app.get('/api/resources', (req, res) => {
    const db = readDB();
    res.json(db.resources);
  });

  // API Route - Add engineering resources (supports metadata of files 400MB+)
  app.post('/api/resources', requireAdmin, (req, res) => {
    const { title, category, description, url, fileName, fileSize } = req.body;
    if (!title || !url || !fileName) {
      return res.status(400).json({ error: 'المعلومات الأساسية للمصدر ناقصة' });
    }
    const db = readDB();
    const newResource = {
      id: 'res-' + Date.now(),
      title,
      category: category || 'كتب عامة',
      description: description || '',
      url,
      fileName,
      fileSize: Number(fileSize) || 0,
      addedAt: new Date().toISOString()
    };
    db.resources.push(newResource);
    
    // Auto-generate notification
    if (!db.notifications) db.notifications = [];
    const sizeMb = newResource.fileSize ? (newResource.fileSize / 1000000).toFixed(1) : 'unknown';
    db.notifications.push({
      id: 'notif-' + Date.now(),
      title: `إضافة مصدر هندسي جديد: ${title}`,
      titleEn: `New resource library file: ${title}`,
      description: `تم إدراج مرجع وملخص هندسي جديد تحت عنوان "${title}" في قسم المصادر والمكتبة الكيميائية. الحجم التقريبي: ${sizeMb} ميغابايت.`,
      descriptionEn: `A brand-new methodology textbook "${title}" is now downloadable from GCE portal. Approx size: ${sizeMb}MB.`,
      type: 'resource',
      createdAt: new Date().toISOString()
    });

    writeDB(db);
    res.json(newResource);
  });

  // API Route - Edit engineering resource
  app.put('/api/resources/:id', requireAdmin, (req, res) => {
    const { id } = req.params;
    const { title, category, description, url, fileName, fileSize } = req.body;
    const db = readDB();
    const index = db.resources.findIndex(r => r.id === id);
    if (index === -1) {
      return res.status(404).json({ error: 'المصدر غير موجود' });
    }
    db.resources[index] = {
      ...db.resources[index],
      title: title || db.resources[index].title,
      category: category || db.resources[index].category,
      description: description !== undefined ? description : db.resources[index].description,
      url: url || db.resources[index].url,
      fileName: fileName || db.resources[index].fileName,
      fileSize: fileSize !== undefined ? Number(fileSize) : db.resources[index].fileSize
    };

    // Auto-generate official engineering library file update alert
    if (!db.notifications) db.notifications = [];
    db.notifications.push({
      id: 'notif-' + Date.now(),
      title: `تحديث مصدر هندسي: ${db.resources[index].title}`,
      titleEn: `Resource updated: ${db.resources[index].title}`,
      description: `تم تحديث وتحرير تفاصيل المصدر الهندسي المشترك "${db.resources[index].title}" في المكتبة الرقمية العامة لمهندسي البصرة.`,
      descriptionEn: `A dynamic edit has been published for download resource "${db.resources[index].title}" inside GCE Library database.`,
      type: 'resource',
      createdAt: new Date().toISOString()
    });

    writeDB(db);
    res.json(db.resources[index]);
  });

  // API Route - Reorder resources
  app.post('/api/resources/reorder', requireAdmin, (req, res) => {
    const { resourceIds } = req.body;
    if (!Array.isArray(resourceIds)) {
      return res.status(400).json({ error: 'الترتيب غير صحيح للمصادر' });
    }
    const db = readDB();
    const ordered: any[] = [];
    resourceIds.forEach(rid => {
      const found = db.resources.find(r => r.id === rid);
      if (found) ordered.push(found);
    });
    db.resources.forEach(r => {
      if (!ordered.some(o => o.id === r.id)) {
        ordered.push(r);
      }
    });
    db.resources = ordered;
    writeDB(db);
    res.json(db.resources);
  });

  // API Route - Delete resource
  app.delete('/api/resources/:id', requireAdmin, (req, res) => {
    const { id } = req.params;
    const db = readDB();
    const deletedRes = db.resources.find(r => r.id === id);
    db.resources = db.resources.filter(r => r.id !== id);

    if (deletedRes) {
      if (!db.notifications) db.notifications = [];
      db.notifications.push({
        id: 'notif-' + Date.now(),
        title: `حذف مصدر هندسي: ${deletedRes.title}`,
        titleEn: `Resource removed: ${deletedRes.title}`,
        description: `تمت إزالة المستند أو الملخص "${deletedRes.title}" من مكتبة الهياكل والمصادر العامة من قبل المشرف.`,
        descriptionEn: `The technical resource file "${deletedRes.title}" has been removed from GCE Basra senior library databases.`,
        type: 'resource',
        createdAt: new Date().toISOString()
      });
    }

    writeDB(db);
    res.json({ success: true });
  });

  // API Route - Get PWA manifest
  app.get('/manifest.json', (req, res) => {
    res.json({
      short_name: "GCE Basra",
      name: "الهيئة الكيميائية للهندسة والتعليم بالبصرة",
      description: "المنصة التعليمية الشاملة ومحاكيات الغاز والمنظفات لمهندسي البصرة",
      icons: [
        {
          src: "https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=192&auto=format&fit=crop&q=80",
          type: "image/jpeg",
          sizes: "192x192"
        },
        {
          src: "https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=512&auto=format&fit=crop&q=80",
          type: "image/jpeg",
          sizes: "512x512"
        }
      ],
      start_url: "/",
      background_color: "#0f172a",
      theme_color: "#0d9488",
      display: "standalone",
      orientation: "portrait"
    });
  });

  // API Route - Get social/authority accounts
  app.get('/api/accounts', (req, res) => {
    const db = readDB();
    res.json(db.accounts);
  });

  // API Route - Update social accounts
  app.put('/api/accounts', requireAdmin, (req, res) => {
    const db = readDB();
    db.accounts = {
      ...db.accounts,
      ...req.body
    };

    // Auto-generate accounts updating notification
    if (!db.notifications) db.notifications = [];
    db.notifications.push({
      id: 'notif-' + Date.now(),
      title: `تحديث منصات التواصل وقنوات الدعم`,
      titleEn: `Official direct portals updated`,
      description: `قامت إدارة الهيئة بتحديث وتعديل مكاتب التنسيق وقنوات التواصل والمواقع الرقمية الرسمية وشريكها منصة GOT Engineering.`,
      descriptionEn: `GCE Basra direct contact links or partner training platform channels have been updated.`,
      type: 'general',
      createdAt: new Date().toISOString()
    });

    writeDB(db);
    res.json(db.accounts);
  });

  // API Routes - News & Activities
  app.get('/api/news', (req, res) => {
    const db = readDB();
    if (!db.news) db.news = [];
    const sorted = [...db.news].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    res.json(sorted);
  });

  app.post('/api/news', requireAdmin, (req, res) => {
    const { title, content, imageUrl, videoUrl } = req.body;
    if (!title || !content) {
      return res.status(400).json({ error: 'العنوان والتفاصيل مطلوبة' });
    }
    const db = readDB();
    if (!db.news) db.news = [];
    const newPost = {
      id: 'news-' + Date.now(),
      title,
      content,
      imageUrl: imageUrl || undefined,
      videoUrl: videoUrl || undefined,
      createdAt: new Date().toISOString(),
      comments: []
    };
    db.news.push(newPost);

    // Auto-generate notification when admin posts news
    if (!db.notifications) db.notifications = [];
    db.notifications.push({
      id: 'notif-' + Date.now(),
      title: `نشاط جديد: ${title}`,
      titleEn: `New activity: ${title}`,
      description: content.substring(0, 150) + '...',
      descriptionEn: `A fresh update has been posted in GCE News & Activities panel.`,
      type: 'general',
      createdAt: new Date().toISOString()
    });

    writeDB(db);
    res.json(newPost);
  });

  app.delete('/api/news/:id', requireAdmin, (req, res) => {
    const { id } = req.params;
    const db = readDB();
    if (!db.news) db.news = [];
    db.news = db.news.filter((post: any) => post.id !== id);
    writeDB(db);
    res.json({ success: true, message: 'تم الحذف بنجاح' });
  });

  app.post('/api/news/:id/comments', (req, res) => {
    const { id } = req.params;
    const { userName, userEmail, content } = req.body;
    if (!userName || !content) {
      return res.status(400).json({ error: 'اسم المستخدم والتعليق مطلوبين' });
    }
    const db = readDB();
    if (!db.news) db.news = [];
    const postIndex = db.news.findIndex((p: any) => p.id === id);
    if (postIndex === -1) {
      return res.status(404).json({ error: 'المنشور غير موجود' });
    }
    const newComment = {
      id: 'comment-' + Date.now(),
      userName,
      userEmail: userEmail || '',
      content,
      createdAt: new Date().toISOString()
    };
    if (!db.news[postIndex].comments) db.news[postIndex].comments = [];
    db.news[postIndex].comments.push(newComment);
    writeDB(db);
    res.json(newComment);
  });

  app.delete('/api/news/:id/comments/:commentId', requireAdmin, (req, res) => {
    const { id, commentId } = req.params;
    const db = readDB();
    if (!db.news) db.news = [];
    const postIndex = db.news.findIndex((p: any) => p.id === id);
    if (postIndex === -1) {
      return res.status(404).json({ error: 'المنشور غير موجود' });
    }
    if (db.news[postIndex].comments) {
      db.news[postIndex].comments = db.news[postIndex].comments.filter((c: any) => c.id !== commentId);
    }
    writeDB(db);
    res.json({ success: true, message: 'تم حذف التعليق بنجاح' });
  });

  // API Route - Get all notifications
  app.get('/api/notifications', (req, res) => {
    const db = readDB();
    if (!db.notifications) db.notifications = [];
    const sorted = [...db.notifications].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    res.json(sorted);
  });

  // API Route - Add administrative notification
  app.post('/api/notifications', requireAdmin, (req, res) => {
    const { title, titleEn, description, descriptionEn, type } = req.body;
    if (!title || !description) {
      return res.status(400).json({ error: 'العنوان والتفاصيل مطلوبة' });
    }
    const db = readDB();
    if (!db.notifications) db.notifications = [];
    const newNotif = {
      id: 'notif-' + Date.now(),
      title,
      titleEn: titleEn || title,
      description,
      descriptionEn: descriptionEn || description,
      type: type || 'general',
      createdAt: new Date().toISOString()
    };
    db.notifications.push(newNotif);
    writeDB(db);
    res.json(newNotif);
  });

  // API Route - Register
  app.post('/api/auth/register', (req, res) => {
    const { name, email, password, academicYear, adminInviteCode } = sanitizeInput(req.body);
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'الاسم والبريد ورقم المرور مطلوبات للتسجيل' });
    }

    const db = readDB();
    const existing = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      return res.status(400).json({ error: 'البريد الإلكتروني مسجل مسبقاً' });
    }

    // Admin accounts are never granted based on a fixed/known password. The
    // only way to register as admin is by supplying a secret invite code
    // configured server-side via the ADMIN_INVITE_CODE environment variable.
    // If that variable isn't set, admin self-registration is disabled entirely
    // and admin accounts must be promoted manually in the database.
    const configuredInviteCode = process.env.ADMIN_INVITE_CODE || '';
    const suppliedCode = typeof adminInviteCode === 'string' ? adminInviteCode : '';
    const isValidInvite = !!configuredInviteCode &&
      suppliedCode.length === configuredInviteCode.length &&
      crypto.timingSafeEqual(Buffer.from(suppliedCode), Buffer.from(configuredInviteCode));

    const assignedRole = isValidInvite ? 'admin' : 'student';
    const assignedAcademicYear = isValidInvite
      ? 'مشرف عام الهيئة'
      : (academicYear || 'طالب هندسة كيميائية بالبصرة');

    const newUser = {
      id: 'u-' + Date.now() + '-' + crypto.randomBytes(4).toString('hex'),
      name,
      email: email.toLowerCase(),
      password: hashPassword(password), // Salted + hashed, never stored in plain text
      role: assignedRole,
      academicYear: assignedAcademicYear,
      emailVerified: false, // Every new account must verify its email, no exceptions
      twoFactorEnabled: false,
      twoFactorSecret: '',
      createdAt: new Date().toISOString()
    };

    db.users.push(newUser);
    
    // Add transaction to administrative audit log
    db.auditLogs.unshift({
      id: 'audit-' + Date.now(),
      userId: newUser.id,
      userName: newUser.name,
      userEmail: newUser.email,
      action: 'REGISTRATION',
      timestamp: new Date().toISOString(),
      details: `إنشاء حساب جديد للمنصة التعليمية برتبة ${assignedRole === 'admin' ? 'مشرف' : 'طالب'} وتعيين البريد غير مؤكد مبدئياً`,
      ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
      userAgent: req.headers['user-agent'] || 'Unknown'
    });

    // Setup initial tracking log for this user
    db.trackingLogs[newUser.id] = {
      userId: newUser.id,
      userName: newUser.name,
      userEmail: newUser.email,
      role: assignedRole,
      registrationDate: newUser.createdAt,
      lastActive: new Date().toISOString(),
      dailyUsageCount: 1,
      totalActiveTimeSeconds: 10,
      platformStays: {},
      activityTimeline: [
        { action: 'إنشاء حساب جديد', timestamp: new Date().toISOString(), details: 'تم تسجيل العضوية التعليمية بنجاح' }
      ]
    };

    writeDB(db);
    const token = createSession(newUser.id);
    res.json({ id: newUser.id, name: newUser.name, email: newUser.email, role: newUser.role, academicYear: newUser.academicYear, emailVerified: newUser.emailVerified, token });
  });

  // API Route - Username + PIN Entry
  // No email/password/Google required. The visitor types their full English
  // name (4+ parts, e.g. "Ali Ahmed Kadhim Al-Basri") plus a 4-digit PIN they
  // choose themselves. If the name is new, we create the account with that
  // PIN. If the name already exists, the PIN must match to log back in -
  // this stops one person from impersonating another just by typing their
  // name, and lets the real owner come back on a new device/browser.
  app.post('/api/auth/username-login', (req, res) => {
    const { username, pin } = sanitizeInput(req.body);
    const rawName = typeof username === 'string' ? username.trim().replace(/\s+/g, ' ') : '';
    const rawPin = typeof pin === 'string' ? pin.trim() : '';

    if (!rawName) {
      return res.status(400).json({ error: 'الرجاء إدخال اسمك الرباعي الكامل باللغة الإنكليزية للدخول' });
    }

    // Require a full English name of at least 4 parts (e.g. "Ali Ahmed Kadhim Al-Basri")
    // so that two different students essentially never collide on the same identifier.
    const namePattern = /^[A-Za-z]+(?:['-][A-Za-z]+)*(?:\s[A-Za-z]+(?:['-][A-Za-z]+)*){3,}$/;
    if (!namePattern.test(rawName)) {
      return res.status(400).json({
        error: 'يجب إدخال الاسم الرباعي الكامل بأحرف إنكليزية فقط (مثال: Ali Ahmed Kadhim Al-Basri)، بدون أرقام أو رموز أو حروف عربية.'
      });
    }

    if (!/^\d{4}$/.test(rawPin)) {
      return res.status(400).json({ error: 'يجب إدخال رمز مكوّن من 4 أرقام بالضبط.' });
    }

    // Normalize into a stable key so "Ali Ahmed..." / " ALI  ahmed... " map to the same identifier
    const usernameKey = rawName.toLowerCase();
    const slug = usernameKey.replace(/[^a-z0-9]+/gi, '-').replace(/^-+|-+$/g, '') || 'user';

    // Rate limit PIN attempts per name, same mechanism as the legacy email/password login
    const clientKey = 'pin:' + usernameKey;
    const attempts = loginAttempts[clientKey];
    if (attempts && attempts.lockUntil > Date.now()) {
      const waitMinutes = Math.ceil((attempts.lockUntil - Date.now()) / 60000);
      return res.status(429).json({
        error: `تم إيقاف محاولات الدخول لهذا الاسم مؤقتاً بسبب تكرار الرمز الخاطئ. حاول مرة أخرى بعد ${waitMinutes} دقيقة.`
      });
    }

    const db = readDB();
    const existing = db.users.find(u => (u.usernameKey || u.name.toLowerCase().replace(/\s+/g, ' ').trim()) === usernameKey);

    let user: any;

    if (existing) {
      const pinOk = !!existing.pin && verifyPassword(rawPin, existing.pin);
      if (!pinOk) {
        if (!loginAttempts[clientKey]) {
          loginAttempts[clientKey] = { count: 1, lockUntil: 0 };
        } else {
          loginAttempts[clientKey].count += 1;
          if (loginAttempts[clientKey].count >= 5) {
            loginAttempts[clientKey].lockUntil = Date.now() + 15 * 60 * 1000;
          }
        }
        return res.status(401).json({
          error: 'هذا الاسم مسجل مسبقاً والرمز الذي أدخلته غير صحيح. إذا كان هذا اسمك، أدخل رمزك الصحيح. وإذا لم يكن اسمك، الرجاء اختيار اسم مختلف.'
        });
      }

      delete loginAttempts[clientKey];
      user = existing;

      db.auditLogs.unshift({
        id: 'audit-' + Date.now(),
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        action: 'LOGIN_SUCCESS',
        timestamp: new Date().toISOString(),
        details: 'تسجيل دخول عبر الاسم والرمز الرباعي',
        ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
        userAgent: req.headers['user-agent'] || 'Unknown'
      });

      if (!db.trackingLogs[user.id]) {
        db.trackingLogs[user.id] = {
          userId: user.id,
          userName: user.name,
          userEmail: user.email,
          role: user.role,
          registrationDate: user.createdAt || new Date().toISOString(),
          lastActive: new Date().toISOString(),
          dailyUsageCount: 0,
          totalActiveTimeSeconds: 0,
          platformStays: {},
          activityTimeline: []
        };
      }
      db.trackingLogs[user.id].lastActive = new Date().toISOString();
      db.trackingLogs[user.id].dailyUsageCount += 1;
      db.trackingLogs[user.id].activityTimeline.unshift({
        action: 'تسجيل دخول للمنصة',
        timestamp: new Date().toISOString(),
        details: 'دخول باستخدام الاسم والرمز الرباعي'
      });
    } else {
      user = {
        id: 'u-' + Date.now() + '-' + crypto.randomBytes(4).toString('hex'),
        name: rawName,
        usernameKey,
        email: `${slug}-${crypto.randomBytes(3).toString('hex')}@highali.local`,
        password: hashPassword(crypto.randomBytes(16).toString('hex')), // unused placeholder, this account has no email/password login
        pin: hashPassword(rawPin), // salted+hashed 4-digit PIN, same as password hashing
        role: 'student',
        academicYear: 'طالب هندسة كيميائية بالبصرة',
        emailVerified: true, // no email flow for username-only accounts
        twoFactorEnabled: false,
        twoFactorSecret: '',
        createdAt: new Date().toISOString()
      };
      db.users.push(user);

      db.auditLogs.unshift({
        id: 'audit-' + Date.now(),
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        action: 'REGISTRATION',
        timestamp: new Date().toISOString(),
        details: 'إنشاء حساب جديد باسم رباعي فريد ورمز دخول من 4 أرقام',
        ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
        userAgent: req.headers['user-agent'] || 'Unknown'
      });

      db.trackingLogs[user.id] = {
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        role: user.role,
        registrationDate: user.createdAt,
        lastActive: new Date().toISOString(),
        dailyUsageCount: 1,
        totalActiveTimeSeconds: 10,
        platformStays: {},
        activityTimeline: [
          { action: 'إنشاء حساب جديد', timestamp: new Date().toISOString(), details: 'دخول أول بالاسم الرباعي والرمز' }
        ]
      };
    }

    writeDB(db);
    const token = createSession(user.id);
    res.json({
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      academicYear: user.academicYear,
      emailVerified: user.emailVerified,
      token
    });
  });

  // API Route - Real Google Sign-In
  // The client obtains a Firebase ID token via signInWithPopup(auth, new
  // GoogleAuthProvider()) and sends it here. We verify it server-side with
  // firebase-admin (which checks the signature, expiry, issuer and audience
  // against Google's keys) — nothing about identity is trusted from the
  // client body itself, unlike the old simulated flow.
  app.post('/api/auth/google-session', async (req, res) => {
    const { idToken } = req.body;
    if (!idToken || typeof idToken !== 'string') {
      return res.status(400).json({ error: 'رمز مصادقة Google مفقود' });
    }
    if (!firebaseAdminReady) {
      return res.status(503).json({ error: 'تسجيل الدخول عبر Google غير مُفعّل على الخادم حالياً. يرجى تهيئة بيانات اعتماد Firebase Admin.' });
    }

    let decoded: admin.auth.DecodedIdToken;
    try {
      decoded = await admin.auth().verifyIdToken(idToken);
    } catch (err) {
      return res.status(401).json({ error: 'رمز مصادقة Google غير صالح أو منتهي الصلاحية' });
    }

    const email = (decoded.email || '').toLowerCase().trim();
    if (!email) {
      return res.status(400).json({ error: 'حساب Google هذا لا يحتوي على بريد إلكتروني' });
    }

    const db = readDB();
    let user = db.users.find(u => u.email.toLowerCase() === email);

    if (!user) {
      user = {
        id: 'u-google-' + Date.now() + '-' + crypto.randomBytes(4).toString('hex'),
        name: decoded.name || email.split('@')[0],
        email,
        // This account can only ever sign in via Google, so the password
        // hash is set to an unusable random value — no one can log in with
        // a typed password even if they somehow learned this hash.
        password: hashPassword(crypto.randomBytes(32).toString('hex')),
        role: 'student',
        academicYear: 'عضو مسجل عبر Google',
        emailVerified: !!decoded.email_verified,
        twoFactorEnabled: false,
        twoFactorSecret: '',
        createdAt: new Date().toISOString()
      };
      db.users.push(user);
    } else if (decoded.email_verified && !user.emailVerified) {
      user.emailVerified = true;
    }

    // Capture 2FA intercept before issuing session
    if (user.twoFactorEnabled) {
      writeDB(db);
      return res.json({ require2Fa: true, userId: user.id });
    }

    db.auditLogs.unshift({
      id: 'audit-' + Date.now(),
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      action: 'LOGIN_GOOGLE',
      timestamp: new Date().toISOString(),
      details: 'تسجيل دخول حقيقي وموثّق عبر Google (تم التحقق من الرمز عبر Firebase Admin)',
      ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
      userAgent: req.headers['user-agent'] || 'Unknown'
    });

    if (!db.trackingLogs[user.id]) {
      db.trackingLogs[user.id] = {
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        role: user.role,
        registrationDate: user.createdAt || new Date().toISOString(),
        lastActive: new Date().toISOString(),
        dailyUsageCount: 0,
        totalActiveTimeSeconds: 0,
        platformStays: {},
        activityTimeline: []
      };
    }

    db.trackingLogs[user.id].lastActive = new Date().toISOString();
    db.trackingLogs[user.id].dailyUsageCount += 1;
    db.trackingLogs[user.id].activityTimeline.unshift({
      action: 'تسجيل دخول عبر Google',
      timestamp: new Date().toISOString(),
      details: `بواسطة البريد الإلكتروني: ${user.email}`
    });

    writeDB(db);
    const token = createSession(user.id);
    res.json({ id: user.id, name: user.name, email: user.email, role: user.role, academicYear: user.academicYear, emailVerified: user.emailVerified, token });
  });

  // API Route - Login with Rate Limiter (Max 5 attempts / 15 minutes)
  app.post('/api/auth/login', (req, res) => {
    const { email, password } = sanitizeInput(req.body);
    if (!email || !password) {
      return res.status(400).json({ error: 'الرجاء إدخال البريد الإلكتروني وكلمة المرور' });
    }

    // Rate Limiting calculations
    const clientKey = email.toLowerCase().trim();
    const attempts = loginAttempts[clientKey];
    if (attempts && attempts.lockUntil > Date.now()) {
      const waitMinutes = Math.ceil((attempts.lockUntil - Date.now()) / 60000);
      return res.status(429).json({ 
        error: `معطل للأمن! تم حظر عمليات الدخول مؤقتاً لتجاوز محاولات تسجيل الدخول المسموح بها (5 محاولات). الرجاء المحاولة بعد ${waitMinutes} دقيقة.` 
      });
    }

    const db = readDB();
    const user = db.users.find(u => u.email.toLowerCase() === clientKey);
    const passwordOk = !!user && verifyPassword(password, user.password);

    if (!user || !passwordOk) {
      // Failed login count
      if (!loginAttempts[clientKey]) {
        loginAttempts[clientKey] = { count: 1, lockUntil: 0 };
      } else {
        loginAttempts[clientKey].count += 1;
        if (loginAttempts[clientKey].count >= 5) {
          loginAttempts[clientKey].lockUntil = Date.now() + 15 * 60 * 1000; // block for 15 mins
        }
      }

      db.auditLogs.unshift({
        id: 'audit-' + Date.now(),
        userId: 'anonymous',
        userName: 'محاولة مجهولة',
        userEmail: clientKey,
        action: 'LOGIN_FAILURE',
        timestamp: new Date().toISOString(),
        details: `محاولة تسجيل دخول فاشلة للمرة رقم ${loginAttempts[clientKey].count}`,
        ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
        userAgent: req.headers['user-agent'] || 'Unknown'
      });
      writeDB(db);

      const remains = 5 - (loginAttempts[clientKey].count % 5);
      return res.status(401).json({ 
        error: `البريد الإلكتروني أو كلمة المرور غير صحيحة. متبقي لديك ${remains === 5 ? 0 : remains} محاولات قبل إغلاق الحساب.` 
      });
    }

    // Correct login - clear previous limits
    delete loginAttempts[clientKey];

    // Transparently upgrade legacy unsalted sha256 hashes to the new salted format
    if (!user.password.includes(':')) {
      user.password = hashPassword(password);
    }

    // Check if 2FA is active
    if (user.twoFactorEnabled) {
      return res.json({ require2Fa: true, userId: user.id });
    }

    // Clean login audit write
    db.auditLogs.unshift({
      id: 'audit-' + Date.now(),
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      action: 'LOGIN_SUCCESS',
      timestamp: new Date().toISOString(),
      details: 'تسجيل دخول ناجح ومرخص من صفحة تسجيل الدخول الموحدة',
      ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
      userAgent: req.headers['user-agent'] || 'Unknown'
    });

    // Refresh user log last active and count
    if (!db.trackingLogs[user.id]) {
      db.trackingLogs[user.id] = {
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        role: user.role,
        registrationDate: user.createdAt || new Date().toISOString(),
        lastActive: new Date().toISOString(),
        dailyUsageCount: 0,
        totalActiveTimeSeconds: 0,
        platformStays: {},
        activityTimeline: []
      };
    }
    
    db.trackingLogs[user.id].lastActive = new Date().toISOString();
    db.trackingLogs[user.id].dailyUsageCount += 1;
    db.trackingLogs[user.id].activityTimeline.unshift({
      action: 'تسجيل دخول للمنصة',
      timestamp: new Date().toISOString(),
      details: 'من خلال صفحة المصادقة الرئيسية'
    });

    writeDB(db);
    const loginToken = createSession(user.id);
    res.json({ id: user.id, name: user.name, email: user.email, role: user.role, academicYear: user.academicYear, emailVerified: user.emailVerified, token: loginToken });
  });

  // API Route - Generate 2FA Secret and QR Code image
  app.post('/api/auth/2fa/generate', requireAuth, (req, res) => {
    const user = (req as any).currentUser;

    // Generate random 16 character Base32 private secret key seed
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    let tempSecret = '';
    for (let i = 0; i < 16; i++) {
      tempSecret += chars[Math.floor(Math.random() * chars.length)];
    }

    // Construct OTPAuth standard URI
    const label = encodeURIComponent(`GCE_Basra:${user.email}`);
    const otpauthUrl = `otpauth://totp/${label}?secret=${tempSecret}&issuer=GCE_Basra_Platform`;

    // Render local SVG Data URL QR Code
    qrcode.toDataURL(otpauthUrl, (err, dataUrl) => {
      if (err) {
        return res.status(500).json({ error: 'فشل توليد رمز الاستجابة السريعة (QR Code)' });
      }
      res.json({ secret: tempSecret, qrCodeUrl: dataUrl });
    });
  });

  // API Route - Activate and Lock with 2FA
  app.post('/api/auth/2fa/enable', requireAuth, (req, res) => {
    const { secret, code } = req.body;
    if (!secret || !code) {
      return res.status(400).json({ error: 'جميع حقول التحقق من المصادقة الثنائية إجبارية' });
    }
    const db = readDB();
    const user = db.users.find(u => u.id === (req as any).currentUser.id);
    if (!user) {
      return res.status(404).json({ error: 'المستخدم غير موجود' });
    }

    // Validate if the user input matches the standard OTP hash
    const isValid = verifyTOTP(secret, code);
    if (!isValid) {
      return res.status(400).json({ error: 'الرمز المدخل غير صحيح أو انتهت صلاحيته كود 2FA' });
    }

    user.twoFactorEnabled = true;
    user.twoFactorSecret = secret;

    // Log this severe security update to audit log
    db.auditLogs.unshift({
      id: 'audit-' + Date.now(),
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      action: '2FA_ACTIVATE',
      timestamp: new Date().toISOString(),
      details: 'تم تفعيل ميزة المصادقة الثنائية 2FA بنجاح بترميز Google Authenticator',
      ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
      userAgent: req.headers['user-agent'] || 'Unknown'
    });

    writeDB(db);
    res.json({ success: true, message: 'تم تفعيل المصادقة الثنائية بنجاح' });
  });

  // API Route - Disable 2FA Settings
  app.post('/api/auth/2fa/disable', requireAuth, (req, res) => {
    const { code } = req.body;
    if (!code) {
      return res.status(400).json({ error: 'رمز المصادقة ضروري لتعطيل الميزة' });
    }
    const db = readDB();
    const user = db.users.find(u => u.id === (req as any).currentUser.id);
    if (!user) {
      return res.status(404).json({ error: 'العضو غير موجود' });
    }

    const isValid = verifyTOTP(user.twoFactorSecret || '', code);
    if (!isValid) {
      return res.status(400).json({ error: 'فشل إيقاف الخدمة: الرمز المكون من 6 أرقام غير منطبق' });
    }

    user.twoFactorEnabled = false;
    user.twoFactorSecret = '';

    db.auditLogs.unshift({
      id: 'audit-' + Date.now(),
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      action: '2FA_DEACTIVATE',
      timestamp: new Date().toISOString(),
      details: 'تم إيقاف ميزة المصادقة الثنائية عن طريق إرشادات إعدادات المستخدم المعني',
      ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
      userAgent: req.headers['user-agent'] || 'Unknown'
    });

    writeDB(db);
    res.json({ success: true, message: 'تم إلغاء تفعيل المصادقة الثنائية بنجاح' });
  });

  // API Route - Challenge Verification on Login
  app.post('/api/auth/2fa/verify', (req, res) => {
    const { userId, code } = req.body;
    if (!userId || !code) {
      return res.status(400).json({ error: 'الرجاء كتابة رمز التحقق المكون من 6 أرقام' });
    }
    const db = readDB();
    const user = db.users.find(u => u.id === userId);
    if (!user) {
      return res.status(404).json({ error: 'المستخدم غير مدرج بالنظام' });
    }

    const isValid = verifyTOTP(user.twoFactorSecret || '', code);
    if (!isValid) {
      // Log failed 2FA verification attempt
      db.auditLogs.unshift({
        id: 'audit-' + Date.now(),
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        action: '2FA_VERIFICATION_FAILED',
        timestamp: new Date().toISOString(),
        details: 'فشل إدخل رمز التحقق الثنائي 2FA في صفحة تسجيل الدخول',
        ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
        userAgent: req.headers['user-agent'] || 'Unknown'
      });
      writeDB(db);
      return res.status(400).json({ error: 'رمز التحقق غير صحيح، يرجى التأكد من التطبيق والمطابقة' });
    }

    // Success audit log
    db.auditLogs.unshift({
      id: 'audit-' + Date.now(),
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      action: 'LOGIN_SUCCESS',
      timestamp: new Date().toISOString(),
      details: 'تم تسجيل الدخول بنجاح بعد اجتياز المصادقة الثنائية 2FA',
      ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
      userAgent: req.headers['user-agent'] || 'Unknown'
    });

    // Refresh user activity log telemetry
    if (!db.trackingLogs[user.id]) {
      db.trackingLogs[user.id] = {
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        role: user.role,
        registrationDate: user.createdAt || new Date().toISOString(),
        lastActive: new Date().toISOString(),
        dailyUsageCount: 0,
        totalActiveTimeSeconds: 0,
        platformStays: {},
        activityTimeline: []
      };
    }
    db.trackingLogs[user.id].lastActive = new Date().toISOString();
    db.trackingLogs[user.id].dailyUsageCount += 1;
    db.trackingLogs[user.id].activityTimeline.unshift({
      action: 'تسجيل دخول (جاوزت المصادقة الثنائية)',
      timestamp: new Date().toISOString(),
      details: 'من خلال البوابة الأمنية والتحقق من Google Authenticator'
    });

    writeDB(db);
    const twoFaToken = createSession(user.id);
    res.json({ id: user.id, name: user.name, email: user.email, role: user.role, academicYear: user.academicYear, emailVerified: user.emailVerified, token: twoFaToken });
  });

  // API Route - Confirm / Verify User Email Immediately (Test Tool + Sandbox Flow)
  app.post('/api/auth/verify-email/confirm', requireAuth, (req, res) => {
    const db = readDB();
    const user = db.users.find(u => u.id === (req as any).currentUser.id);
    if (!user) return res.status(404).json({ error: 'المستخدم غير موجود' });

    user.emailVerified = true;

    db.auditLogs.unshift({
      id: 'audit-' + Date.now(),
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      action: 'EMAIL_VERIFIED',
      timestamp: new Date().toISOString(),
      details: 'تم تأكيد التحقق من البريد الإلكتروني وتفعيل الحساب التعليمي بنجاح',
      ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
      userAgent: req.headers['user-agent'] || 'Unknown'
    });

    writeDB(db);
    res.json({ success: true, emailVerified: true });
  });

  // API Route - Forgot / Reset Password simulated link generator
  app.post('/api/auth/reset-password', (req, res) => {
    const { email } = sanitizeInput(req.body);
    if (!email) {
      return res.status(400).json({ error: 'الرجاء إدخال البريد الإلكتروني بشكل صحيح' });
    }
    const db = readDB();
    const user = db.users.find(u => u.email.toLowerCase() === email.toLowerCase().trim());
    if (!user) {
      return res.status(404).json({ error: 'لم يتم العثور على أي حساب مسجل بهذا البريد الإلكتروني.' });
    }

    // Write audit log
    db.auditLogs.unshift({
      id: 'audit-' + Date.now(),
      userId: user.id || 'anonymous',
      userName: user.name || 'مجهول',
      userEmail: user.email,
      action: 'PASSWORD_RESET_REQUESTED',
      timestamp: new Date().toISOString(),
      details: 'تم إرسال رابط آمن لإعادة تعيين كلمة المرور عبر نظام بريد Firebase المعتمد',
      ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
      userAgent: req.headers['user-agent'] || 'Unknown'
    });
    
    writeDB(db);
    res.json({
      success: true,
      message: `تم إرسال تعليمات إعادة تعيين الرقم السري بنجاح إلى البريد: ${user.email}. يرجى مراجعة صندوق الوارد والبريد غير الهام (Junk/Spam).`
    });
  });

  // API Route - Retrieve Security Audits for Supervisor Dashboard
  app.get('/api/admin/audit-logs', requireAdmin, (req, res) => {
    const db = readDB();
    if (!db.auditLogs) db.auditLogs = [];
    res.json(db.auditLogs);
  });

  // API Route - Aggregate platform statistics for the exportable report
  app.get('/api/admin/stats', requireAdmin, (req, res) => {
    const db = readDB();
    const users = db.users || [];
    const auditLogs = db.auditLogs || [];
    const trackingLogs = Object.values(db.trackingLogs || {}) as any[];

    const totalUsers = users.length;
    const totalAdmins = users.filter(u => u.role === 'admin').length;
    const totalStudents = totalUsers - totalAdmins;

    const now = Date.now();
    const DAY = 24 * 60 * 60 * 1000;
    const activeToday = trackingLogs.filter(l => l.lastActive && (now - new Date(l.lastActive).getTime()) < DAY).length;
    const activeThisWeek = trackingLogs.filter(l => l.lastActive && (now - new Date(l.lastActive).getTime()) < 7 * DAY).length;

    const totalLogins = auditLogs.filter(l => l.action === 'LOGIN' || l.action === 'LOGIN_GOOGLE').length;
    const totalRegistrations = auditLogs.filter(l => l.action === 'REGISTRATION').length;

    // Build a 30-day daily series of new registrations and logins for the chart
    const days: { date: string; registrations: number; logins: number }[] = [];
    for (let i = 29; i >= 0; i--) {
      const dayStart = new Date(now - i * DAY);
      const dayKey = dayStart.toISOString().slice(0, 10);
      days.push({ date: dayKey, registrations: 0, logins: 0 });
    }
    const dayIndex: Record<string, number> = {};
    days.forEach((d, idx) => { dayIndex[d.date] = idx; });

    auditLogs.forEach((log: any) => {
      if (!log.timestamp) return;
      const key = new Date(log.timestamp).toISOString().slice(0, 10);
      const idx = dayIndex[key];
      if (idx === undefined) return;
      if (log.action === 'REGISTRATION') days[idx].registrations += 1;
      if (log.action === 'LOGIN' || log.action === 'LOGIN_GOOGLE') days[idx].logins += 1;
    });

    // Breakdown of users by academic year / stage, for a pie-style summary
    const byAcademicYear: Record<string, number> = {};
    users.forEach(u => {
      const key = u.academicYear || 'غير محدد';
      byAcademicYear[key] = (byAcademicYear[key] || 0) + 1;
    });

    res.json({
      generatedAt: new Date().toISOString(),
      totalUsers,
      totalAdmins,
      totalStudents,
      activeToday,
      activeThisWeek,
      totalLogins,
      totalRegistrations,
      dailySeries: days,
      byAcademicYear
    });
  });

  // API Route - Change Own Password
  app.post('/api/auth/change-password', requireAuth, (req, res) => {
    const { currentPassword, newPassword } = sanitizeInput(req.body);
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: 'الرجاء ملء جميع حقول تغيير كلمة المرور' });
    }
    const db = readDB();
    const user = db.users.find(u => u.id === (req as any).currentUser.id);
    if (!user) {
      return res.status(404).json({ error: 'المستخدم غير موجود' });
    }
    if (!verifyPassword(currentPassword, user.password)) {
      return res.status(400).json({ error: 'كلمة المرور الحالية غير صحيحة' });
    }
    
    user.password = hashPassword(newPassword);
    db.auditLogs.unshift({
      id: 'audit-' + Date.now(),
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      action: 'CREDENTIALS_CHANGED',
      timestamp: new Date().toISOString(),
      details: 'تم تحديث الرقم السري لبريد الإشراف مع التشفير الأمني الكامل بنجاح',
      ipAddress: req.ip || req.headers['x-forwarded-for'] || '127.0.0.1',
      userAgent: req.headers['user-agent'] || 'Unknown'
    });

    writeDB(db);
    res.json({ success: true, message: 'تم تحديث كلمة المرور بنجاح' });
  });

  // API Route - Receive active/page usage clicks tracking
  app.post('/api/track/activity', (req, res) => {
    const { userId, action, pageName, platformId, platformName, details } = req.body;
    if (!userId) return res.sendStatus(400);

    const db = readDB();
    const log = db.trackingLogs[userId];
    if (log) {
      log.lastActive = new Date().toISOString();
      log.dailyUsageCount += 1;
      
      const timelineAction = action === 'view_page' ? `زيارة صفحة: ${pageName}` 
                         : action === 'click_platform' ? `زيارة منصة رقمية: ${platformName}`
                         : action;

      log.activityTimeline.unshift({
        action: timelineAction,
        timestamp: new Date().toISOString(),
        details: details || `تم تصفح التطبيق بنجاح`
      });

      // Unlimited timeline log history as requested by the user
      // No truncation to 50 entries anymore

      // If they clicked on a digital platform, increment its click counter
      if (action === 'click_platform' && platformId) {
        if (!log.platformStays[platformId]) {
          log.platformStays[platformId] = {
            platformId,
            platformName,
            entriesCount: 0,
            durationSeconds: 0
          };
        }
        log.platformStays[platformId].entriesCount += 1;
      }

      writeDB(db);
    }
    res.json({ success: true });
  });

  // API Route - Heartbeat ping sends periodically to track duration inside platform
  app.post('/api/track/heartbeat', (req, res) => {
    const { userId, platformId, platformName, seconds } = req.body;
    if (!userId) return res.sendStatus(400);

    const db = readDB();
    const log = db.trackingLogs[userId];
    const duration = Number(seconds) || 5;

    if (log) {
      log.lastActive = new Date().toISOString();
      log.totalActiveTimeSeconds += duration;

      if (platformId && platformName) {
        if (!log.platformStays[platformId]) {
          log.platformStays[platformId] = {
            platformId,
            platformName,
            entriesCount: 1,
            durationSeconds: 0
          };
        }
        log.platformStays[platformId].durationSeconds += duration;
      }

      writeDB(db);
    }
    res.json({ success: true });
  });

  // API Route - Get all tracking metrics & user lists for admin control panel
  app.get('/api/admin/tracking', requireAdmin, (req, res) => {
    const db = readDB();
    // Return combined users and log metrics
    const list = Object.values(db.trackingLogs);
    res.json(list);
  });

  // AI API Route - Summarizer (Thaker summarizing engineering files/texts)
  app.post('/api/ai/summarize', async (req, res) => {
    const { text, type } = req.body;
    if (!text) {
      return res.status(400).json({ error: 'لا يوجد نص لتلخيصه' });
    }

    if (!geminiApiKey) {
      return res.status(503).json({
        error: 'مفتاح ذكاء جيميناي غير مهيأ حالياً. قم بوضعه في لوحة Secrets.'
      });
    }

    try {
      const systemInstruction = `
        أنت رائد تكنولوجيا ومهندس كيميائي متميز تعمل كخبير محتوى لمنصة "الهيئة العامة للمهندسين الكيميائيين في البصرة".
        مهمتك هي تلخيص النص الهندسي الكيميائي المدخل باللغة العربية بأسلوب علمي رصين ومرتب جداً ومفيد للطلبة.
        قم بتقسيمه إلى:
        1. الخلاصة العامة (بفقرة أو فقرتين).
        2. المصطلحات والرموز الكيميائية الرئيسية المذكورة ومعانيها.
        3. أهم المعادلات والقواعد أو الخطوات الصناعية الموضحة في النص.
        4. استنتاجات هندسية ونصائح للعمليات الكيميائية أو السلامة المهنية.
        إذا كان النص غير مرتبط بالهندسة الكيميائية أو الكيمياء أو العلوم التطبيقية، فقم مع ذلك بتلخيصه بأناقة، لكن ركّز على صياغة المنظور العلمي المناسب.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: [
          { role: 'user', parts: [{ text: `${systemInstruction}\n\nالنص المطلوب تلخيصه:\n${text}` }] }
        ]
      });

      const summaryText = response.text || '';
      res.json({ summary: summaryText });
    } catch (err: any) {
      console.error('Gemini error during summarization:', err);
      res.status(500).json({ error: `حدث خطأ في جيميناي أثناء تلخيص الملف: ${err?.message || err}` });
    }
  });

  // AI API Route - Simulated Chemical Engineering Interview Helper
  app.post('/api/ai/interview', async (req, res) => {
    const { topic, messages } = req.body;
    // messages: array of { role: 'user' | 'assistant' | 'system', content: string }
    
    if (!topic) {
      return res.status(400).json({ error: 'موضوع المقابلة مطلوب' });
    }

    if (!geminiApiKey) {
      return res.status(503).json({
        error: 'مفتاح ذكاء جيميناي غير مهيأ حالياً. قم بوضعه في لوحة Secrets.'
      });
    }

    try {
      const formattedHistory = messages.map((m: any) => `${m.role === 'user' ? 'المرشح (الطالب)' : 'المقابل المهندس'}: ${m.content}`).join('\n');

      const prompt = `
        أنت مهندس مقابلات كيميائي رئيسي في لجنة التوظيف في "الهيئة العامة للمهندسين الكيميائيين في البصرة".
        أنت تجري مقابلة عمل تقنية علمية صارمة ولكنها تدريبية وتفاعلية لطالب أو خريج هندسة كيميائية بالبصرة.
        الموضوع المختار للمقابلة: "${topic}".
        
        تاريخ الحوار الحالي حتى الآن:
        ${formattedHistory}
        
        المهمة المطلوبة منك:
        1. قم بالرد على إجابة المرشح الأخيرة (إذا وجد حوار سابق). قيّم مهاراته ومستواه بكل احترام ومهنية واذكر الإجابة الصحيحة أو الإضافات العلمية الهامة بلغة عربية سليمة.
        2. اسأل المرشح سؤالاً علمياً كيميائياً واحداً فقط يتعلق بموضوع المقابلة "${topic}"، واجعل السؤال مناسباً لمستوى المقابلات في الشركات العالمية والمحلية بالبصرة مثل شركة غاز البصرة BGC أو شركة مصافي الجنوب أو شركة الاستكشافات النفطية.
        3. اجعل الأسلوب تشجيعياً، تفاعلياً، وبناءً لتعلم الطلبة، واختم الحديث بالسؤال دائماً.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: [
          { role: 'user', parts: [{ text: prompt }] }
        ]
      });

      const aiReply = response.text || '';
      res.json({ reply: aiReply });
    } catch (err: any) {
      console.error('Gemini error during interview prep:', err);
      res.status(500).json({ error: `حدث خطأ في جيميناي أثناء التحضير للمقابلة: ${err?.message || err}` });
    }
  });


  // Serve static assets or use Vite in dev mode
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
