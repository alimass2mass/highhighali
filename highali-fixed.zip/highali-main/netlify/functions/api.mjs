// Single backend endpoint for the whole app. Replaces Firebase entirely.
// Storage: Netlify Blobs (built into every Netlify site, zero setup, no
// external account, no security-rules console). Everything lives in one
// JSON document so it behaves exactly like the old database.json file did,
// except it now persists correctly on Netlify's serverless functions.
import { getStore } from '@netlify/blobs';
import crypto from 'crypto';

const STORE_NAME = 'highali-db';
const ENTRIES_STORE = 'highali-entries'; // separate, append-only, never touched by any delete/reset logic
const KEY = 'state';

// ---------------------------------------------------------------------------
// Server-signed session tokens (replaces "trust whatever the client sends").
// The client can no longer claim to be an admin — only this server, using a
// secret it alone holds, can produce a token that says role: 'admin', and
// every admin-only action below re-checks that signature on every request.
// ---------------------------------------------------------------------------
const SESSION_SECRET = process.env.SESSION_SECRET;
// A real secret baked in so this works immediately with zero setup. If you
// ever want to rotate it, set a SESSION_SECRET environment variable in your
// Netlify site settings — that will automatically take priority over this.
const BUILT_IN_SECRET = '601201f6348dbd1d3e00f1fc46a8cae7f39230ce32f5df5c1f740b1cc60e954a';
const EFFECTIVE_SECRET = SESSION_SECRET || BUILT_IN_SECRET;
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

function b64url(buf) {
  return Buffer.from(buf).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function signToken(payload) {
  const body = b64url(JSON.stringify(payload));
  const sig = crypto.createHmac('sha256', EFFECTIVE_SECRET).update(body).digest();
  return `${body}.${b64url(sig)}`;
}
function verifyToken(token) {
  if (!token || typeof token !== 'string' || !token.includes('.')) return null;
  const [body, sig] = token.split('.');
  const expected = b64url(crypto.createHmac('sha256', EFFECTIVE_SECRET).update(body).digest());
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8'));
    if (!payload.exp || Date.now() > payload.exp) return null;
    return payload; // { uid, role, exp }
  } catch {
    return null;
  }
}

// Actions that must only ever be performed by a verified admin. Role is
// read from the signed token (re-checked against the live user record),
// never from anything the client sends in the request body.
const ADMIN_ACTIONS = new Set([
  'create_platform', 'update_platform', 'delete_platform', 'reorder_platforms',
  'create_course', 'update_course', 'delete_course', 'reorder_courses',
  'create_resource', 'update_resource', 'delete_resource', 'reorder_resources',
  'update_accounts',
  'fetch_tracking_logs', 'fetch_audit_logs', 'fetch_permanent_entries', 'fetch_admin_stats',
  'create_notification', 'delete_notification',
  'create_news', 'delete_news', 'delete_news_comment'
]);

function seedState() {
  return {
    users: [], // { id, slug, name, pin: "salt:hash", role, academicYear, createdAt }
    platforms: [
      { id: 'detergents-lab', name: 'مختبر انتاج المنظفات', url: 'https://ais-pre-oz2lnw2v5izn7sw74dre7l-501029547945.europe-west1.run.app/', image: 'https://images.unsplash.com/photo-1607613009820-a29f7bb81c04?w=500&auto=format&fit=crop&q=60', description: 'دليل عملي وتفاعلي لشرح كيمياء السطح وتصنيع الصابون السائل والمطهرات والمعقمات التجارية وفق المواصفة العراقية.', isSystem: true, order: 1 },
      { id: 'hplc-sim-lab', name: 'مختبر محاكي جهاز HPLC', url: 'https://taupe-liger-42ce91.netlify.app/', image: 'https://images.unsplash.com/photo-1532187863486-abf9d39d66e8?w=500&auto=format&fit=crop&q=60', description: 'تطبيق محاكاة هندسي كيميائي تفاعلي لفهم خطوات تشغيل جهاز الكروماتوغرافيا السائلة عالية الأداء HPLC.', isSystem: true, order: 2 },
      { id: 'cosmetics-lab', name: 'مختبر علوم التجميل', url: 'https://statuesque-speculoos-eca636.netlify.app/', image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=500&auto=format&fit=crop&q=60', description: 'دراسة وتطبيق تراكيب المستحلبات، الكريمات المرطبة، السيروم المغذي والمستحضرات التجميلية المتطورة.', isSystem: true, order: 3 },
      { id: 'uv-vis-lab', name: 'مختبر جهاز Uv visible', url: 'https://magnificent-tarsier-50e394.netlify.app/', image: 'https://images.unsplash.com/photo-1576086213369-97a306dca665?w=500&auto=format&fit=crop&q=60', description: 'محاكاة وإرشادات لإجراء الفحوصات الطيفية وامتصاص السوائل وقياس متبقيات المواد الكيميائية بدقة.', isSystem: true, order: 4 },
      { id: 'assistant-bot', name: 'البوت الرقمي', url: 'https://share.google/4NvoZbQlQnklDfQdb', image: 'https://images.unsplash.com/photo-1531747118685-ca8fa6e08806?w=500&auto=format&fit=crop&q=60', description: 'مساعد ذكي مخصص للإجابة على تساؤلات المهندسين الكيميائيين في البصرة.', isSystem: true, order: 5 },
      { id: 'thaker-summarizer', name: 'منصة ذاكر الهندسية لتلخيص الملفات', url: 'https://spiffy-pie-2f4a6c.netlify.app/', image: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=500&auto=format&fit=crop&q=60', description: 'نظام مدعوم بالذكاء الاصطناعي لتلخيص الأبحاث الهندسية والكتب الكيميائية الضخمة.', isSystem: true, order: 6 },
      { id: 'interview-prep', name: 'منصة المقابلات الهندسية', url: 'embedded', image: 'https://images.unsplash.com/photo-1521791136368-1a46827d52bf?w=500&auto=format&fit=crop&q=60', description: 'تساعد الطلبة على التحضير لمقابلات العمل في شركات جولات التراخيص والشركات النفطية.', isSystem: true, order: 7 }
    ],
    courses: [
      { id: 'course-1', title: 'دورة هندسة الغاز الطبيعي وعمليات تسييل الغاز LNG', url: 'https://gce-basra.org/courses/gas-engineering', description: 'تغطي الدورة عمليات المعالجة، إزالة الشوائب، وعمليات التجفيف والتبريد.', instructor: 'أ. د. كريم جابر البصري', addedAt: '2026-06-01T10:00:00Z', order: 1 },
      { id: 'course-2', title: 'تصنيع وتطوير المنظفات الكيميائية والمطهرات المنزلية', url: 'https://gce-basra.org/courses/detergent-manufacturing', description: 'دورة عملية شاملة لتركيب وتصنيع مختلف أنواع الشامبو والصابون السائل.', instructor: 'م. علي السعدي', addedAt: '2026-06-03T11:30:00Z', order: 2 },
      { id: 'course-3', title: 'تطبيقات الكروماتوغرافيا السائلة وفحوصات الدواء والمياه', url: 'https://gce-basra.org/courses/hplc-analysis', description: 'مبادئ التحليل الكروماتوغرافي وطرق معايرة الأجهزة الكيميائية الحساسة.', instructor: 'د. ليلى شاكر محمد', addedAt: '2026-06-05T09:12:00Z', order: 3 }
    ],
    resources: [
      { id: 'resource-1', title: "Perry's Chemical Engineers' Handbook (9th Edition)", category: 'كتب ومناهج أساسية', description: 'المرجع الأهم والشامل لكافة العمليات الكيميائية وموازين المادة.', url: 'https://gce-basra.org/storage/perry-handbook-9e.pdf', fileName: 'perrys_chemical_handbook_9th.pdf', fileSize: 256870912, addedAt: '2026-06-02T14:20:00Z', order: 1 },
      { id: 'resource-2', title: 'Chemical Engineering Volume 6: Design - Sinnott', category: 'تصميم المصانع والمفاعلات', description: 'كتاب منهجي لتصميم المبادلات الحرارية، أبراج التقطير والمفاعلات الكيميائية.', url: 'https://gce-basra.org/storage/chemical-design-v6.pdf', fileName: 'chem_engineering_design_sinnott.pdf', fileSize: 196083712, addedAt: '2026-06-04T16:30:00Z', order: 2 }
    ],
    accounts: {
      telegram: 'https://t.me/chemicallyengineer', instagram: 'https://www.instagram.com/chemical_authority', facebook: 'https://facebook.com/GeneralChemBAS', whatsapp: '', youtube: 'https://youtube.com/@GeneralChemBAS', linkedin: '', website: 'https://gce-basra.org', telegramGot: 'https://t.me/GoT_information', instagramGot: '', telegramTrainee: 'https://t.me/chemicaltrainee'
    },
    news: [],
    notifications: [],
    trackingLogs: {},
    auditLogs: []
  };
}

function hashPin(pin, existingSalt) {
  const salt = existingSalt || crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(pin, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}
function verifyPin(pin, stored) {
  if (!stored || !stored.includes(':')) return false;
  const [salt, hash] = stored.split(':');
  const derived = crypto.scryptSync(pin, salt, 64).toString('hex');
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(derived, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
const genId = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
const slugify = (name) => name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'user';
const publicUser = (u) => { const { pin, ...rest } = u; return rest; };

async function getState(store) {
  const state = await store.get(KEY, { type: 'json' });
  return state || seedState();
}
async function saveState(store, state) {
  await store.setJSON(KEY, state);
}

// Permanently records one entry (registration or login) as its own
// independent key in a separate store. Nothing in this file ever deletes
// from ENTRIES_STORE or overwrites an existing key in it — nothing can
// ever wipe or shrink this history, even 10 years from now.
async function recordEntryForever(entriesStore, entry) {
  const key = `${entry.timestamp}__${entry.userId}__${genId()}`;
  await entriesStore.setJSON(key, entry);
}

export default async (req) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405 });
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: 'Invalid JSON body' }), { status: 400 });
  }

  const { action, payload = {}, token } = body;
  const store = getStore(STORE_NAME);
  const entriesStore = getStore(ENTRIES_STORE);
  const state = await getState(store);
  let changed = false;

  const reply = (data, status = 200) => new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' }
  });

  // Verify the caller's session token (if any). The role inside it was
  // decided by this server at login time and can't be forged by the client.
  const session = verifyToken(token);

  if (ADMIN_ACTIONS.has(action)) {
    // Re-check against the *live* user record too, in case an admin was
    // demoted after their token was issued.
    const liveUser = session && state.users.find(u => u.id === session.uid);
    if (!session || !liveUser || liveUser.role !== 'admin') {
      return reply({ error: 'forbidden' }, 403);
    }
  }

  try {
    switch (action) {
      // ---------------- Auth (replaces Firebase Auth) ----------------
      case 'auth': {
        const name = String(payload.name || '').trim().replace(/\s+/g, ' ');
        const pin = String(payload.pin || '');
        if (!name || !/^\d{4}$/.test(pin)) return reply({ error: 'invalid_input' }, 400);
        const slug = slugify(name);
        const existing = state.users.find(u => u.slug === slug);
        const now = new Date().toISOString();

        if (!existing) {
          const isAdmin = payload.adminInviteCode && process.env.ADMIN_INVITE_CODE && payload.adminInviteCode === process.env.ADMIN_INVITE_CODE;
          const user = {
            id: genId(),
            slug,
            name,
            pin: hashPin(pin),
            role: isAdmin ? 'admin' : 'student',
            academicYear: 'طالب هندسة كيميائية بالبصرة',
            createdAt: now
          };
          state.users.push(user);
          state.auditLogs.unshift({ id: genId(), userId: user.id, userName: name, userEmail: `${slug}@highali.local`, action: 'REGISTRATION', timestamp: now, details: 'إنشاء حساب جديد باسم رباعي فريد ورمز دخول من 4 أرقام' });
          await recordEntryForever(entriesStore, { userId: user.id, userName: name, action: 'REGISTRATION', timestamp: now });
          state.trackingLogs[user.id] = {
            userId: user.id, userName: name, userEmail: `${slug}@highali.local`, role: user.role,
            registrationDate: now, lastActive: now, dailyUsageCount: 1, totalActiveTimeSeconds: 0,
            platformStays: {}, activityTimeline: [{ action: 'REGISTRATION', timestamp: now }]
          };
          changed = true;
          await saveState(store, state);
          const token = signToken({ uid: user.id, role: user.role, exp: Date.now() + SESSION_TTL_MS });
          return reply({ user: { ...publicUser(user), token } });
        } else {
          if (!verifyPin(pin, existing.pin)) return reply({ error: 'wrong_pin' }, 401);
          existing.role = existing.role; // no-op, keep as is
          state.auditLogs.unshift({ id: genId(), userId: existing.id, userName: existing.name, userEmail: `${slug}@highali.local`, action: 'LOGIN_SUCCESS', timestamp: now, details: 'تسجيل دخول عبر الاسم والرمز الرباعي' });
          await recordEntryForever(entriesStore, { userId: existing.id, userName: existing.name, action: 'LOGIN_SUCCESS', timestamp: now });
          const log = state.trackingLogs[existing.id];
          if (log) {
            log.lastActive = now;
            log.dailyUsageCount = (log.dailyUsageCount || 0) + 1;
            log.activityTimeline = [...(log.activityTimeline || []), { action: 'LOGIN_SUCCESS', timestamp: now }];
          } else {
            state.trackingLogs[existing.id] = {
              userId: existing.id, userName: existing.name, userEmail: `${slug}@highali.local`, role: existing.role,
              registrationDate: existing.createdAt, lastActive: now, dailyUsageCount: 1, totalActiveTimeSeconds: 0,
              platformStays: {}, activityTimeline: [{ action: 'LOGIN_SUCCESS', timestamp: now }]
            };
          }
          changed = true;
          await saveState(store, state);
          const token = signToken({ uid: existing.id, role: existing.role, exp: Date.now() + SESSION_TTL_MS });
          return reply({ user: { ...publicUser(existing), token } });
        }
      }

      // ---------------- Platforms / Courses / Resources ----------------
      case 'fetch_platforms': return reply(state.platforms.sort((a, b) => (a.order ?? 0) - (b.order ?? 0)));
      case 'fetch_courses': return reply(state.courses.sort((a, b) => (a.order ?? 0) - (b.order ?? 0)));
      case 'fetch_resources': return reply(state.resources.sort((a, b) => (a.order ?? 0) - (b.order ?? 0)));

      case 'create_platform': state.platforms.push({ id: genId(), ...payload, order: Date.now() }); changed = true; break;
      case 'update_platform': { const p = state.platforms.find(x => x.id === payload.id); if (p) Object.assign(p, payload.updated); changed = true; break; }
      case 'delete_platform': state.platforms = state.platforms.filter(x => x.id !== payload.id); changed = true; break;
      case 'reorder_platforms': payload.ids.forEach((id, i) => { const p = state.platforms.find(x => x.id === id); if (p) p.order = i; }); changed = true; break;

      case 'create_course': state.courses.push({ id: genId(), ...payload, order: Date.now(), addedAt: new Date().toISOString() }); changed = true; break;
      case 'update_course': { const c = state.courses.find(x => x.id === payload.id); if (c) Object.assign(c, payload.updated); changed = true; break; }
      case 'delete_course': state.courses = state.courses.filter(x => x.id !== payload.id); changed = true; break;
      case 'reorder_courses': payload.ids.forEach((id, i) => { const c = state.courses.find(x => x.id === id); if (c) c.order = i; }); changed = true; break;

      case 'create_resource': state.resources.push({ id: genId(), ...payload, order: Date.now(), addedAt: new Date().toISOString() }); changed = true; break;
      case 'update_resource': { const r = state.resources.find(x => x.id === payload.id); if (r) Object.assign(r, payload.updated); changed = true; break; }
      case 'delete_resource': state.resources = state.resources.filter(x => x.id !== payload.id); changed = true; break;
      case 'reorder_resources': payload.ids.forEach((id, i) => { const r = state.resources.find(x => x.id === id); if (r) r.order = i; }); changed = true; break;

      // ---------------- Accounts ----------------
      case 'fetch_accounts': return reply(state.accounts);
      case 'update_accounts': state.accounts = { ...state.accounts, ...payload }; changed = true; break;

      // ---------------- Activity tracking / entry log ----------------
      case 'log_activity': {
        const { userId, userName, userEmail, role, action: act, details } = payload;
        const now = new Date().toISOString();
        const entry = { action: act, timestamp: now, details: details || '' };
        const log = state.trackingLogs[userId];
        if (!log) {
          state.trackingLogs[userId] = { userId, userName, userEmail, role, registrationDate: now, lastActive: now, dailyUsageCount: 1, totalActiveTimeSeconds: 0, platformStays: {}, activityTimeline: [entry] };
        } else {
          log.lastActive = now;
          log.dailyUsageCount = (log.dailyUsageCount || 0) + 1;
          log.activityTimeline = [...(log.activityTimeline || []), entry];
        }
        changed = true;
        break;
      }
      case 'log_heartbeat': {
        const { userId, platformId, platformName, seconds } = payload;
        const log = state.trackingLogs[userId];
        if (log) {
          log.lastActive = new Date().toISOString();
          log.totalActiveTimeSeconds = (log.totalActiveTimeSeconds || 0) + seconds;
          if (platformId) {
            const existing = log.platformStays[platformId] || { platformId, platformName: platformName || '', entriesCount: 0, durationSeconds: 0 };
            log.platformStays[platformId] = { ...existing, platformName: platformName || existing.platformName, durationSeconds: (existing.durationSeconds || 0) + seconds };
          }
          changed = true;
        }
        break;
      }
      case 'fetch_tracking_logs': return reply(Object.values(state.trackingLogs));

      // ---------------- Audit log (who entered, when) ----------------
      case 'log_audit': state.auditLogs.unshift({ id: genId(), ...payload, timestamp: new Date().toISOString() }); changed = true; break;
      case 'fetch_audit_logs': return reply(state.auditLogs.slice(0, payload.max || 300));

      // Full permanent history of every login/registration, ever. There is
      // deliberately no "delete" or "clear" action for this anywhere in this
      // file — it only ever grows.
      case 'fetch_permanent_entries': {
        const { blobs } = await entriesStore.list();
        const keys = blobs.map(b => b.key).sort(); // chronological, since key starts with the ISO timestamp
        const entries = await Promise.all(keys.map(k => entriesStore.get(k, { type: 'json' })));
        return reply({ total: entries.length, entries });
      }

      // ---------------- Admin dashboard stats ----------------
      case 'fetch_admin_stats': {
        const users = state.users.map(publicUser);
        const totalUsers = users.length;
        const totalStudents = users.filter(u => u.role === 'student').length;
        const trackingLogs = Object.values(state.trackingLogs);
        const now = Date.now();
        const dayMs = 24 * 60 * 60 * 1000;
        const activeToday = trackingLogs.filter(l => now - new Date(l.lastActive).getTime() < dayMs).length;
        const activeThisWeek = trackingLogs.filter(l => now - new Date(l.lastActive).getTime() < 7 * dayMs).length;
        const totalLogins = trackingLogs.reduce((sum, l) => sum + (l.dailyUsageCount || 0), 0);
        const totalRegistrations = state.auditLogs.filter(a => a.action === 'REGISTRATION').length;
        const byAcademicYear = {};
        users.forEach(u => { const key = u.academicYear || 'غير محدد'; byAcademicYear[key] = (byAcademicYear[key] || 0) + 1; });
        const dailyMap = {}; const days = [];
        for (let i = 13; i >= 0; i--) { const d = new Date(now - i * dayMs); const key = d.toISOString().slice(0, 10); days.push(key); dailyMap[key] = 0; }
        state.auditLogs.forEach(a => { if (a.action !== 'REGISTRATION' && a.action !== 'LOGIN_SUCCESS') return; const key = String(a.timestamp).slice(0, 10); if (key in dailyMap) dailyMap[key] += 1; });
        const dailySeries = days.map(day => ({ date: day, count: dailyMap[day] }));
        return reply({ generatedAt: new Date().toISOString(), totalUsers, totalStudents, activeToday, activeThisWeek, totalRegistrations, totalLogins, dailySeries, byAcademicYear });
      }

      case 'change_pin': {
        const u = state.users.find(x => x.id === payload.id);
        if (!u) return reply({ error: 'not_found' }, 404);
        if (!verifyPin(String(payload.currentPin || ''), u.pin)) return reply({ error: 'wrong_pin' }, 401);
        if (!/^\d{4}$/.test(String(payload.newPin || ''))) return reply({ error: 'invalid_pin' }, 400);
        u.pin = hashPin(String(payload.newPin));
        changed = true;
        await saveState(store, state);
        return reply({ ok: true });
      }

      case 'update_user': {
        const u = state.users.find(x => x.id === payload.id);
        if (!u) return reply({ error: 'not_found' }, 404);
        // Only the account owner (proven via their signed token) or an
        // admin may update a profile — and `role` is never accepted here,
        // even from an admin. There is deliberately no path in this API
        // that lets a request body grant someone the admin role.
        const isSelf = session && session.uid === u.id;
        const isAdmin = session && session.role === 'admin' && state.users.some(x => x.id === session.uid && x.role === 'admin');
        if (!isSelf && !isAdmin) return reply({ error: 'forbidden' }, 403);
        const { pin, id, slug, role, ...safeUpdates } = payload.updates || {};
        Object.assign(u, safeUpdates);
        changed = true;
        await saveState(store, state);
        return reply({ user: publicUser(u) });
      }

      // ---------------- Notifications ----------------
      case 'fetch_notifications': return reply(state.notifications.slice().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 200));
      case 'create_notification': state.notifications.push({ id: genId(), ...payload, createdAt: new Date().toISOString(), isRead: [] }); changed = true; break;
      case 'delete_notification': state.notifications = state.notifications.filter(n => n.id !== payload.id); changed = true; break;
      case 'mark_notification_read': { const n = state.notifications.find(x => x.id === payload.id); if (n) { n.isRead = Array.from(new Set([...(n.isRead || []), payload.userId])); changed = true; } break; }
      case 'mark_all_notifications_read': payload.ids.forEach(id => { const n = state.notifications.find(x => x.id === id); if (n) n.isRead = Array.from(new Set([...(n.isRead || []), payload.userId])); }); changed = true; break;

      // ---------------- News ----------------
      case 'fetch_news': return reply(state.news.slice().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 100));
      case 'create_news': state.news.push({ id: genId(), ...payload, createdAt: new Date().toISOString(), comments: [] }); changed = true; break;
      case 'delete_news': state.news = state.news.filter(n => n.id !== payload.id); changed = true; break;
      case 'add_news_comment': {
        const post = state.news.find(n => n.id === payload.postId);
        const comment = { id: genId(), createdAt: new Date().toISOString(), ...payload.comment };
        if (post) { post.comments = [...(post.comments || []), comment]; changed = true; }
        await saveState(store, state);
        return reply(comment);
      }
      case 'delete_news_comment': { const post = state.news.find(n => n.id === payload.postId); if (post) { post.comments = (post.comments || []).filter(c => c.id !== payload.commentId); changed = true; } break; }

      default:
        return reply({ error: 'unknown_action' }, 400);
    }

    if (changed) await saveState(store, state);
    return reply({ ok: true });
  } catch (err) {
    return reply({ error: 'server_error', message: String(err && err.message || err) }, 500);
  }
};
