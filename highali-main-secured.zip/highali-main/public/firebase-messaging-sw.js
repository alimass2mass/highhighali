importScripts('https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.23.0/firebase-messaging-compat.js');

// Initialize the Firebase app in the service worker
const firebaseConfig = {
  apiKey: "AIzaSyC1rCHlHJZjVS2DSyv4EKqAZN8gidLM0L8",
  authDomain: "gen-lang-client-0761662384.firebaseapp.com",
  projectId: "gen-lang-client-0761662384",
  storageBucket: "gen-lang-client-0761662384.firebasestorage.app",
  messagingSenderId: "72670301007",
  appId: "1:72670301007:web:40e24a406d096751d1533a"
};

firebase.initializeApp(firebaseConfig);

const messaging = firebase.messaging();

// Handle background messages
messaging.onBackgroundMessage((payload) => {
  console.log('[firebase-messaging-sw.js] Received background message: ', payload);
  const notificationTitle = payload.notification?.title || payload.data?.title || 'إشعار جديد من المنصة الهندسية بالبصرة';
  const notificationOptions = {
    body: payload.notification?.body || payload.data?.message || payload.data?.body || '',
    icon: 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=128',
    data: {
      url: payload.data?.click_action || payload.data?.url || '/'
    }
  };

  self.registration.showNotification(notificationTitle, notificationOptions);
});

// Handle notification click to open window
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const urlToOpen = event.notification.data?.url || '/';

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windowClients) => {
      for (let i = 0; i < windowClients.length; i++) {
        const client = windowClients[i];
        if (client.url === urlToOpen && 'focus' in client) {
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow(urlToOpen);
      }
    })
  );
});
