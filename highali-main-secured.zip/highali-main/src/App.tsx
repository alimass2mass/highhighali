/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import HomeSection from './components/HomeSection';
import PlatformsSection from './components/PlatformsSection';
import CoursesSection from './components/CoursesSection';
import ResourcesSection from './components/ResourcesSection';
import NewsSection from './components/NewsSection';
import AccountsSection from './components/AccountsSection';
import AboutSection from './components/AboutSection';
import AdminSection from './components/AdminSection';
import SecuritySettingsSection from './components/SecuritySettingsSection';
import AuthPage from './components/AuthPage';
import LocalHelpBot from './components/LocalHelpBot';
import HeaderNotifications from './components/HeaderNotifications';
import NotificationsSection from './components/NotificationsSection';
import ToastContainer, { triggerToast } from './components/ToastContainer';
import { getApiUrl } from './lib/api';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { auth, isFirebaseValid } from './lib/firebase';

import { Menu, Landmark, Download, Smartphone, Laptop, HelpCircle, X, ChevronLeft, ChevronRight, Mail } from 'lucide-react';
import { User, DigitalPlatform, Course, EngineeringResource, AuthorityAccounts } from './types';
import { LanguageType, locales } from './locales';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeSection, setActiveSection] = useState<string>('home');
  const [isAuthLoading, setIsAuthLoading] = useState(true);

  // Theme Management (Light vs Dark mode)
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  // Progressive Web App (PWA) Install Trigger Handles
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isPwaInstalled, setIsPwaInstalled] = useState(false);
  const [showPwaTutorial, setShowPwaTutorial] = useState(false);

  // Multi-language state management
  const [lang, setLang] = useState<LanguageType>('ar');
  const t = locales[lang];

  // Mobile sidebar visibility toggle drawer
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Core synchronized server-side state databases
  const [platforms, setPlatforms] = useState<DigitalPlatform[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [resources, setResources] = useState<EngineeringResource[]>([]);
  const [accounts, setAccounts] = useState<AuthorityAccounts | null>(null);

  // Load Session from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem('gce_basra_user');
      if (stored) {
        setCurrentUser(JSON.parse(stored));
      }
      
      // Load saved language preference if any
      const storedLang = localStorage.getItem('gce_basra_lang');
      if (storedLang && ['ar', 'en', 'de', 'es'].includes(storedLang)) {
        setLang(storedLang as LanguageType);
      }

      // Load saved theme preference
      const storedTheme = localStorage.getItem('gce_basra_theme');
      if (storedTheme === 'light' || storedTheme === 'dark') {
        setTheme(storedTheme);
      }
    } catch (err) {
      console.error('Error reading persistent session:', err);
    } finally {
      setIsAuthLoading(false);
    }
  }, []);

  // Silent Google session restore.
  // Firebase Auth persists the signed-in Google identity in the browser
  // indefinitely (until the person explicitly signs out), independent of
  // our own app session. If Firebase still recognizes a Google identity on
  // this device, we quietly mint/refresh our own backend session token in
  // the background — the person never has to re-enter email/password.
  useEffect(() => {
    if (!isFirebaseValid) return;
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (!firebaseUser) return;
      try {
        const idToken = await firebaseUser.getIdToken();
        const res = await fetch(getApiUrl('/api/auth/google-session'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ idToken })
        });
        const data = await res.json();
        if (res.ok && !data.require2Fa) {
          localStorage.setItem('gce_basra_user', JSON.stringify(data));
          setCurrentUser(data);
        }
        // If 2FA is required, or the request fails, we simply leave the
        // person on the normal login screen — no silent takeover of an
        // account that needs a second factor.
      } catch (err) {
        console.error('Silent Google session refresh failed:', err);
      }
    });
    return () => unsubscribe();
  }, []);

  // Save language preference when toggled
  const handleLanguageChange = (newLang: LanguageType) => {
    setLang(newLang);
    localStorage.setItem('gce_basra_lang', newLang);
  };

  // Toggle Theme Mode Function
  const handleThemeToggle = () => {
    const nextTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(nextTheme);
    localStorage.setItem('gce_basra_theme', nextTheme);
  };

  // Listen to PWA system install events
  useEffect(() => {
    const catchInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', catchInstallPrompt);

    // Initial check for standalone mode
    if (window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone) {
      setIsPwaInstalled(true);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', catchInstallPrompt);
    };
  }, []);

  // 30 Minutes Inactivity Auto-Logout Timer implementation
  useEffect(() => {
    if (!currentUser) return;

    let timer: NodeJS.Timeout;
    const INACTIVITY_LIMIT = 30 * 60 * 1000; // 30 minutes in milliseconds

    const resetTimer = () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        // Log out immediately
        handleLogout();
        triggerToast({
          title: "انتهت صلاحية الجلسة",
          titleEn: "Session Expired",
          description: "تم تسجيل خروجك تلقائياً لعدم النشاط لمدة 30 دقيقة لحماية خصوصية بياناتك.",
          descriptionEn: "You have been logged out due to 30 minutes of inactivity to protect your account.",
          type: "success"
        });
      }, INACTIVITY_LIMIT);
    };

    // User activity listeners
    const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click'];
    
    events.forEach(event => {
      window.addEventListener(event, resetTimer);
    });

    // Initialize first timer countdown
    resetTimer();

    return () => {
      clearTimeout(timer);
      events.forEach(event => {
        window.removeEventListener(event, resetTimer);
      });
    };
  }, [currentUser]);

  // Action to launch PWA Installation Prompt or Open beautiful local wizard
  const triggerPwaInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      try {
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === 'accepted') {
          setIsPwaInstalled(true);
        }
      } catch (err) {
        console.error('PWA prompt error:', err);
      }
      setDeferredPrompt(null);
    } else {
      // Manual wizard trigger for sandbox iframes / mobile iOS
      setShowPwaTutorial(true);
    }
  };

  // Fetch all lists from Express APIs
  const fetchAllData = async () => {
    try {
      const pRes = await fetch(getApiUrl('/api/platforms'));
      const pData = await pRes.json();
      if (pRes.ok) setPlatforms(pData);

      const cRes = await fetch(getApiUrl('/api/courses'));
      const cData = await cRes.json();
      if (cRes.ok) setCourses(cData);

      const rRes = await fetch(getApiUrl('/api/resources'));
      const rData = await rRes.json();
      if (rRes.ok) setResources(rData);

      const aRes = await fetch(getApiUrl('/api/accounts'));
      const aData = await aRes.json();
      if (aRes.ok) setAccounts(aData);
    } catch (err) {
      console.error('Error fetching synced server data:', err);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, [currentUser]);

  // Track page transitions and activity hits
  const handleTrackAction = async (action: string, platformId?: string, platformName?: string, details?: string) => {
    if (!currentUser) return;
    try {
      await fetch(getApiUrl('/api/track/activity'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          action,
          pageName: activeSection,
          platformId,
          platformName,
          details
        })
      });
    } catch (err) {
      console.error('Failed to log tracking activity:', err);
    }
  };

  // Track any page navigational click transitions
  useEffect(() => {
    if (!currentUser) return;
    const pageTitles: Record<string, string> = {
      'home': t.sections.home,
      'platforms': t.sections.platforms,
      'courses': t.sections.courses,
      'resources': t.sections.resources,
      'news': t.sections.news,
      'accounts': t.sections.accounts,
      'about': t.sections.about,
      'admin': t.sections.admin
    };
    handleTrackAction('view_page', undefined, undefined, `Browsed tab: ${pageTitles[activeSection] || activeSection}`);
  }, [activeSection, currentUser, lang]);

  const handleLoginSuccess = (user: User) => {
    localStorage.setItem('gce_basra_user', JSON.stringify(user));
    setCurrentUser(user);
    setActiveSection('home');
  };

  const handleLogout = async () => {
    if (currentUser) {
      try {
        await fetch(getApiUrl('/api/track/activity'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: currentUser.id,
            action: 'logout_action',
            details: 'Safe session logout'
          })
        });
      } catch (err) {
        console.error(err);
      }
    }
    localStorage.removeItem('gce_basra_user');
    setCurrentUser(null);
    setActiveSection('home');

    if (isFirebaseValid) {
      try {
        await signOut(auth);
      } catch (err) {
        console.error('Firebase sign-out failed:', err);
      }
    }

    // Force browser back-button denial on logout
    window.history.pushState(null, '', window.location.href);
    window.onpopstate = function () {
      window.history.go(1);
    };
  };

  // Admin dynamic control actions
  const handleAddPlatform = async (p: { name: string; url: string; image?: string; description?: string }) => {
    try {
      const res = await fetch(getApiUrl('/api/platforms'), {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + (currentUser?.token || '')
        },
        body: JSON.stringify(p)
      });
      if (res.ok) {
        fetchAllData();
        triggerToast({
          title: "تم إضافة منصة رقمية",
          titleEn: "Digital Platform Added",
          description: `تم إطلاق المنصة الجديدة "${p.name}" وجاري بثها للمهندسين فوراً.`,
          descriptionEn: `The new platform "${p.name}" has been successfully added to the main interface.`,
          type: "platform"
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleEditPlatform = async (id: string, updated: Partial<DigitalPlatform>) => {
    try {
      const res = await fetch(getApiUrl(`/api/platforms/${id}`), {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + (currentUser?.token || '')
        },
        body: JSON.stringify(updated)
      });
      if (res.ok) {
        fetchAllData();
        triggerToast({
          title: "تم تحديث المنصة",
          titleEn: "Platform Details Updated",
          description: `تم حفظ تفاصيل المنصة "${updated.name || 'المختارة'}" وإتاحتها للتصفح الفوري.`,
          descriptionEn: `The digital platform "${updated.name || 'selected'}" has been updated with new descriptions.`,
          type: "platform"
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeletePlatform = async (id: string) => {
    try {
      const res = await fetch(getApiUrl(`/api/platforms/${id}`), {
        method: 'DELETE',
        headers: {
          'Authorization': 'Bearer ' + (currentUser?.token || '')
        }
      });
      if (res.ok) {
        fetchAllData();
        triggerToast({
          title: "تم حذف المنصة",
          titleEn: "Platform Removed",
          description: "تمت إزالة وتصحيح هيكلية منصات الإدارة العامة بالبصرة بنجاح.",
          descriptionEn: "The digital platform was successfully erased from the local registries.",
          type: "success"
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddCourse = async (c: { title: string; url: string; description?: string; instructor?: string }) => {
    try {
      const res = await fetch(getApiUrl('/api/courses'), {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + (currentUser?.token || '')
        },
        body: JSON.stringify(c)
      });
      if (res.ok) {
        fetchAllData();
        triggerToast({
          title: "تم إدراج حقيبة كورس",
          titleEn: "Training Syllabus Added",
          description: `تم نشر الكورس الجديد "${c.title}" وتم إخطار كافة المنتسبين وتثبيته.`,
          descriptionEn: `Syllabus folders for "${c.title}" have been uploaded directly.`,
          type: "course"
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteCourse = async (id: string) => {
    try {
      const res = await fetch(getApiUrl(`/api/courses/${id}`), {
        method: 'DELETE',
        headers: {
          'Authorization': 'Bearer ' + (currentUser?.token || '')
        }
      });
      if (res.ok) {
        fetchAllData();
        triggerToast({
          title: "تم حذف الحقيبة التدريبية",
          titleEn: "Training Folder Retired",
          description: "تم نقل المنهج التدريبي المختار إلى الأرشيف وإزالته بنجاح.",
          descriptionEn: "The chosen syllabus guide was retired and successfully purged.",
          type: "success"
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddResource = async (r: { title: string; category: string; description: string; url: string; fileName: string; fileSize: number }) => {
    try {
      const res = await fetch(getApiUrl('/api/resources'), {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + (currentUser?.token || '')
        },
        body: JSON.stringify(r)
      });
      if (res.ok) {
        fetchAllData();
        triggerToast({
          title: "تم رفع مرجع للمكتبة",
          titleEn: "Engineering Reference Added",
          description: `تم توفير المستند الهام "${r.title}" للتحميل التلقائي بجودة عالية.`,
          descriptionEn: `The technical catalog file "${r.title}" was made downloadable.`,
          type: "resource"
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteResource = async (id: string) => {
    try {
      const res = await fetch(getApiUrl(`/api/resources/${id}`), {
        method: 'DELETE',
        headers: {
          'Authorization': 'Bearer ' + (currentUser?.token || '')
        }
      });
      if (res.ok) {
        fetchAllData();
        triggerToast({
          title: "تمت إزالة المستند",
          titleEn: "Reference Document Removed",
          description: "تم فك ارتباط الملف وحذفه بنجاح من مكتبة المهندسين الرقمية.",
          descriptionEn: "The specified library paper was removed from global catalog listings.",
          type: "success"
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleEditCourse = async (id: string, updated: any) => {
    try {
      const res = await fetch(getApiUrl(`/api/courses/${id}`), {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + (currentUser?.token || '')
        },
        body: JSON.stringify(updated)
      });
      if (res.ok) {
        fetchAllData();
        triggerToast({
          title: "تم تعديل المنهج",
          titleEn: "Syllabus Details Refined",
          description: `تم تثبيت التحديثات والمحاور المطروحة للحقيبة الكيميائية "${updated.title || 'المحددة'}".`,
          descriptionEn: `Changes were committed to "${updated.title || 'selected'}" program file.`,
          type: "course"
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleReorderCourses = async (courseIds: string[]) => {
    try {
      const res = await fetch(getApiUrl('/api/courses/reorder'), {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + (currentUser?.token || '')
        },
        body: JSON.stringify({ courseIds })
      });
      if (res.ok) {
        fetchAllData();
        triggerToast({
          title: "إعادة تنظيم الحقائب",
          titleEn: "Courses Hierarchy Reordered",
          description: "تمت إعادة ترتيب وتسلسل الحقائب التدريبية على الشاشة الرئيسية.",
          descriptionEn: "The order of senior syllabus modules has been customized.",
          type: "success"
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleEditResource = async (id: string, updated: any) => {
    try {
      const res = await fetch(getApiUrl(`/api/resources/${id}`), {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + (currentUser?.token || '')
        },
        body: JSON.stringify(updated)
      });
      if (res.ok) {
        fetchAllData();
        triggerToast({
          title: "تم تحديث الملف المرجعي",
          titleEn: "Reference Book Updated",
          description: `تم تعديل فهرس ووصف المستند المشترك "${updated.title || 'المختار'}".`,
          descriptionEn: `Indexing schemas on manuscript file "${updated.title || 'selected'}" updated.`,
          type: "resource"
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleReorderResources = async (resourceIds: string[]) => {
    try {
      const res = await fetch(getApiUrl('/api/resources/reorder'), {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + (currentUser?.token || '')
        },
        body: JSON.stringify({ resourceIds })
      });
      if (res.ok) {
        fetchAllData();
        triggerToast({
          title: "إعادة ترتيب المكتبة",
          titleEn: "Library Files Reordered",
          description: "تمت إعادة ترتيب وتسلسل المستندات الهندسية بنجاح.",
          descriptionEn: "The default display sequence of library manual assets has been updated.",
          type: "success"
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleReorderPlatforms = async (platformIds: string[]) => {
    try {
      const res = await fetch(getApiUrl('/api/platforms/reorder'), {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + (currentUser?.token || '')
        },
        body: JSON.stringify({ platformIds })
      });
      if (res.ok) {
        fetchAllData();
        triggerToast({
          title: "إعادة ترتيب المنصات",
          titleEn: "Simulator Order Adjusted",
          description: "تم ترتيب تسلسل المحاكيات الرقمية على واجهتك الرئيسية.",
          descriptionEn: "The viewing hierarchy of interactive simulator portals was rearranged.",
          type: "success"
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateAccounts = async (acc: AuthorityAccounts) => {
    try {
      const res = await fetch(getApiUrl('/api/accounts'), {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + (currentUser?.token || '')
        },
        body: JSON.stringify(acc)
      });
      if (res.ok) {
        fetchAllData();
        triggerToast({
          title: "تم تحديث منصات التواصل",
          titleEn: "Contact Points Refined",
          description: "تم حفظ الروابط والقنوات الرسمية الجديدة للمهندسين بنجاح.",
          descriptionEn: "Social telegram and contact access links have been successfully registered.",
          type: "success"
        });
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (isAuthLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center text-white" dir="rtl">
        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-teal-500 mb-4"></div>
        <p className="text-xs text-teal-300 font-bold">جاري تحميل البوابات الكيميائية بالبصرة...</p>
      </div>
    );
  }

  if (!currentUser) {
    return (
      <AuthPage 
        onLoginSuccess={handleLoginSuccess} 
        lang={lang} 
        setLang={handleLanguageChange} 
        t={t} 
      />
    );
  }

  // Email verification block gate
  if (currentUser && !currentUser.emailVerified) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 text-center font-sans" dir="rtl">
        <div className="max-w-md w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 shadow-2xl relative text-right space-y-6">
          <div className="flex flex-col items-center text-center space-y-3 mb-4">
            <div className="bg-teal-50 dark:bg-teal-950 p-4 rounded-full text-teal-600 dark:text-teal-300">
              <Mail className="h-8 w-8 animate-pulse" />
            </div>
            <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100">
              تفعيل حساب المنصة الهندسية
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm leading-relaxed">
              لقد قمنا بإرسال رابط تفعيل إلى بريدك الإلكتروني المعتمد:
              <br />
              <strong className="text-teal-600 dark:text-teal-300 font-mono mt-1 select-all block text-sm">{currentUser.email}</strong>
            </p>
          </div>

          <div className="bg-slate-50 dark:bg-slate-950 border border-dashed rounded-2xl p-4 text-xs text-slate-650 dark:text-slate-400 space-y-2">
            <h4 className="font-bold text-slate-800 dark:text-slate-200">لماذا هذا مطلوب؟</h4>
            <p className="leading-relaxed">
              لحماية المنصة الهندسية ومكافحة الحسابات الوهمية، تفرض الهيئة الكيميائية بالبصرة التحقق الإلزامي من البريد الإلكتروني لكافة طلاب ومنتسبي الكلية قبل مراجعة المواد الدراسية والمناهج الهندسية.
            </p>
          </div>

          <div className="flex flex-col gap-3">
            <button
              onClick={async () => {
                try {
                  const res = await fetch(getApiUrl('/api/auth/verify-email/confirm'), {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json',
                      'Authorization': 'Bearer ' + (currentUser?.token || '')
                    }
                  });
                  if (res.ok) {
                    const updated = { ...currentUser, emailVerified: true };
                    localStorage.setItem('gce_basra_user', JSON.stringify(updated));
                    setCurrentUser(updated);
                    triggerToast({
                      title: "تم تفعيل الحساب بنجاح",
                      titleEn: "Account activated",
                      description: "مرحباً بك في البوابات الهندسية التفاعلية للبصرة.",
                      descriptionEn: "Welcome to the interactive engineering vaults of Basra.",
                      type: "success"
                    });
                  }
                } catch (err) {
                  console.error(err);
                }
              }}
              className="w-full text-center py-3 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl transition cursor-pointer shadow-lg shadow-teal-600/10"
            >
              تأكيد وتفعيل البريد الآن (محيط التجربة المباشر)
            </button>

            <button
              onClick={() => {
                localStorage.removeItem('gce_basra_user');
                setCurrentUser(null);
              }}
              className="w-full text-center py-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-350 font-bold text-xs rounded-xl transition cursor-pointer"
            >
              العودة والتسجيل بحساب آخر
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Pre-aggregated statistics summary computation for dashboard views (dynamic mapping labels are localized)
  const statsSummary = {
    platformsCount: platforms.length,
    coursesCount: courses.length,
    resourcesCount: resources.length,
    activeUsersCount: 3000 // True realistic community member counts
  };

  const isRtl = t.dir === 'rtl';

  return (
    <div className={`flex flex-col md:flex-row min-h-screen font-sans transition-colors duration-300 ${theme === 'dark' ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'}`} dir={t.dir}>
      
      {/* Mobile Sticky Header Bar with Hamburger */}
      <header className="md:hidden sticky top-0 bg-slate-900 border-b border-slate-800 text-white p-4 flex items-center justify-between z-30">
        <div className="flex items-center gap-2.5">
          <span className="p-1.5 rounded-lg bg-teal-600/20 border border-teal-500/20 text-emerald-300 flex items-center justify-center shadow-inner">
            <Landmark className="h-4.5 w-4.5" />
          </span>
          <span className="text-xs font-black truncate max-w-[155px]">
            {t.appSubName}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Notification bell widget */}
          <HeaderNotifications currentUser={currentUser} lang={lang} onNavigate={setActiveSection} />

          <button 
            onClick={() => setIsMobileSidebarOpen(true)}
            className="p-1.5 rounded-lg hover:bg-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500 text-slate-300 hover:text-white transition cursor-pointer"
            id="mobile-hamburger-btn"
          >
            <Menu className="h-5 w-5" />
          </button>
        </div>
      </header>

      {/* Side navigation bar component */}
      <Sidebar
        currentUser={currentUser}
        activeSection={activeSection}
        onNavigate={setActiveSection}
        onLogout={handleLogout}
        lang={lang}
        setLang={handleLanguageChange}
        t={t}
        isOpen={isMobileSidebarOpen}
        onClose={() => setIsMobileSidebarOpen(false)}
        theme={theme}
        onToggleTheme={handleThemeToggle}
      />

      {/* Primary content area panel */}
      <main className="flex-1 p-6 md:p-10 overflow-y-auto w-full md:max-h-screen">
        <div className="max-w-7xl mx-auto">
          {/* Main Top Header Navigation and Notification Bar */}
          <div className="flex items-center justify-between mb-8 border-b border-slate-200/50 dark:border-slate-800 pb-5">
            <div className="space-y-1">
              <h1 className="text-lg md:text-2xl font-black text-slate-900 dark:text-white leading-tight">
                {activeSection === 'home' && (lang === 'ar' ? 'البوابة الرئيسية للتعليم الكيميائي' : 'Chemical Education Core Gateway')}
                {activeSection === 'platforms' && (lang === 'ar' ? 'المنصات والمحاكيات الرقمية' : 'Digital Simulators & Platforms')}
                {activeSection === 'courses' && (lang === 'ar' ? 'الحقائب التدريبية المعتمدة' : 'Certified Training Portfolios')}
                {activeSection === 'resources' && (lang === 'ar' ? 'المكتبة والمصادر الهندسية لكبار المهندسين' : 'Senior Engineering References Library')}
                {activeSection === 'news' && (lang === 'ar' ? 'الأخبار والنشاطات التفاعلية' : 'Interactive News & Activities Feed')}
                {activeSection === 'accounts' && (lang === 'ar' ? 'قنوات وحسابات الهيئة الرسمية' : 'Official Basra GCE Contact Portals')}
                {activeSection === 'about' && (lang === 'ar' ? 'عن الهيئة وأسس التمثيل والاتحاد' : 'Credentials & Developer Showcase')}
                {activeSection === 'admin' && (lang === 'ar' ? 'إدارة لوحة التحكم وصناعة الأخبار' : 'Global Administrative Operations')}
              </h1>
              <p className="text-[10px] md:text-xs text-slate-500 dark:text-slate-400 font-bold">
                {lang === 'ar' 
                  ? `أهلاً بك مهندس: ${currentUser?.name} | رتبة الحساب: ${currentUser?.role === 'admin' ? 'مشرف عام الهيئة' : 'عضو كيميائي مسجل بالبصرة'}`
                  : `Welcome Eng. ${currentUser?.name} | Space privileges: ${currentUser?.role === 'admin' ? 'Global Controller' : 'Standard Registrant'}`}
              </p>
            </div>

            {/* Notification bell on desktop (hidden on mobile since it is in the sticky header) */}
            <div className="hidden md:block shrink-0">
              <HeaderNotifications currentUser={currentUser} lang={lang} onNavigate={setActiveSection} />
            </div>
          </div>

          {/* Bento-style PWA Promotion Banner */}
          {!isPwaInstalled && (
            <div className="mb-6 rounded-2xl bg-gradient-to-r from-teal-500/10 via-emerald-500/5 to-transparent border border-teal-500/20 p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 shadow-xs">
              <div className="flex items-center gap-3">
                <span className="p-2.5 rounded-xl bg-teal-500/20 text-teal-400 shrink-0">
                  <Smartphone className="h-5 w-5 animate-bounce" />
                </span>
                <div className="space-y-0.5">
                  <h4 className="text-xs font-extrabold text-slate-800">
                    {lang === 'ar' ? 'قم بتثبيت تطبيق الهيئة بالبصرة على هاتفِك!' : 'Install GCE Basra as a native mobile app!'}
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    {lang === 'ar' ? 'تصفح أسرع، استهلاك أقل للبيانات، وسهولة تصفح المحاكيات والمصادر الهندسية بنقرة واحدة.' : 'Faster offline loading, native full-screen view, and easy access with zero clutter.'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={triggerPwaInstall}
                  className="rounded-xl bg-teal-500 hover:bg-teal-600 px-3.5 py-2 text-xs font-black text-slate-950 transition cursor-pointer shadow-xs shadow-teal-500/15"
                >
                  {lang === 'ar' ? 'تثبيت التطبيق الآن' : 'Install App Now'}
                </button>
                <button
                  onClick={() => setIsPwaInstalled(true)}
                  className="p-1.5 px-2.5 rounded-lg hover:bg-slate-200 text-[11px] font-bold text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  {lang === 'ar' ? 'إغلاق' : 'Dismiss'}
                </button>
              </div>
            </div>
          )}

          {activeSection === 'home' && (
            <HomeSection 
              onNavigate={setActiveSection} 
              stats={statsSummary} 
              lang={lang}
              t={t}
            />
          )}

          {activeSection === 'platforms' && (
            <PlatformsSection
              currentUser={currentUser}
              platforms={platforms}
              onTrackAction={(act, pId, pName, details) => handleTrackAction(act, pId, pName, details)}
              lang={lang}
              t={t}
            />
          )}

          {activeSection === 'courses' && (
            <CoursesSection
              currentUser={currentUser}
              courses={courses}
              onAddCourse={handleAddCourse}
              onDeleteCourse={handleDeleteCourse}
              onEditCourse={handleEditCourse}
              onReorderCourses={handleReorderCourses}
              lang={lang}
              t={t}
            />
          )}

          {activeSection === 'resources' && (
            <ResourcesSection
              currentUser={currentUser}
              resources={resources}
              onAddResource={handleAddResource}
              onDeleteResource={handleDeleteResource}
              onEditResource={handleEditResource}
              onReorderResources={handleReorderResources}
              onTrackAction={(act, page, details) => handleTrackAction(act, undefined, undefined, details)}
              lang={lang}
              t={t}
            />
          )}

          {activeSection === 'news' && (
            <NewsSection
              currentUser={currentUser}
              lang={lang}
              t={t}
            />
          )}

          {activeSection === 'accounts' && accounts && (
            <AccountsSection
              currentUser={currentUser}
              accounts={accounts}
              onUpdateAccounts={handleUpdateAccounts}
              lang={lang}
              t={t}
            />
          )}

          {activeSection === 'about' && (
            <AboutSection 
              lang={lang}
              t={t}
            />
          )}

          {activeSection === 'security_settings' && (
            <SecuritySettingsSection
              currentUser={currentUser}
              onUpdateCurrentUser={setCurrentUser}
              lang={lang}
            />
          )}

          {activeSection === 'notifications' && (
            <NotificationsSection
              currentUser={currentUser}
              lang={lang}
              onNavigate={setActiveSection}
            />
          )}

          {activeSection === 'admin' && (
            <AdminSection
              currentUser={currentUser}
              platforms={platforms}
              courses={courses}
              resources={resources}
              onAddPlatform={handleAddPlatform}
              onEditPlatform={handleEditPlatform}
              onDeletePlatform={handleDeletePlatform}
              onReorderPlatforms={handleReorderPlatforms}
              onAddCourse={handleAddCourse}
              onEditCourse={handleEditCourse}
              onDeleteCourse={handleDeleteCourse}
              onReorderCourses={handleReorderCourses}
              onAddResource={handleAddResource}
              onEditResource={handleEditResource}
              onDeleteResource={handleDeleteResource}
              onReorderResources={handleReorderResources}
              lang={lang}
              t={t}
            />
          )}
        </div>
      </main>

      {/* Floating Rules-based Companion Assistance Bot */}
      <LocalHelpBot lang={lang} />

      {/* PWA Step-by-Step Tutorial Dialog Modal */}
      {showPwaTutorial && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-100 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-150 dark:border-slate-800 w-full max-w-lg p-6 shadow-2xl relative" dir={t.dir}>
            <button
              onClick={() => setShowPwaTutorial(false)}
              className="absolute top-4 right-4 p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 transition"
            >
              <X className="h-5 w-5" />
            </button>

            <div className="space-y-5">
              <div className="flex items-center gap-3">
                <span className="p-3 rounded-2xl bg-teal-500/10 text-teal-400 border border-teal-500/20">
                  <HelpCircle className="h-6 w-6" />
                </span>
                <div>
                  <h3 className="text-base font-black text-slate-900 dark:text-white">
                    {lang === 'ar' ? 'دليل تنصيب تطبيق الهيئة الكيميائية' : 'GCE PWA Installation Guide'}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {lang === 'ar' ? 'خطوات مبسطة لتشغيل المنصة كتطبيق كيميائي متكامل' : 'Simple steps to run GCE Basra as an independent desktop/mobile app'}
                  </p>
                </div>
              </div>

              <div className="border-t border-b border-slate-100 dark:border-slate-800 py-4 space-y-4">
                {/* iOS Safari */}
                <div className="flex gap-3">
                  <span className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-350 font-bold text-xs h-8 w-8 flex items-center justify-center">iOS</span>
                  <div className="space-y-1">
                    <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      {lang === 'ar' ? 'هواتف الآيفون (Safari):' : 'iPhones & iPads (Safari):'}
                    </h4>
                    <p className="text-xs text-slate-550 dark:text-slate-400 leading-relaxed font-light">
                      {lang === 'ar' ? '1. انقر على زر المشاركة (Share) في متصفح سفاري بالأسفل.' : '1. Tap the Share icon along the Safari browser navigation bar.'}
                      <br />
                      {lang === 'ar' ? '2. مرر لأسفل ثم اختر "إضافة إلى الشاشة الرئيسية" (Add to Home Screen).' : '2. Scroll down and press "Add to Home Screen".'}
                    </p>
                  </div>
                </div>

                {/* Android / Chrome */}
                <div className="flex gap-3">
                  <span className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-350 font-bold text-xs h-8 w-8 flex items-center justify-center border border-slate-200 dark:border-slate-700">AND</span>
                  <div className="space-y-1">
                    <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      {lang === 'ar' ? 'هواتف الأندرويد ومتصفح كروم:' : 'Android Phones & Google Chrome:'}
                    </h4>
                    <p className="text-xs text-slate-550 dark:text-slate-400 leading-relaxed font-light">
                      {lang === 'ar' ? '1. انقر على النقاط الثلاث العمودية في الزاوية العلوية للمتصفح.' : '1. Press the three vertical dots options panel in Chrome.'}
                      <br />
                      {lang === 'ar' ? '2. اختر "تثبيت التطبيق" (Install App) أو "الإضافة للشاشة الرئيسية".' : '2. Tap "Install App" or "Add to Home Screen".'}
                    </p>
                  </div>
                </div>

                {/* Windows / macOS Desktop */}
                <div className="flex gap-3">
                  <span className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-350 font-bold text-xs h-8 w-8 flex items-center justify-center">PC</span>
                  <div className="space-y-1">
                    <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      {lang === 'ar' ? 'أجهزة الحاسوب المكتبي واللابتوب:' : 'Windows & macOS Desktops:'}
                    </h4>
                    <p className="text-xs text-slate-550 dark:text-slate-400 leading-relaxed font-light">
                      {lang === 'ar' ? '1. انقر على أيقونة الشاشة/السهم الصغير المتواجد في شريط العنوان بالأعلى.' : '1. Spot the tiny monitor/download arrow symbol in the browser URL bar.'}
                      <br />
                      {lang === 'ar' ? '2. أكد عملية تثبيت GCE Basra لتفتح في نافذة مستقلة راقية.' : '2. Click it to confirm and run GCE Basra as an independent desktop slot.'}
                    </p>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setShowPwaTutorial(false)}
                className="w-full text-center py-2.5 bg-teal-500 hover:bg-teal-600 font-extrabold text-xs text-slate-950 rounded-xl transition cursor-pointer shadow-md shadow-teal-500/10"
              >
                {lang === 'ar' ? 'فهمت ذلك، شكراً لك' : 'Understood, Thank You!'}
              </button>
            </div>
          </div>
        </div>
      )}
      <ToastContainer lang={lang} />
    </div>
  );
}
