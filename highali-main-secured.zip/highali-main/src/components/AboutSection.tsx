/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Landmark, Cpu, Mail, Star, Code } from 'lucide-react';
import { motion } from 'motion/react';
import { LanguageType } from '../locales';

interface AboutSectionProps {
  lang: LanguageType;
  t: any;
}

export default function AboutSection({ lang, t }: AboutSectionProps) {
  return (
    <div className="space-y-8 max-w-4xl mx-auto" dir={t.dir}>
      {/* Platform Information banner */}
      <motion.div
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        className="rounded-3xl border border-slate-100 bg-white p-6 md:p-10 shadow-sm space-y-6"
      >
        <div className="flex items-center gap-3">
          <span className="p-3 rounded-2xl bg-teal-50 text-teal-800">
            <Landmark className="h-6 w-6" />
          </span>
          <div>
            <span className="text-[10px] text-teal-600 font-bold uppercase">{t.about.introTitle}</span>
            <h2 className="text-xl font-bold text-slate-800">{t.about.title}</h2>
          </div>
        </div>

        <div className="space-y-4 text-xs text-slate-600 leading-relaxed font-light">
          <p>{t.about.p1}</p>
          <p>{t.about.p2}</p>
        </div>

        <div className="grid gap-4 sm:grid-cols-3 pt-4 border-t">
          {t.about.cards.map((item: any, idX: number) => (
            <div key={idX} className="space-y-1.5 p-4 rounded-2xl bg-slate-50 border border-slate-100">
              <h4 className="text-xs font-bold text-teal-800">{item.title}</h4>
              <p className="text-[11px] text-gray-500 font-light leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Developer Information Card */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="rounded-3xl bg-gradient-to-br from-slate-900 to-teal-950 p-6 md:p-8 text-white shadow-xl relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 h-full w-1/4 bg-[url('https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=400')] bg-cover opacity-5"></div>
        
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-6 justify-between">
          <div className="space-y-4 text-center md:text-right">
            <div className="inline-flex items-center gap-1 bg-teal-500/20 px-3 py-1 rounded-full text-xs font-semibold text-teal-300">
              <Code className="h-3.5 w-3.5" />
              <span>{t.about.devBadge}</span>
            </div>
            
            <div className="space-y-1">
              <h2 className="text-2xl font-extrabold text-white">{t.about.devName}</h2>
              <p className="text-xs text-teal-400 font-mono">{t.about.devTitle}</p>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed font-light max-w-xl">
              {t.about.devDesc}
            </p>

            <div className="flex flex-wrap justify-center md:justify-start gap-3 pt-2 text-xs">
              <span className="inline-flex items-center gap-1 text-slate-300">
                <Star className="h-3.5 w-3.5 text-yellow-400" />
                <span>{t.about.devContact}</span>
              </span>
            </div>
          </div>

          {/* Clean Visual avatar/logo mock */}
          <div className="h-28 w-28 rounded-2xl bg-teal-600/30 border border-teal-400/30 flex flex-col items-center justify-center p-3 text-center shrink-0 shadow-lg">
            <Cpu className="h-10 w-10 text-teal-300 animate-pulse mb-1" />
            <span className="text-[10px] font-bold text-teal-200">{t.about.devStudio}</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
