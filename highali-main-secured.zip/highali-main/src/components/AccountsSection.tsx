/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Send, Phone, Globe, ExternalLink, HelpCircle, Shield, Sparkles, 
  Settings2, Save, ChevronLeft, ChevronRight, MessageCircle, Instagram, Linkedin
} from 'lucide-react';
import { AuthorityAccounts, User } from '../types';
import { motion } from 'motion/react';
import { LanguageType } from '../locales';

interface AccountsSectionProps {
  currentUser: User | null;
  accounts: AuthorityAccounts;
  onUpdateAccounts: (accounts: AuthorityAccounts) => Promise<void>;
  lang: LanguageType;
  t: any;
}

export default function AccountsSection({
  currentUser,
  accounts,
  onUpdateAccounts,
  lang,
  t
}: AccountsSectionProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [isSubmitLoading, setIsSubmitLoading] = useState(false);
  const isAdmin = currentUser?.role === 'admin';
  const isRtl = lang === 'ar';

  // Local state for all channels
  const [telegram, setTelegram] = useState(accounts.telegram || '');
  const [instagram, setInstagram] = useState(accounts.instagram || '');
  const [linkedin, setLinkedin] = useState(accounts.linkedin || '');
  const [telegramGot, setTelegramGot] = useState(accounts.telegramGot || '');
  const [instagramGot, setInstagramGot] = useState(accounts.instagramGot || '');
  const [telegramTrainee, setTelegramTrainee] = useState(accounts.telegramTrainee || '');

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitLoading(true);
    try {
      await onUpdateAccounts({
        ...accounts, // Keep old values for uneditable fields like facebook, youtube, website
        telegram,
        instagram,
        whatsapp: '',
        linkedin,
        telegramGot,
        instagramGot,
        telegramTrainee
      });
      setIsEditing(false);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitLoading(false);
    }
  };

  // Define channels details for clean presentation
  const channels = [
    {
      id: 'telegram',
      title: isRtl ? 'قناة الهيئة العامة الرسمية' : 'GCE Official Telegram Channel',
      description: isRtl 
        ? 'النافذة الإعلامية والخبرية المعتمدة لنشر قرارات وبيانات الهيئة العامة الكيميائية' 
        : 'The accredited direct public feed for official authority announcements and resolutions.',
      url: telegram,
      icon: Send,
      color: 'bg-sky-500/10 text-sky-500 border-sky-500/20 hover:bg-sky-500/15',
      badge: isRtl ? 'الهيئة الرسمية' : 'Official Portal'
    },
    {
      id: 'instagram',
      title: isRtl ? 'حساب الإنستغرام الرسمي للهيئة' : 'GCE Official Instagram Office',
      description: isRtl 
        ? 'تغطية مصورة للورش، المؤتمرات، وحفلات تخرج ودورات الطلبة في البصرة' 
        : 'Visual photo and video logs of technical symposiums, exhibitions and graduate assemblies.',
      url: instagram,
      icon: Instagram,
      color: 'bg-pink-500/10 text-pink-500 border-pink-500/20 hover:bg-pink-500/15',
      badge: isRtl ? 'تغطية حية' : 'Live Socials'
    },
    {
      id: 'linkedin',
      title: isRtl ? 'الحساب المهني الرسمي على LinkedIn' : 'Official GCE Professional LinkedIn',
      description: isRtl 
        ? 'بناء شبكة تواصل احترافية للمنصة ومتابعة مشاريع وبحوث كبار المهندسين بالبصرة' 
        : 'Engage with GCE business, research networks, senior developers, and regional engineering groups.',
      url: linkedin,
      icon: Linkedin,
      color: 'bg-blue-500/10 text-blue-500 border-blue-500/20 hover:bg-blue-500/15',
      badge: isRtl ? 'مسار مهني' : 'Career Growth'
    },
    {
      id: 'telegramGot',
      title: isRtl ? 'قناة الدعم العلمي GOT Engineering' : 'GOT Science & Support Channel',
      description: isRtl 
        ? 'شريك الهيئة الحصري لتقديم شروحات موازنة المادة وميكانيك الموائع للطلاب' 
        : 'Our official educational partner channel, providing rigorous core chemical guidelines.',
      url: telegramGot,
      icon: Send,
      color: 'bg-purple-500/10 text-purple-500 border-purple-500/20 hover:bg-purple-500/15',
      badge: isRtl ? 'شريك علمي' : 'Science Hub'
    },
    {
      id: 'instagramGot',
      title: isRtl ? 'إنستغرام الدعم العلمي والمعلومات' : 'GOT Educational Instagram',
      description: isRtl 
        ? 'منصتنا الرديفة لنشر مخططات تدفق العمليات الهندسية والمعادلات الرياضية' 
        : 'Alternate partner feed publishing technical flowcharts, formulas, and mock problems.',
      url: instagramGot,
      icon: Instagram,
      color: 'bg-amber-500/10 text-amber-500 border-amber-500/20 hover:bg-amber-500/15',
      badge: isRtl ? 'محتوى تعليمي' : 'Learning Guides'
    },
    {
      id: 'telegramTrainee',
      title: isRtl ? 'قناة التدريب والتأهيل الكيميائي' : 'GCE Chemical Train & Qualify Channel',
      description: isRtl 
        ? 'قناة تنشر كل الدورات في التلكرام ك مركز تدريبي تابع للهيئة' 
        : 'The official GCE training center channel, publishing all engineering courses and qualifying syllabuses directly on Telegram.',
      url: telegramTrainee,
      icon: Send,
      color: 'bg-teal-500/10 text-teal-500 border-teal-500/20 hover:bg-teal-500/15',
      badge: isRtl ? 'مركز تدريبي' : 'Training Center'
    }
  ];

  return (
    <div className="space-y-6" id="accounts-section-root">
      {/* Header and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-5">
        <div>
          <h2 className="text-xl font-extrabold text-slate-800 dark:text-slate-100 flex items-center gap-2.5">
            <Send className="h-6 w-6 text-teal-500" />
            {isRtl ? 'قنوات تواصل الهيئة العامة والشركاء' : 'Official Basra GCE Support Portals'}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {isRtl 
              ? 'الروابط المباشرة ومنصات الدعم وعائلات التليجرام لخدمة وتدريب أعضاء الهيئة بالبصرة بالتكامل مع GOT Engineering'
              : 'Direct links, telegram groups, and partner feeds dedicated to serving Basra chemists.'}
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-teal-500/30 bg-teal-500/10 hover:bg-teal-500/20 text-teal-600 dark:text-teal-400 text-xs font-black transition cursor-pointer self-start sm:self-auto"
          >
            <Settings2 className="h-4 w-4" />
            {isEditing 
              ? (isRtl ? 'إغلاق نافذة التعديل' : 'Cancel Editing') 
              : (isRtl ? 'تعديل الروابط الرسمية' : 'Edit Official Links')}
          </button>
        )}
      </div>

      {/* Admin Modification Form */}
      {isEditing && isAdmin && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-slate-50 dark:bg-slate-800/40 p-5 rounded-2xl border border-slate-150 dark:border-slate-800"
        >
          <div className="flex items-center gap-2 mb-4">
            <span className="p-1.5 rounded-lg bg-teal-500/10 text-teal-500">
              <Shield className="h-4 w-4" />
            </span>
            <h3 className="text-xs font-extrabold text-slate-800 dark:text-slate-200">
              {isRtl ? 'لوحة تحرير الروابط الرقمية (خاص بمسؤولي الهيئة)' : 'Manage Digital Access Channels (Admin Only)'}
            </h3>
          </div>

          <form onSubmit={handleSave} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-black text-slate-600 dark:text-slate-400 mb-1.5">
                  {isRtl ? 'قناة الهيئة العامة على تليجرام' : 'GCE Telegram Channel'}
                </label>
                <input
                  type="url"
                  value={telegram}
                  onChange={(e) => setTelegram(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 text-slate-800 dark:text-slate-100"
                  placeholder="https://t.me/..."
                />
              </div>

              <div>
                <label className="block text-[11px] font-black text-slate-600 dark:text-slate-400 mb-1.5">
                  {isRtl ? 'حساب الإنستغرام الرسمي للهيئة' : 'GCE Instagram Link'}
                </label>
                <input
                  type="url"
                  value={instagram}
                  onChange={(e) => setInstagram(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 text-slate-800 dark:text-slate-100"
                  placeholder="https://www.instagram.com/..."
                />
              </div>

              <div>
                <label className="block text-[11px] font-black text-slate-600 dark:text-slate-400 mb-1.5">
                  {isRtl ? 'حساب لينكد إن للمنصة الكيميائية' : 'LinkedIn Professional URL'}
                </label>
                <input
                  type="url"
                  value={linkedin}
                  onChange={(e) => setLinkedin(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 text-slate-800 dark:text-slate-100"
                  placeholder="https://www.linkedin.com/in/..."
                />
              </div>

              <div>
                <label className="block text-[11px] font-black text-slate-600 dark:text-slate-400 mb-1.5">
                  {isRtl ? 'قناة العلوم والتفكير GOT Engineering' : 'GOT Educational Telegram'}
                </label>
                <input
                  type="url"
                  value={telegramGot}
                  onChange={(e) => setTelegramGot(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 text-slate-800 dark:text-slate-100"
                  placeholder="https://t.me/..."
                />
              </div>

              <div>
                <label className="block text-[11px] font-black text-slate-600 dark:text-slate-400 mb-1.5">
                  {isRtl ? 'إنستغرام الدعم العلمي الكيميائي' : 'GOT Educational Instagram'}
                </label>
                <input
                  type="url"
                  value={instagramGot}
                  onChange={(e) => setInstagramGot(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 text-slate-800 dark:text-slate-100"
                  placeholder="https://www.instagram.com/..."
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-[11px] font-black text-slate-600 dark:text-slate-400 mb-1.5">
                  {isRtl ? 'قناة التدريب والتأهيل الكيميائي' : 'Chemical Trainee Telegram Channel'}
                </label>
                <input
                  type="url"
                  value={telegramTrainee}
                  onChange={(e) => setTelegramTrainee(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 text-slate-800 dark:text-slate-100"
                  placeholder="https://t.me/..."
                />
              </div>
            </div>

            <div className="flex justify-end gap-2.5 pt-2">
              <button
                type="submit"
                disabled={isSubmitLoading}
                className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-teal-500 hover:bg-teal-600 text-slate-950 text-xs font-black transition cursor-pointer disabled:opacity-50 shadow-md shadow-teal-500/10"
              >
                <Save className="h-4 w-4" />
                {isSubmitLoading 
                  ? (isRtl ? 'جاري الحفظ والتدوين...' : 'Saving Link Details...') 
                  : (isRtl ? 'حفظ وتحديث التعديلات' : 'Commit Link Updates')}
              </button>
            </div>
          </form>
        </motion.div>
      )}

      {/* Grid of Clickable Portals */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
        {channels.map((ch, idx) => {
          const IconComponent = ch.icon;
          return (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              id={`channel-card-${ch.id}`}
              className="rounded-2xl border border-slate-150 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 scroll-mt-28 shadow-xs hover:shadow-lg hover:border-teal-500/20 transition flex flex-col justify-between"
            >
              <div className="space-y-4">
                {/* Channel Header Group */}
                <div className="flex items-center justify-between gap-3">
                  <span className={`p-3 rounded-2xl border shrink-0 ${ch.color}`}>
                    <IconComponent className="h-5 w-5" />
                  </span>
                  <span className="px-2.5 py-1 rounded-full text-[9px] font-black bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 capitalize">
                    {ch.badge}
                  </span>
                </div>

                <div className="space-y-1">
                  <h3 className="text-xs font-extrabold text-slate-800 dark:text-slate-100">
                    {ch.title}
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                    {ch.description}
                  </p>
                </div>
              </div>

              <div className="border-t border-slate-50 dark:border-slate-800/60 mt-5 pt-4">
                {ch.url ? (
                  <a
                    href={ch.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between group rounded-xl bg-slate-50 dark:bg-slate-800/40 p-2.5 hover:bg-teal-500 hover:text-slate-950 transition-all text-slate-700 dark:text-slate-300"
                  >
                    <span className="text-[11px] font-bold group-hover:font-extrabold truncate max-w-[180px] text-slate-500 dark:text-slate-400 group-hover:text-slate-950">
                      {ch.url}
                    </span>
                    <span className="flex items-center gap-1 text-[11px] font-black">
                      {isRtl ? 'انضم الآن' : 'Open Link'}
                      {isRtl ? (
                        <ChevronLeft className="h-3 w-3 transform group-hover:-translate-x-1 transition" />
                      ) : (
                        <ChevronRight className="h-3 w-3 transform group-hover:translate-x-1 transition" />
                      )}
                    </span>
                  </a>
                ) : (
                  <div className="flex items-center gap-2 p-2.5 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-slate-400 text-center justify-center text-[11px]">
                    <HelpCircle className="h-4 w-4 shrink-0" />
                    <span>{isRtl ? 'الرابط غير مضبوط حالياً من المشرف' : 'Portal Link is not set by admin.'}</span>
                  </div>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Footer support card */}
      <div className="rounded-2xl bg-gradient-to-r from-teal-500/10 via-emerald-500/5 to-transparent border border-teal-500/20 p-5 flex flex-col md:flex-row items-center gap-4 justify-between mt-8">
        <div className="flex items-center gap-3">
          <span className="p-3 rounded-2xl bg-teal-500/15 text-teal-400 border border-teal-500/35">
            <Sparkles className="h-6 w-6" />
          </span>
          <div className="space-y-0.5" dir={isRtl ? 'rtl' : 'ltr'}>
            <h4 className="text-xs font-extrabold text-slate-800 dark:text-slate-100">
              {isRtl ? 'هل تحتاج إلى دعم إضافي أو مساعدة في التسجيل؟' : 'Need help or administrative guidance?'}
            </h4>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              {isRtl 
                ? 'يمكنك دائماً مراسلة اللجان العلمية عبر حسابات التليجرام الرسمية أو استخدام البوت الكيميائي العائم بأسفل الشاشة لحل المشاكل الرقمية وحجز المقاعد.'
                : 'Message the scientific committees through our official Telegram channels or tap the helper bot icon at the bottom of your screen anytime.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
