/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Landmark, Mail, Lock, User as UserIcon, Sparkles, LogIn, UserPlus, Globe, ChevronDown, Check } from 'lucide-react';
import { motion } from 'motion/react';
import { LanguageType } from '../locales';
import { getApiUrl } from '../lib/api';
import { GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { auth, isFirebaseValid } from '../lib/firebase';

interface AuthPageProps {
  onLoginSuccess: (user: any) => void;
  lang: LanguageType;
  setLang: (lang: LanguageType) => void;
  t: any;
}

export default function AuthPage({ onLoginSuccess, lang, setLang, t }: AuthPageProps) {
  const [activeMode, setActiveMode] = useState<'login' | 'register'>('login');
  const [isLangDropdownOpen, setIsLangDropdownOpen] = useState(false);
  
  // Login Form States
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  
  // Register Form States
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regAcademic, setRegAcademic] = useState('المرحلة الأولى - جامعة البصرة');

  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // 2FA Challenge Interception States
  const [require2FaStep, setRequire2FaStep] = useState(false);
  const [twoFactorUserId, setTwoFactorUserId] = useState('');
  const [twoFactorPin, setTwoFactorPin] = useState('');
  const [twoFactorError, setTwoFactorError] = useState('');

  // Password recovery mock state
  const [isResetOpen, setIsResetOpen] = useState(false);
  const [resetEmail, setResetEmail] = useState('');
  const [resetSuccess, setResetSuccess] = useState('');
  const [resetError, setResetError] = useState('');

  // Google Sign-In (real, via Firebase Auth)
  const [googleError, setGoogleError] = useState('');

  const languages: { code: LanguageType; name: string }[] = [
    { code: 'ar', name: 'العربية' },
    { code: 'en', name: 'English' },
    { code: 'de', name: 'Deutsch' },
    { code: 'es', name: 'Español' }
  ];

  const checkPasswordStrength = (password: string) => {
    if (!password) return { score: 0, text: '', color: 'bg-gray-200' };
    let score = 0;
    if (password.length >= 10) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[a-z]/.test(password)) score++;
    if (/[0-9]/.test(password)) score++;
    if (/[^A-Za-z0-9]/.test(password)) score++;

    if (score <= 2) {
      return { score, text: lang === 'ar' ? 'ضعيف ❌' : 'Weak ❌', color: 'bg-red-500 w-1/3' };
    } else if (score <= 4) {
      return { score, text: lang === 'ar' ? 'متوسط ⚠️' : 'Medium ⚠️', color: 'bg-amber-500 w-2/3' };
    } else {
      return { score, text: lang === 'ar' ? 'قوي جداً ومؤمن ممتاز ✅' : 'Excellent Strong ✅', color: 'bg-teal-500 w-full' };
    }
  };

  const handleGoogleSignIn = async () => {
    setGoogleError('');
    if (!isFirebaseValid) {
      setGoogleError(
        lang === 'ar'
          ? 'تسجيل الدخول عبر Google غير مُفعّل على هذا الخادم حالياً (إعدادات Firebase ناقصة).'
          : 'Google Sign-In is not configured on this server yet.'
      );
      return;
    }
    setIsLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      const idToken = await result.user.getIdToken();

      const response = await fetch(getApiUrl('/api/auth/google-session'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken })
      });
      const data = await response.json();
      if (response.ok) {
        if (data.require2Fa) {
          setTwoFactorUserId(data.userId);
          setRequire2FaStep(true);
        } else {
          onLoginSuccess(data);
        }
      } else {
        setGoogleError(data.error || (lang === 'ar' ? 'فشل تسجيل الدخول عبر Google.' : 'Google login failed.'));
      }
    } catch (err: any) {
      // err.code 'auth/popup-closed-by-user' etc. are not real errors, just skip silently
      if (err?.code !== 'auth/popup-closed-by-user' && err?.code !== 'auth/cancelled-popup-request') {
        setGoogleError(`${lang === 'ar' ? 'خطأ في تسجيل الدخول عبر Google' : 'Google sign-in error'}: ${err.message}`);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!loginEmail.trim() || !loginPassword.trim()) {
      setErrorMsg(t.auth.errorMissingCreds);
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch(getApiUrl('/api/auth/login'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: loginEmail, password: loginPassword })
      });
      const data = await response.json();
      if (response.ok) {
        if (data.require2Fa) {
          setTwoFactorUserId(data.userId);
          setRequire2FaStep(true);
        } else {
          onLoginSuccess(data);
        }
      } else {
        setErrorMsg(data.error || 'Login failed.');
      }
    } catch (err: any) {
      setErrorMsg(`Server connection error: ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!regName.trim() || !regEmail.trim() || !regPassword.trim()) {
      setErrorMsg(t.auth.errorAllFields);
      return;
    }

    // Password strength check constraint validation
    const strength = checkPasswordStrength(regPassword);
    if (strength.score < 5) {
      setErrorMsg(
        lang === 'ar'
          ? 'يجب أن تفوق قوة كلمة المرور مستوى "قوي جداً" كشرط أمن للمنصة: يجب أن تكون 10 خانات فأكثر، وتتضمن أحرفاً كبيرة A-Z، وصغيرة a-z، وأرقاماً 0-9، ورمزاً خاصاً مثل @#$&.'
          : 'Security policy: Password must be extremely strong (min 10 chars, uppercase, lowercase, number, symbol).'
      );
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch(getApiUrl('/api/auth/register'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: regName,
          email: regEmail,
          password: regPassword,
          academicYear: regAcademic
        })
      });
      const data = await response.json();
      if (response.ok) {
        onLoginSuccess(data);
      } else {
        setErrorMsg(data.error || 'Registration failed.');
      }
    } catch (err: any) {
      setErrorMsg(`Server submission error: ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const isRtl = t.dir === 'rtl';

  return (
    <div className="min-h-screen bg-[#f1f5f9] flex flex-col md:flex-row shadow-inner font-sans relative" dir={t.dir}>
      
      {/* Floating Language Switcher for Guest view */}
      <div className={`absolute top-4 ${isRtl ? 'left-4' : 'right-4'} z-40`}>
        <div className="relative">
          <button
            onClick={() => setIsLangDropdownOpen(!isLangDropdownOpen)}
            className="rounded-xl bg-white/95 border border-slate-200 hover:border-slate-350 px-3.5 py-2 text-xs font-semibold text-slate-700 flex items-center gap-2 transition shadow-xs cursor-pointer"
          >
            <Globe className="h-4 w-4 text-teal-600" />
            <span>{languages.find(l => l.code === lang)?.name}</span>
            <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
          </button>

          {isLangDropdownOpen && (
            <div className={`absolute ${isRtl ? 'left-0' : 'right-0'} mt-1 rounded-xl bg-white border border-slate-200 shadow-xl py-1 z-50 w-36`}>
              {languages.map((l) => (
                <button
                  key={l.code}
                  onClick={() => {
                    setLang(l.code);
                    setIsLangDropdownOpen(false);
                  }}
                  className={`w-full text-right px-4 py-2.5 text-xs font-semibold flex items-center justify-between transition cursor-pointer ${
                    lang === l.code 
                      ? 'bg-teal-50 text-teal-700' 
                      : 'hover:bg-slate-50 text-slate-600'
                  }`}
                >
                  <span>{l.name}</span>
                  {lang === l.code && <Check className="h-3.5 w-3.5 text-teal-600" />}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Decorative Branding Section */}
      <div className="md:w-1/2 bg-gradient-to-br from-emerald-900 via-teal-800 to-cyan-950 p-8 md:p-12 text-white flex flex-col justify-between relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=1000')] bg-cover opacity-5 bg-blend-overlay"></div>
        
        <div className="relative z-10 flex items-center gap-3">
          <span className="p-2.5 rounded-2xl bg-teal-600/30 border border-teal-400/20 backdrop-blur-md">
            <Landmark className="h-6 w-6 text-emerald-300" />
          </span>
          <span className="font-extrabold text-xs md:text-sm tracking-tight uppercase leading-tight">
            {t.appName}
          </span>
        </div>

        <div className="relative z-10 space-y-4 max-w-lg my-auto py-12 md:py-0">
          <div className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/20 px-3 py-1 text-xs font-semibold text-emerald-300">
            <Sparkles className="h-4 w-4 animate-pulse" />
            {t.certifiedPlatform}
          </div>
          <h1 className="text-3xl font-black md:text-5xl leading-tight">
            {t.home.title}
          </h1>
          <p className="text-xs md:text-sm text-teal-100 font-light leading-relaxed">
            {t.home.subtitle}
          </p>
        </div>

        <div className="relative z-10 text-[9px] text-teal-300/60 font-mono flex justify-between border-t border-teal-800/60 pt-4">
          <span>ENG. ALI SAIF ALDIN HAIDER - AL-NAWFAL © 2026</span>
          <span>BASRA, IRAQ</span>
        </div>
      </div>

      {/* Interactive Account Form Fields Section */}
      <div className="md:w-1/2 bg-white flex flex-col justify-center p-6 md:p-16 relative">
        <div className="w-full max-w-sm mx-auto space-y-8">
          
          <div className="space-y-2 text-center md:text-right">
            <h2 className="text-2xl font-black text-slate-800">{t.auth.welcome}</h2>
            <p className="text-xs text-gray-400 leading-relaxed font-light">
              {t.auth.subtitle}
            </p>
          </div>

          {/* Form Trigger tabs */}
          <div className="flex bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => {
                setActiveMode('login');
                setErrorMsg('');
              }}
              className={`flex-1 text-center font-bold py-2 text-xs rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer ${
                activeMode === 'login' ? 'bg-white text-teal-850 shadow-xs' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <LogIn className="h-3.5 w-3.5" />
              <span>{t.auth.hasAccount}</span>
            </button>
            <button
              onClick={() => {
                setActiveMode('register');
                setErrorMsg('');
              }}
              className={`flex-1 text-center font-bold py-2 text-xs rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer ${
                activeMode === 'register' ? 'bg-white text-teal-850 shadow-xs' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <UserPlus className="h-3.5 w-3.5" />
              <span>{t.auth.newAccount}</span>
            </button>
          </div>

          {(errorMsg || googleError) && (
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs text-center font-bold"
            >
              {errorMsg || googleError}
            </motion.div>
          )}

          {activeMode === 'login' ? (
            // Form Login
            <form onSubmit={handleLoginSubmit} className="space-y-4 text-right">
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-500">{t.auth.email}</label>
                <div className="relative">
                  <span className={`absolute ${isRtl ? 'right-3.5' : 'left-3.5'} top-3.5 text-gray-400`}>
                    <Mail className="h-4 w-4" />
                  </span>
                  <input
                    type="email"
                    required
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="example: test@gmail.com"
                    className={`w-full rounded-xl border border-slate-200 bg-slate-50 py-3 text-xs outline-none focus:bg-white focus:border-teal-500 ${
                      isRtl ? 'pr-10 pl-4 text-right' : 'pl-10 pr-4 text-left'
                    }`}
                  />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-gray-500">{t.auth.password}</label>
                  <button
                    type="button"
                    onClick={() => {
                      setResetEmail('');
                      setResetSuccess('');
                      setResetError('');
                      setIsResetOpen(true);
                    }}
                    className="text-[10px] text-teal-600 hover:text-teal-700 font-bold transition focus:outline-none cursor-pointer"
                  >
                    {lang === 'ar' ? 'هل نسيت كلمة المرور؟ استعادة 🔑' : 'Forgot Password? Recover 🔑'}
                  </button>
                </div>
                <div className="relative">
                  <span className={`absolute ${isRtl ? 'right-3.5' : 'left-3.5'} top-3.5 text-gray-400`}>
                    <Lock className="h-4 w-4" />
                  </span>
                  <input
                    type="password"
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="******"
                    className={`w-full rounded-xl border border-slate-200 bg-slate-50 py-3 text-xs outline-none focus:bg-white focus:border-teal-500 ${
                      isRtl ? 'pr-10 pl-4 text-right' : 'pl-10 pr-4 text-left'
                    }`}
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full rounded-xl bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 py-3 text-xs font-bold text-white shadow-lg shadow-teal-600/10 transition cursor-pointer"
                id="submit-login-credentials"
              >
                {isLoading ? t.auth.loading : t.auth.loginBtn}
              </button>
            </form>
          ) : (
            // Form Registration/Signup
            <form onSubmit={handleRegisterSubmit} className="space-y-4 text-right">
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-500">{t.auth.name}</label>
                <div className="relative">
                  <span className={`absolute ${isRtl ? 'right-3.5' : 'left-3.5'} top-3.5 text-gray-400`}>
                    <UserIcon className="h-4 w-4" />
                  </span>
                  <input
                    type="text"
                    required
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder="Ali Ahmed Hassan"
                    className={`w-full rounded-xl border border-slate-200 bg-slate-50 py-3 text-xs outline-none focus:bg-white focus:border-teal-500 animate-transition ${
                      isRtl ? 'pr-10 pl-4 text-right' : 'pl-10 pr-4 text-left'
                    }`}
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-500">{t.auth.email}</label>
                <div className="relative">
                  <span className={`absolute ${isRtl ? 'right-3.5' : 'left-3.5'} top-3.5 text-gray-400`}>
                    <Mail className="h-4 w-4" />
                  </span>
                  <input
                    type="email"
                    required
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="email@example.com"
                    className={`w-full rounded-xl border border-slate-200 bg-slate-50 py-3 text-xs outline-none focus:bg-white focus:border-teal-500 ${
                      isRtl ? 'pr-10 pl-4 text-right' : 'pl-10 pr-4 text-left'
                    }`}
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-500">{t.auth.password}</label>
                <div className="relative">
                  <span className={`absolute ${isRtl ? 'right-3.5' : 'left-3.5'} top-3.5 text-gray-400`}>
                    <Lock className="h-4 w-4" />
                  </span>
                  <input
                    type="password"
                    required
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="******"
                    className={`w-full rounded-xl border border-slate-200 bg-slate-50 py-3 text-xs outline-none focus:bg-white focus:border-teal-500 ${
                      isRtl ? 'pr-10 pl-4 text-right' : 'pl-10 pr-4 text-left'
                    }`}
                  />
                </div>
                {regPassword && (
                  <div className="space-y-1 pt-1 text-right">
                    <div className="text-[10px] text-gray-500 font-bold">
                      {lang === 'ar' ? 'متانة كلمة المرور:' : 'Password Strength:'}{' '}
                      <span className="font-extrabold text-slate-800">{checkPasswordStrength(regPassword).text}</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-850 rounded-full overflow-hidden mt-0.5">
                      <div className={`h-full ${checkPasswordStrength(regPassword).color} transition-all duration-300`}></div>
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-500">{t.auth.academicYear}</label>
                <select
                  value={regAcademic}
                  onChange={(e) => setRegAcademic(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-white p-3 text-xs focus:border-teal-500 outline-none cursor-pointer"
                >
                  <option value="المرحلة الأولى - جامعة البصرة">{t.auth.studentPhase1}</option>
                  <option value="المرحلة الثانية - جامعة البصرة">{t.auth.studentPhase2}</option>
                  <option value="المرحلة الثالثة - جامعة البصرة">{t.auth.studentPhase3}</option>
                  <option value="المرحلة الرابعة - جامعة البصرة">{t.auth.studentPhase4}</option>
                  <option value="خريج هندسة كيميائية وبتروكيماويات">{t.auth.graduate}</option>
                  <option value="مهندس ممارس في القطاع النفطي / الصناعي بالبصرة">{t.auth.practitioner}</option>
                </select>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full rounded-xl bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 py-3 text-xs font-bold text-white shadow-lg transition cursor-pointer"
                id="submit-register-credentials"
              >
                {isLoading ? t.auth.loading : t.auth.registerBtn}
              </button>

              </form>
          )}

          <div className="text-[10px] text-center text-gray-400 font-light">
            {t.auth.agreeDetails}
          </div>

        </div>
      </div>

      {/* PASSWORD RECOVERY MODAL */}
      {isResetOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs font-sans animate-fade-in" dir="rtl">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="w-full max-w-md bg-white rounded-3xl border border-slate-200 p-8 shadow-2xl relative text-right space-y-6"
          >
            <div className="flex flex-col items-center text-center space-y-3">
              <div className="bg-teal-50 p-4 rounded-full text-teal-600">
                <Sparkles className="h-8 w-8 animate-pulse" />
              </div>
              <h3 className="text-xl font-bold text-slate-850">استعادة كلمة المرور للمنصة</h3>
              <p className="text-xs text-gray-500 leading-relaxed max-w-sm">
                يرجى إدخال بريدك الإلكتروني المعتمد لنرسل لك رابط إعادة تعيين آمن عبر خوادم Firebase المعتمدة.
              </p>
            </div>

            {resetSuccess ? (
              <div className="p-4 rounded-xl bg-teal-50 border border-teal-200 text-teal-800 text-xs text-center font-bold">
                {resetSuccess}
              </div>
            ) : (
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  setResetError('');
                  setResetSuccess('');
                  if (!resetEmail.trim()) {
                    setResetError('الرجاء إدخال البريد الإلكتروني');
                    return;
                  }
                  try {
                    const res = await fetch(getApiUrl('/api/auth/reset-password'), {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ email: resetEmail })
                    });
                    const d = await res.json();
                    if (res.ok) {
                      setResetSuccess(d.message || 'تم إرسال رابط استعادة كلمة المرور بنجاح إلى بريدك المعتمد. يرجى التحقق من البريد الوارد.');
                    } else {
                      setResetError(d.error || 'فشلت الخدمة، يرجى التحقق من كتابة بريدك بشكل صحيح.');
                    }
                  } catch (err) {
                    setResetError('خطأ اتصال بالخادم المعتمد.');
                  }
                }}
                className="space-y-4"
              >
                {resetError && (
                  <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-650 text-xs text-center font-bold">
                    {resetError}
                  </div>
                )}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-500">البريد الإلكتروني المعتمد:</label>
                  <input
                    type="email"
                    required
                    value={resetEmail}
                    onChange={(e) => setResetEmail(e.target.value)}
                    placeholder="example@gmail.com"
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 p-3.5 text-xs text-left outline-none focus:bg-white focus:border-teal-500 font-mono"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full rounded-xl bg-teal-600 hover:bg-teal-700 py-3 text-xs font-bold text-white shadow-lg shadow-teal-605/10 transition cursor-pointer"
                >
                  إرسال رابط استعادة آمن عبر البريد
                </button>
              </form>
            )}

            <button
              onClick={() => setIsResetOpen(false)}
              className="w-full text-center py-2.5 bg-slate-50 hover:bg-slate-100 font-bold text-xs text-slate-650 border border-slate-200 rounded-xl transition cursor-pointer"
            >
              إغلاق النافذة
            </button>
          </motion.div>
        </div>
      )}

      {/* 2FA PIN INPUT MODAL */}
      {require2FaStep && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs font-sans animate-fade-in" dir="rtl">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="w-full max-w-[440px] bg-white rounded-3xl border border-slate-200 p-8 shadow-2xl relative text-right space-y-6"
          >
            <div className="flex flex-col items-center text-center space-y-3">
              <div className="bg-teal-50 p-4 rounded-full text-teal-600">
                <Lock className="h-8 w-8 animate-bounce" />
              </div>
              <h3 className="text-xl font-bold text-slate-850">تحقق الأمان ثنائي الخطوات (2FA)</h3>
              <p className="text-xs text-gray-500 leading-relaxed max-w-sm">
                تم تفعيل ميزة الأمان الإضافي لهذا الحساب من قبل الكادر الفني للهيئة. يرجى فتح تطبيق <strong>Google Authenticator</strong> وإدخال الرمز الدوار المكون من 6 أرقام:
              </p>
            </div>

            <form
              onSubmit={async (e) => {
                e.preventDefault();
                setTwoFactorError('');
                if (!twoFactorPin.trim() || twoFactorPin.length !== 6) {
                  setTwoFactorError('يرجى إدخال الرمز المكون من 6 أرقام بشكل كامل.');
                  return;
                }
                try {
                  const res = await fetch(getApiUrl('/api/auth/2fa/verify'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ userId: twoFactorUserId, code: twoFactorPin })
                  });
                  const d = await res.json();
                  if (res.ok) {
                    setRequire2FaStep(false);
                    onLoginSuccess(d);
                  } else {
                    setTwoFactorError(d.error || 'رمز التحقق ثنائي الأمان غير صحيح، يرجى إعادة التحقق من تطبيق Google Authenticator.');
                  }
                } catch (err) {
                  setTwoFactorError('فشل الاتصال بخادم الأمن الموثوق.');
                }
              }}
              className="space-y-4"
            >
              {twoFactorError && (
                <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-650 text-xs text-center font-bold">
                  {twoFactorError}
                </div>
              )}
              <div className="space-y-2">
                <input
                  type="text"
                  maxLength={6}
                  required
                  autoFocus
                  value={twoFactorPin}
                  onChange={(e) => setTwoFactorPin(e.target.value.replace(/\D/g, ''))}
                  placeholder="000000"
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 p-4 text-center tracking-widest text-xl font-bold outline-none focus:bg-white focus:border-teal-500 font-mono text-slate-850"
                />
              </div>
              <button
                type="submit"
                className="w-full rounded-xl bg-teal-600 hover:bg-teal-700 py-3 text-xs font-bold text-white shadow-lg transition cursor-pointer"
              >
                تأكيد ومتابعة الدخول الآمن 🛡️
              </button>
            </form>

            <button
              onClick={() => {
                setRequire2FaStep(false);
                setTwoFactorPin('');
                setTwoFactorError('');
              }}
              className="w-full text-center py-2.5 bg-slate-50 hover:bg-slate-100 font-bold text-xs text-slate-650 border border-slate-200 rounded-xl transition cursor-pointer"
            >
              إلغاء والرجوع
            </button>
          </motion.div>
        </div>
      )}
    </div>
  );
}

// Inline Google translations for beautiful integration
const googleT = {
  ar: {
    or: 'أو',
    signInWithGoogle: 'تسجيل الدخول باستخدام Google',
    signUpWithGoogle: 'سجل حساب جديد عبر Google',
    modalTitle: 'تسجيل دخول آمن عبر Google',
    modalSubtitle: 'أدخل بريدك الإلكتروني للمتابعة إلى بوابة كيميائيي البصرة الرقمية',
    useAnother: 'استخدام حساب آخر',
    enterEmail: 'أدخل بريد Google الإلكتروني الخاص بك:',
    next: 'التالي',
    cancel: 'إلغاء',
    back: 'رجوع',
    emailPlat: 'مثال: alias@gmail.com',
    passwordTitle: 'تأكيد هوية المشرف لإكمال الدخول',
    passwordDesc: 'هذا البريد الإلكتروني مسجل كمسؤول عام في الهيئة. يرجى إدخال كلمة سر المشرف لمتابعة الإدارة الآمنة والولوج للوحة التحكم:',
    passwordPlat: 'أدخل كلمة سر المشرف المعتمدة',
    submitBtn: 'تأكيد وتسجيل الدخول',
    testingNotice: 'تنبيه: يمكنك استخدام أي بريد تجريبي أو بريدك الشخصي، وفي حال استخدام البريد المعتمد للمشرفين سيطلب منك كلمة مرور الإدارة لتأمين الصلاحيات.'
  },
  en: {
    or: 'OR',
    signInWithGoogle: 'Sign in with Google',
    signUpWithGoogle: 'Sign up with Google',
    modalTitle: 'Secure Google Sign-In',
    modalSubtitle: 'Enter your Google email to continue to Basra Chemists Portal',
    useAnother: 'Use another account',
    enterEmail: 'Enter your Google email address:',
    next: 'Next',
    cancel: 'Cancel',
    back: 'Back',
    emailPlat: 'e.g. alias@gmail.com',
    passwordTitle: 'Verify Admin Credentials',
    passwordDesc: 'This email is recognized as an authorized general administrator. Please enter the supervisor password to proceed with secure admin dashboard access:',
    passwordPlat: 'Enter supervisor password',
    submitBtn: 'Verify & Sign In',
    testingNotice: 'Note: You can use any test email or your personal email under Google login. Using authorized admin emails requires the admin password to verify privileges.'
  },
  de: {
    or: 'ODER',
    signInWithGoogle: 'Mit Google anmelden',
    signUpWithGoogle: 'Erstellen Sie ein Konto mit Google',
    modalTitle: 'Sichere Google-Anmeldung',
    modalSubtitle: 'Geben Sie Ihre Google-E-Mail-Adresse ein, um fortzufahren',
    useAnother: 'Anderes Konto verwenden',
    enterEmail: 'Geben Sie Ihre Google-E-Mail-Adresse ein:',
    next: 'Weiter',
    cancel: 'Abbrechen',
    back: 'Zurück',
    emailPlat: 'z.B. alias@gmail.com',
    passwordTitle: 'Admin-Anmeldeinformationen überprüfen',
    passwordDesc: 'Diese E-Mail ist als autorisierter Administrator registriert. Bitte geben Sie das Administrator-Passwort ein, um fortzufahren:',
    passwordPlat: 'Passwort eingeben',
    submitBtn: 'Bestätigen & Einloggen',
    testingNotice: 'Hinweis: Jeder normale Account benötigt kein Passwort. Nur autorisierte Admin-E-Mails verlangen das Admin-Passwort zum Schutz.'
  },
  es: {
    or: 'O BIEN',
    signInWithGoogle: 'Iniciar sesión con Google',
    signUpWithGoogle: 'Registrarse con Google',
    modalTitle: 'Iniciar sesión con Google de forma segura',
    modalSubtitle: 'Ingresa tu correo de Google para continuar al portal de químicos de Basora',
    useAnother: 'Usar otra cuenta',
    enterEmail: 'Ingresa tu correo de Google:',
    next: 'Siguiente',
    cancel: 'Cancelar',
    back: 'Atrás',
    emailPlat: 'ej. alias@gmail.com',
    passwordTitle: 'Verificar credenciales de administrador',
    passwordDesc: 'Este correo está reconocido como administrador general. Por favor ingresa la contraseña para continuar:',
    passwordPlat: 'Contraseña de administrador',
    submitBtn: 'Verificar e iniciar sesión',
    testingNotice: 'Nota: Puede usar cualquier correo personal para iniciar sesión. Si es el correo del administrador, ingresará la clave de administración.'
  }
};
