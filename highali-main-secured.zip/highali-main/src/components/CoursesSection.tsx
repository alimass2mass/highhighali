/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Award, BookOpen, Clock, Calendar, ExternalLink, Plus, Trash2, Search, ArrowUp, ArrowDown, Edit } from 'lucide-react';
import { Course, User } from '../types';
import { motion } from 'motion/react';
import { LanguageType } from '../locales';

interface CoursesSectionProps {
  currentUser: User | null;
  courses: Course[];
  onAddCourse: (course: { title: string; url: string; description?: string; instructor?: string }) => void;
  onDeleteCourse: (id: string) => void;
  onEditCourse?: (id: string, updated: Partial<Course>) => void;
  onReorderCourses?: (orderedIds: string[]) => void;
  lang: LanguageType;
  t: any;
}

export default function CoursesSection({ 
  currentUser, 
  courses, 
  onAddCourse, 
  onDeleteCourse, 
  onEditCourse,
  onReorderCourses,
  lang, 
  t 
}: CoursesSectionProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newUrl, setNewUrl] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newInstructor, setNewInstructor] = useState('');
  
  // Edit states
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editUrl, setEditUrl] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editInstructor, setEditInstructor] = useState('');

  const [errorMsg, setErrorMsg] = useState('');

  const isAdmin = currentUser?.role === 'admin';

  const handleMoveUp = (courseId: string) => {
    const trueIndex = courses.findIndex(c => c.id === courseId);
    if (trueIndex <= 0) return;
    const reordered = [...courses];
    const temp = reordered[trueIndex];
    reordered[trueIndex] = reordered[trueIndex - 1];
    reordered[trueIndex - 1] = temp;
    if (onReorderCourses) {
      onReorderCourses(reordered.map(c => c.id));
    }
  };

  const handleMoveDown = (courseId: string) => {
    const trueIndex = courses.findIndex(c => c.id === courseId);
    if (trueIndex === -1 || trueIndex === courses.length - 1) return;
    const reordered = [...courses];
    const temp = reordered[trueIndex];
    reordered[trueIndex] = reordered[trueIndex + 1];
    reordered[trueIndex + 1] = temp;
    if (onReorderCourses) {
      onReorderCourses(reordered.map(c => c.id));
    }
  };

  const startEdit = (course: Course) => {
    setEditingCourse(course);
    setEditTitle(course.title);
    setEditUrl(course.url);
    setEditDescription(course.description || '');
    setEditInstructor(course.instructor || '');
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCourse) return;
    if (!editTitle.trim() || !editUrl.trim()) {
      setErrorMsg(t.courses.addModal.errorFill);
      return;
    }
    if (onEditCourse) {
      onEditCourse(editingCourse.id, {
        title: editTitle,
        url: editUrl,
        description: editDescription,
        instructor: editInstructor
      });
    }
    setEditingCourse(null);
    setErrorMsg('');
  };

  const filteredCourses = courses.filter(c => 
    c.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    (c.description && c.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
    (c.instructor && c.instructor.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newUrl.trim()) {
      setErrorMsg(t.courses.addModal.errorFill);
      return;
    }
    onAddCourse({
      title: newTitle,
      url: newUrl,
      description: newDescription,
      instructor: newInstructor || 'لجنة التدريب بالهيئة'
    });
    // Reset states
    setNewTitle('');
    setNewUrl('');
    setNewDescription('');
    setNewInstructor('');
    setErrorMsg('');
    setShowAddModal(false);
  };

  const isRtl = t.dir === 'rtl';

  return (
    <div className="space-y-6" dir={t.dir}>
      {/* Header section with search & optional Admin additions button */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">{t.courses.title}</h1>
          <p className="text-sm text-gray-500">{t.courses.desc}</p>
        </div>
        
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="relative flex-1 sm:flex-initial">
            <input
              type="text"
              placeholder={t.courses.search}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full sm:w-64 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs outline-none focus:border-teal-500"
            />
          </div>
          {isAdmin && (
            <button
              onClick={() => setShowAddModal(true)}
              className="rounded-xl bg-teal-600 hover:bg-teal-700 font-bold text-white text-xs px-4 py-2.5 inline-flex items-center gap-1.5 shrink-0 transition cursor-pointer"
              id="admin-open-add-course"
            >
              <Plus className="h-4 w-4" />
              <span>{t.courses.newCourseBtn}</span>
            </button>
          )}
        </div>
      </div>

      {/* Courses Cards Grid */}
      {filteredCourses.length > 0 ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredCourses.map((course) => (
            <motion.div
              layout
              whileHover={{ y: -4 }}
              key={course.id}
              className="rounded-2xl border border-slate-100 bg-white p-6 shadow-xs relative flex flex-col justify-between h-[250px] hover:shadow-md transition text-right"
              id={`course-card-${course.id}`}
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <span className="p-2 rounded-xl bg-teal-50 text-teal-800">
                    <Award className="h-5 w-5" />
                  </span>
                  
                  {isAdmin && (
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleMoveUp(course.id)}
                        className="p-1.5 rounded-lg bg-slate-50 text-slate-500 hover:bg-slate-100 transition cursor-pointer"
                        title="Move Up"
                        id={`move-up-course-${course.id}`}
                      >
                        <ArrowUp className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => handleMoveDown(course.id)}
                        className="p-1.5 rounded-lg bg-slate-50 text-slate-500 hover:bg-slate-100 transition cursor-pointer"
                        title="Move Down"
                        id={`move-down-course-${course.id}`}
                      >
                        <ArrowDown className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => startEdit(course)}
                        className="p-1.5 rounded-lg bg-teal-50 text-teal-600 hover:bg-teal-100 transition cursor-pointer"
                        title="Edit Course"
                        id={`edit-course-btn-${course.id}`}
                      >
                        <Edit className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => onDeleteCourse(course.id)}
                        className="p-1.5 rounded-lg bg-red-50 text-red-500 hover:bg-red-100 hover:text-red-600 transition cursor-pointer"
                        title="Delete Course Template"
                        id={`delete-course-btn-${course.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  )}
                </div>

                <div className="space-y-1">
                  <h3 className="text-sm font-extrabold text-slate-800 line-clamp-2 leading-relaxed">
                    {course.title}
                  </h3>
                  <p className="text-xs text-gray-400 font-semibold">{t.courses.instructor} {course.instructor}</p>
                </div>

                {course.description && (
                  <p className="text-[11px] text-gray-500 line-clamp-3 leading-relaxed font-light">
                    {course.description}
                  </p>
                )}
              </div>

              <div className="pt-4 border-t border-slate-50 flex items-center justify-between mt-3">
                <span className="text-[9px] text-gray-400 font-mono">
                  {new Date(course.addedAt).toLocaleDateString(lang === 'ar' ? 'ar-IQ' : 'en-US')}
                </span>
                
                <a
                  href={course.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs text-teal-600 bg-teal-50 hover:bg-teal-100 px-3.5 py-1.5 rounded-xl font-bold transition"
                  id={`access-course-link-${course.id}`}
                >
                  <span>{t.courses.accessBtn}</span>
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="rounded-3xl border border-dashed border-slate-200 bg-white p-12 text-center text-gray-400 space-y-3">
          <BookOpen className="h-12 w-12 stroke-1 opacity-50 mx-auto" />
          <p className="text-sm font-light">{t.courses.noCourses}</p>
        </div>
      )}

      {/* Add Course Modal Overlay */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/40 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-2xl bg-white border border-slate-100 p-6 shadow-2xl space-y-4">
            <h3 className="text-sm font-extrabold text-slate-800">{t.courses.addModal.title}</h3>
            
            <form onSubmit={handleSubmit} className="space-y-3 text-right">
              {errorMsg && (
                <div className="p-3 rounded-lg bg-red-105 text-red-700 text-xs text-center font-bold">
                  {errorMsg}
                </div>
              )}

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">{t.courses.addModal.nameLabel}</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder={t.courses.addModal.namePlaceholder}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs outline-none focus:border-teal-500 focus:bg-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">{t.courses.addModal.urlLabel}</label>
                <input
                  type="url"
                  value={newUrl}
                  onChange={(e) => setNewUrl(e.target.value)}
                  placeholder={t.courses.addModal.urlPlaceholder}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs outline-none focus:border-teal-500 focus:bg-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">{t.courses.addModal.instructorLabel}</label>
                <input
                  type="text"
                  value={newInstructor}
                  onChange={(e) => setNewInstructor(e.target.value)}
                  placeholder={t.courses.addModal.instructorPlaceholder}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs outline-none focus:border-teal-500 focus:bg-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">{t.courses.addModal.descLabel}</label>
                <textarea
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  placeholder={t.courses.addModal.descPlaceholder}
                  className="w-full h-24 rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs outline-none focus:border-teal-500 focus:bg-white resize-none"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs py-2.5 transition cursor-pointer"
                  id="submit-add-course"
                >
                  {t.courses.addModal.confirmBtn}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setErrorMsg('');
                  }}
                  className="flex-1 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs py-2.5 transition cursor-pointer"
                >
                  {t.courses.addModal.cancelBtn}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {editingCourse && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/40 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-2xl bg-white border border-slate-100 p-6 md:p-8 shadow-2xl relative space-y-4">
            <h3 className="text-md font-extrabold text-slate-800 text-right">تعديل الدورة التدريبية</h3>
            <form onSubmit={handleEditSubmit} className="space-y-4 text-right">
              {errorMsg && (
                <div className="p-3 rounded-lg bg-red-100 text-red-700 text-xs text-center font-bold">
                  {errorMsg}
                </div>
              )}

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">{t.courses.addModal.nameLabel}</label>
                <input
                  type="text"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs outline-none focus:border-teal-500 focus:bg-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">{t.courses.addModal.urlLabel}</label>
                <input
                  type="url"
                  value={editUrl}
                  onChange={(e) => setEditUrl(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs outline-none focus:border-teal-500 focus:bg-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">{t.courses.addModal.instructorLabel}</label>
                <input
                  type="text"
                  value={editInstructor}
                  onChange={(e) => setEditInstructor(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs outline-none focus:border-teal-500 focus:bg-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-650 block text-right">{t.courses.addModal.descLabel}</label>
                <textarea
                  value={editDescription}
                  onChange={(e) => setEditDescription(e.target.value)}
                  className="w-full h-24 rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs outline-none focus:border-teal-500 focus:bg-white resize-none"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs py-2.5 transition cursor-pointer"
                  id="submit-edit-course"
                >
                  حفظ التعديلات
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setEditingCourse(null);
                    setErrorMsg('');
                  }}
                  className="flex-1 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs py-2.5 transition cursor-pointer"
                >
                  {t.courses.addModal.cancelBtn}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
