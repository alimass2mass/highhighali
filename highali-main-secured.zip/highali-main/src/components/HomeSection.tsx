/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BookOpen, Monitor, Award, Heart, ShieldAlert, ChevronLeft, Volume2, Landmark, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';
import { LanguageType } from '../locales';

interface HomeSectionProps {
  onNavigate: (section: string) => void;
  lang: LanguageType;
  t: any;
  stats: {
    platformsCount: number;
    coursesCount: number;
    resourcesCount: number;
    activeUsersCount: number;
  };
}

export default function HomeSection({ onNavigate, lang, t, stats }: HomeSectionProps) {
  const isRtl = t.dir === 'rtl';

  const statsItems = [
    {
      title: t.home.stats.labs,
      value: stats.platformsCount,
      unit: lang === 'ar' ? 'منصات ومحاكيات كيميائية' : 'Chemical Simulator Systems',
      bg: 'bg-white dark:bg-slate-900',
      border: 'border-emerald-500/20 hover:border-emerald-500/40 dark:border-slate-800',
      text: 'text-emerald-700 dark:text-emerald-400',
      iconColor: 'text-emerald-500 bg-emerald-50 dark:bg-emerald-950/30',
      icon: Monitor,
      section: 'platforms'
    },
    {
      title: t.home.stats.courses,
      value: stats.coursesCount,
      unit: lang === 'ar' ? 'حقائب ودورات تدريبية تخصصية' : 'Certified Training Programs',
      bg: 'bg-white dark:bg-slate-900',
      border: 'border-teal-500/20 hover:border-teal-500/40 dark:border-slate-800',
      text: 'text-teal-700 dark:text-teal-400',
      iconColor: 'text-teal-500 bg-teal-50 dark:bg-teal-950/30',
      icon: Award,
      section: 'courses'
    },
    {
      title: t.home.stats.resources,
      value: stats.resourcesCount,
      unit: lang === 'ar' ? 'إصدارات ومراجع علمية ضخمة' : 'Methodological Resources',
      bg: 'bg-white dark:bg-slate-900',
      border: 'border-cyan-500/20 hover:border-cyan-500/40 dark:border-slate-800',
      text: 'text-cyan-700 dark:text-cyan-400',
      iconColor: 'text-cyan-500 bg-cyan-50 dark:bg-cyan-950/30',
      icon: BookOpen,
      section: 'resources'
    },
    {
      title: t.home.stats.members,
      value: stats.activeUsersCount,
      unit: t.home.stats.membersUnit,
      bg: 'bg-white dark:bg-slate-900',
      border: 'border-amber-500/20 hover:border-amber-500/40 dark:border-slate-800',
      text: 'text-amber-700 dark:text-amber-400',
      iconColor: 'text-amber-500 bg-amber-50 dark:bg-amber-950/30',
      icon: Heart,
      section: 'about' // Navigates to AboutSection where developer & members are celebrated
    }
  ];

  return (
    <div className="space-y-6 md:space-y-8" dir={t.dir}>
      {/* Welcome Banner */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-teal-900 to-emerald-950 p-6 text-white shadow-xl md:p-12 border border-slate-800"
      >
        <div className="absolute top-0 right-0 h-full w-1/3 bg-[url('https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=600')] bg-cover opacity-10 bg-blend-overlay"></div>
        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 rounded-full bg-teal-500/10 border border-teal-500/20 px-3 py-1 text-xs font-semibold text-teal-300 backdrop-blur-md">
            <span className="h-2 w-2 rounded-full bg-teal-400 animate-pulse"></span>
            <Landmark className="h-3.5 w-3.5" />
            {t.certifiedPlatform || 'منصة معتمدة وموثقة'}
          </div>
          <h1 className="text-2xl font-black tracking-tight md:text-5xl leading-tight text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-teal-100">
            {t.home.title}
          </h1>
          <p className="text-xs md:text-base font-light text-slate-300 leading-relaxed max-w-2xl">
            {t.home.subtitle}
          </p>
          <div className="pt-4 flex flex-wrap gap-3">
            <button
              onClick={() => onNavigate('platforms')}
              className="flex items-center gap-2 rounded-xl bg-teal-500 hover:bg-teal-600 px-5 py-3 text-xs font-bold text-slate-950 shadow-md shadow-teal-500/10 transition cursor-pointer"
              id="home-explore-platforms-btn"
            >
              {t.home.explorePlatforms}
              {isRtl ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
            </button>
            <button
              onClick={() => onNavigate('about')}
              className="rounded-xl border border-slate-700 bg-slate-800/40 px-5 py-3 text-xs font-bold text-white hover:bg-slate-800 transition cursor-pointer"
              id="home-about-btn"
            >
              {t.home.whoAreWe}
            </button>
          </div>
        </div>
      </motion.div>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {statsItems.map((item, idX) => (
          <motion.div
            key={idX}
            onClick={() => onNavigate(item.section)}
            whileHover={{ y: -3, scale: 1.01 }}
            className={`cursor-pointer rounded-2xl border ${item.bg} ${item.border} p-5 shadow-xs transition flex flex-col justify-between h-[145px]`}
            id={`stat-card-${idX}`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">{item.title}</span>
              <span className={`p-2 rounded-lg ${item.iconColor}`}>
                <item.icon className="h-4 w-4" />
              </span>
            </div>
            <div className="mt-4 flex flex-col justify-end">
              {item.section === 'about' ? (
                <div className="flex items-baseline gap-1 flex-wrap">
                  <span className={`font-mono text-3xl font-black ${item.text}`}>
                    {item.value.toLocaleString()}
                  </span>
                  <span className="text-[10px] text-slate-400 font-bold">{item.unit}</span>
                </div>
              ) : (
                <div className="space-y-0.5">
                  <span className={`text-sm md:text-base font-extrabold leading-tight ${item.text} tracking-tight block font-sans`}>
                    {item.unit}
                  </span>
                  <span className="text-[9px] text-slate-400 dark:text-slate-500 font-semibold block">
                    {lang === 'ar' ? 'انقر لتصفح المحتوى' : 'Click to view details'}
                  </span>
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Main Content Layout Block (Announcements & Shortcuts) */}
      <div className="grid gap-6 md:grid-cols-3">
        {/* News & Announcements Bar */}
        <div className="md:col-span-2 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <h2 className="text-md font-extrabold text-slate-800 flex items-center gap-2">
              <Volume2 className="h-4.5 w-4.5 text-teal-600 animate-bounce" />
              {t.home.announcements}
            </h2>
            <span className="h-1.5 w-1.5 rounded-full bg-teal-500"></span>
          </div>
          
          <div className="space-y-4">
            {t.home.news.map((news: any, i: number) => {
              const bgs = ['bg-emerald-50 text-emerald-700 border-emerald-100', 'bg-teal-50 text-teal-700 border-teal-100', 'bg-cyan-50 text-cyan-700 border-cyan-100'];
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="rounded-2xl border border-slate-100 bg-white p-5 shadow-xs hover:shadow-md hover:border-slate-200 transition space-y-3 relative group"
                  id={`news-card-${i}`}
                >
                  <div className="flex items-center justify-between">
                    <span className={`rounded-xl px-2.5 py-0.5 text-[10px] border font-bold ${bgs[i % 3]}`}>
                      {news.tag}
                    </span>
                    <span className="text-[10px] text-slate-400 font-bold font-mono">{news.date}</span>
                  </div>
                  <h3 className="text-sm font-black text-slate-800 leading-snug group-hover:text-teal-700 transition-colors">
                    {news.title}
                  </h3>
                  <p className="text-xs text-slate-500 leading-relaxed font-light">{news.desc}</p>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Safety & Compliance Card */}
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <h2 className="text-md font-extrabold text-slate-800 flex items-center gap-2">
              <ShieldAlert className="h-4.5 w-4.5 text-amber-600" />
              {t.home.safety}
            </h2>
            <span className="h-1.5 w-1.5 rounded-full bg-amber-500"></span>
          </div>

          <div className="rounded-2xl border border-amber-100 bg-amber-50/40 p-5 space-y-4">
            <p className="text-xs font-semibold text-amber-900 leading-relaxed">
              {t.home.safetyText}
            </p>
            <div className="space-y-2 text-[11px] text-amber-800">
              {t.home.safetyPoints.map((point: string, idx: number) => (
                <div key={idx} className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-amber-500 shrink-0"></span>
                  <span>{point}</span>
                </div>
              ))}
            </div>
            <div className="pt-2">
              <button
                onClick={() => onNavigate('platforms')}
                className="w-full text-center text-xs font-bold text-teal-950 bg-teal-400 hover:bg-teal-500 py-2.5 rounded-xl transition cursor-pointer shadow-xs shadow-teal-500/10"
                id="home-visit-labs-shortcut"
              >
                {t.home.visitLabs}
              </button>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-xs space-y-3">
            <h3 className="text-xs font-black text-slate-850">{t.home.thakerActivity || 'محاكي الذاكر الرقمي للفصل الحراري'}</h3>
            <p className="text-[11px] text-slate-400 font-light leading-relaxed">
              {t.home.thakerDesc || 'الدخول المباشر لوحدات محاكاة مصنع الغاز وتقدير كفاءة المبادلات الحرارية بأساليب برمجية رصينة.'}
            </p>
            <button
              onClick={() => onNavigate('platforms')}
              className="text-xs font-bold text-teal-600 hover:text-teal-700 flex items-center gap-1 cursor-pointer"
              id="home-shortcut-thaker"
            >
              {t.home.openThaker || 'عرض المحاكي'}
              {isRtl ? <ChevronLeft className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
