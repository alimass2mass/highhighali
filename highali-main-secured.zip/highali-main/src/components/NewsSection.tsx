/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Newspaper, Plus, Trash2, MessageSquare, Calendar, Image as ImageIcon, 
  Video, Send, User as UserIcon, RefreshCw, X, AlertCircle, Play, Check, Sparkles
} from 'lucide-react';
import { NewsActivity, User } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { LanguageType } from '../locales';
import { getApiUrl } from '../lib/api';

interface NewsSectionProps {
  currentUser: User | null;
  lang: LanguageType;
  t: any;
}

export default function NewsSection({ currentUser, lang, t }: NewsSectionProps) {
  const [newsList, setNewsList] = useState<NewsActivity[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitLoading, setIsSubmitLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  
  // Create state
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'images' | 'videos'>('all');

  // Comment input state for each post
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  const [isCommentLoading, setIsCommentLoading] = useState<Record<string, boolean>>({});

  const isAdmin = currentUser?.role === 'admin';
  const isRtl = lang === 'ar';

  useEffect(() => {
    fetchNews();
  }, []);

  const fetchNews = async () => {
    setIsLoading(true);
    try {
      const resp = await fetch(getApiUrl('/api/news'));
      if (resp.ok) {
        const data = await resp.json();
        setNewsList(data);
      }
    } catch (err) {
      console.error('Error fetching news:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateNews = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) {
      setErrorMsg(isRtl ? 'الرجاء تعبئة العنوان والتفاصيل الأساسية.' : 'Please enter title and content.');
      return;
    }

    setIsSubmitLoading(true);
    setErrorMsg('');

    try {
      let finalVideoUrl = videoUrl.trim();
      // Auto-convert standard youtube watch URLs to embed URLs
      if (finalVideoUrl.includes('youtube.com/watch?v=')) {
        const videoId = finalVideoUrl.split('v=')[1]?.split('&')[0];
        if (videoId) finalVideoUrl = `https://www.youtube.com/embed/${videoId}`;
      } else if (finalVideoUrl.includes('youtu.be/')) {
        const videoId = finalVideoUrl.split('youtu.be/')[1]?.split('?')[0];
        if (videoId) finalVideoUrl = `https://www.youtube.com/embed/${videoId}`;
      }

      const resp = await fetch(getApiUrl('/api/news'), {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + (currentUser?.token || '')
        },
        body: JSON.stringify({
          title: title.trim(),
          content: content.trim(),
          imageUrl: imageUrl.trim() || undefined,
          videoUrl: finalVideoUrl || undefined
        })
      });

      if (resp.ok) {
        setTitle('');
        setContent('');
        setImageUrl('');
        setVideoUrl('');
        setIsCreateOpen(false);
        fetchNews();
      } else {
        const data = await resp.json();
        setErrorMsg(data.error || 'Failed to publish news.');
      }
    } catch (err) {
      setErrorMsg(isRtl ? 'حدث خطأ بالاتصال بالسيرفر.' : 'Server connection error.');
    } finally {
      setIsSubmitLoading(false);
    }
  };

  const handleDeleteNews = async (id: string) => {
    if (!window.confirm(isRtl ? 'هل أنت متأكد من حذف هذا النشاط نهائياً؟' : 'Are you sure you want to delete this activity?')) {
      return;
    }
    try {
      const resp = await fetch(getApiUrl(`/api/news/${id}`), { 
        method: 'DELETE',
        headers: {
          'Authorization': 'Bearer ' + (currentUser?.token || '')
        }
      });
      if (resp.ok) {
        setNewsList(prev => prev.filter(n => n.id !== id));
      }
    } catch (err) {
      console.error('Error deleting news:', err);
    }
  };

  const handlePostComment = async (postId: string) => {
    const commentText = commentInputs[postId]?.trim();
    if (!commentText) return;

    setIsCommentLoading(prev => ({ ...prev, [postId]: true }));
    try {
      const resp = await fetch(getApiUrl(`/api/news/${postId}/comments`), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userName: currentUser?.name || (isRtl ? 'زائر كيميائي' : 'Guest Chemist'),
          userEmail: currentUser?.email || 'guest@chemists-portal.local',
          content: commentText
        })
      });

      if (resp.ok) {
        const newC = await resp.json();
        setNewsList(prev => prev.map(post => {
          if (post.id === postId) {
            return {
              ...post,
              comments: [...(post.comments || []), newC]
            };
          }
          return post;
        }));
        setCommentInputs(prev => ({ ...prev, [postId]: '' }));
      }
    } catch (err) {
      console.error('Error posting comment:', err);
    } finally {
      setIsCommentLoading(prev => ({ ...prev, [postId]: false }));
    }
  };

  const handleDeleteComment = async (postId: string, commentId: string) => {
    if (!window.confirm(isRtl ? 'هل تريد حذف هذا التعليق؟' : 'Are you sure you want to delete this comment?')) {
      return;
    }
    try {
      const resp = await fetch(getApiUrl(`/api/news/${postId}/comments/${commentId}`), {
        method: 'DELETE'
      });
      if (resp.ok) {
        setNewsList(prev => prev.map(post => {
          if (post.id === postId) {
            return {
              ...post,
              comments: (post.comments || []).filter(c => c.id !== commentId)
            };
          }
          return post;
        }));
      }
    } catch (err) {
      console.error('Error deleting comment:', err);
    }
  };

  const filteredNewsList = newsList.filter(item => {
    if (activeTab === 'images') return !!item.imageUrl;
    if (activeTab === 'videos') return !!item.videoUrl;
    return true;
  });

  return (
    <div className="space-y-8" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Header section with description and Admin Action Trigger */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b pb-5 border-slate-100">
        <div>
          <h1 className="text-2xl font-black text-slate-800 tracking-tight flex items-center gap-2">
            <Newspaper className="h-6 w-6 text-teal-600" />
            <span>{isRtl ? 'الأخبار والنشاطات' : 'News & Activities'}</span>
          </h1>
          <p className="text-xs md:text-sm text-gray-500 mt-1">
            {isRtl 
              ? 'تغطية مستمرة وسجل حي لتحركات الهيئة العامة والأنشطة التأهيلية والزيارات الميدانية لمنتسبي الكيمياء في البصرة.' 
              : 'Continuous coverage and chronological record of GCE Basra events, field operations, and chemistry training.'}
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={() => setIsCreateOpen(!isCreateOpen)}
            className="rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-black text-xs px-4 py-2.5 inline-flex items-center gap-2 transition cursor-pointer self-start sm:self-auto shadow-sm"
          >
            <Plus className="h-4 w-4" />
            <span>{isRtl ? 'إضافة خبر/نشاط' : 'Publish Activity'}</span>
          </button>
        )}
      </div>

      {/* Admin Creator Workspace Form Drawer */}
      <AnimatePresence>
        {isCreateOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden bg-slate-50 rounded-3xl p-6 border border-slate-200/60 shadow-inner space-y-4"
          >
            <div className="flex justify-between items-center border-b pb-2 mb-2">
              <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
                <Sparkles className="h-4 w-4 text-emerald-500 animate-pulse" />
                <span>{isRtl ? 'صياغة ونشر نشاط جديد للهيئة' : 'Publish GCE Official Activity'}</span>
              </h3>
              <button 
                onClick={() => setIsCreateOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-200 transition text-slate-400"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {errorMsg && (
              <div className="p-3 bg-red-50 text-red-600 rounded-xl text-xs flex items-center gap-2 font-bold font-mono">
                <AlertCircle className="h-4 w-4 text-red-500 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleCreateNews} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-1 text-right">
                  <label className="text-xs font-bold text-gray-600 block">{isRtl ? 'عنوان الخبر / النشاط:' : 'Activity Title:'}</label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder={isRtl ? 'مثال: جولة ميدانية تفقدية للمهندسين في مصفى الشعيبة' : 'e.g., Direct field training inside Basra Refinery'}
                    className="w-full text-xs rounded-xl border border-slate-200 bg-white px-3 py-2.5 outline-none focus:border-teal-500"
                  />
                </div>

                <div className="space-y-1 text-right">
                  <label className="text-xs font-bold text-gray-600 block">{isRtl ? 'رابط الصورة المرفقة (اختياري):' : 'Attached Photo URL (Optional):'}</label>
                  <input
                    type="url"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    placeholder="https://images.unsplash.com/photo-..."
                    className="w-full text-xs font-mono rounded-xl border border-slate-200 bg-white px-3 py-2.5 outline-none focus:border-teal-500 text-left"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-1 text-right">
                  <label className="text-xs font-bold text-gray-600 block">
                    {isRtl ? 'رابط مقطع فيديو من يوتيوب (اختياري):' : 'YouTube Video URL (Optional):'}
                  </label>
                  <input
                    type="url"
                    value={videoUrl}
                    onChange={(e) => setVideoUrl(e.target.value)}
                    placeholder="https://www.youtube.com/watch?v=..."
                    className="w-full text-xs font-mono rounded-xl border border-slate-200 bg-white px-3 py-2.5 outline-none focus:border-teal-500 text-left"
                  />
                </div>

                <div className="space-y-1 text-right md:col-span-2">
                  <label className="text-xs font-bold text-gray-600 block">{isRtl ? 'تفاصيل ونص النشاط بالكامل:' : 'Detailed Body / Core Content:'}</label>
                  <textarea
                    rows={4}
                    required
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder={isRtl ? 'اكتب بالتفصيل تحركات الهيئة والتوصيات والقرارات والتعليق الفني المصاحب للفعالية هنا...' : 'Describe GCE movements, scientific goals achieved, and technical commentary...'}
                    className="w-full text-xs rounded-xl border border-slate-200 bg-white px-3 py-2.5 outline-none focus:border-teal-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="submit"
                  disabled={isSubmitLoading}
                  className="rounded-xl bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 font-bold text-white text-xs px-5 py-3 transition inline-flex items-center gap-1.5 cursor-pointer"
                >
                  {isSubmitLoading ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                  <span>{isRtl ? 'نشر وتعميم الخبر للجميع' : 'Publish & Broadcast'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsCreateOpen(false)}
                  className="rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 text-xs px-4 py-3 transition cursor-pointer"
                >
                  {isRtl ? 'إلغاء' : 'Cancel'}
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Feed Category Filter Tabs */}
      <div className="flex border-b border-gray-100 pb-px">
        <div className="flex gap-4">
          <button
            onClick={() => setActiveTab('all')}
            className={`pb-3 text-xs md:text-sm font-black transition relative cursor-pointer ${
              activeTab === 'all' ? 'text-teal-600' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <span>{isRtl ? 'كافة النشاطات' : 'All Activities'}</span>
            {activeTab === 'all' && <motion.div layoutId="news-tab-indicator" className="absolute bottom-0 left-0 right-0 h-0.5 bg-teal-600 rounded-full" />}
          </button>

          <button
            onClick={() => setActiveTab('images')}
            className={`pb-3 text-xs md:text-sm font-black transition relative cursor-pointer ${
              activeTab === 'images' ? 'text-teal-600' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <span className="inline-flex items-center gap-1.5">
              <ImageIcon className="h-3.5 w-3.5" />
              <span>{isRtl ? 'المنشورات الصورية' : 'Photo Journals'}</span>
            </span>
            {activeTab === 'images' && <motion.div layoutId="news-tab-indicator" className="absolute bottom-0 left-0 right-0 h-0.5 bg-teal-600 rounded-full" />}
          </button>

          <button
            onClick={() => setActiveTab('videos')}
            className={`pb-3 text-xs md:text-sm font-black transition relative cursor-pointer ${
              activeTab === 'videos' ? 'text-teal-600' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <span className="inline-flex items-center gap-1.5">
              <Video className="h-3.5 w-3.5" />
              <span>{isRtl ? 'تغطيات الفيديو والمحاكيات' : 'Video Portals'}</span>
            </span>
            {activeTab === 'videos' && <motion.div layoutId="news-tab-indicator" className="absolute bottom-0 left-0 right-0 h-0.5 bg-teal-600 rounded-full" />}
          </button>
        </div>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 gap-3">
          <RefreshCw className="h-8 w-8 text-teal-500 animate-spin" />
          <p className="text-xs text-gray-400 font-bold">{isRtl ? 'جاري سحب التغطية الإخبارية...' : 'Pulling news feed...'}</p>
        </div>
      ) : filteredNewsList.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-3xl border border-slate-100/60 p-6 space-y-2">
          <Newspaper className="h-12 w-12 text-slate-300 mx-auto" />
          <h3 className="text-sm font-bold text-slate-700">{isRtl ? 'لا توجد نشاطات مسجلة حالياً' : 'No activities broadcasted yet'}</h3>
          <p className="text-xs text-gray-400 max-w-sm mx-auto">
            {isRtl ? 'سيقوم وكلاء وممثلو الهيئة برفع التقارير والصور والملاحظات فور انعقادها.' : 'Reports, multimedia journals and logs will be posted as GCE developments occur.'}
          </p>
        </div>
      ) : (
        /* The News Feed Cards Grid */
        <div className="space-y-8 max-w-4xl mx-auto">
          {filteredNewsList.map((item, index) => (
            <motion.article
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
              key={item.id}
              className="bg-white rounded-3xl border border-slate-100/80 shadow-xs overflow-hidden flex flex-col transition hover:border-slate-200"
            >
              {/* Media rendering header section (Image or Video player) */}
              {item.videoUrl && (
                <div className="aspect-video w-full bg-black relative max-h-[440px]">
                  <iframe
                    src={item.videoUrl}
                    title={item.title}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="absolute top-0 left-0 w-full h-full border-0"
                  />
                </div>
              )}

              {!item.videoUrl && item.imageUrl && (
                <div className="relative w-full aspect-video md:max-h-[380px] overflow-hidden bg-slate-100">
                  <img
                    src={item.imageUrl}
                    alt={item.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-103"
                  />
                  <div className="absolute top-4 right-4 bg-teal-900/80 text-white backdrop-blur-xs text-[10px] uppercase tracking-wider font-extrabold px-3 py-1.5 rounded-full inline-flex items-center gap-1">
                    <ImageIcon className="h-3.5 w-3.5 text-teal-300" />
                    <span>{isRtl ? 'صورة ميدانية' : 'Field Photo'}</span>
                  </div>
                </div>
              )}

              {/* Textual Core Body */}
              <div className="p-6 md:p-8 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-50 pb-3">
                  <div className="flex items-center gap-2 text-slate-400 font-mono text-xs">
                    <Calendar className="h-3.5 w-3.5 text-teal-500" />
                    <span>{new Date(item.createdAt).toLocaleDateString(lang === 'ar' ? 'ar-IQ' : lang, {
                      year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit'
                    })}</span>
                  </div>

                  {isAdmin && (
                    <button
                      onClick={() => handleDeleteNews(item.id)}
                      className="text-red-500 hover:text-red-700 hover:bg-red-50 p-1.5 rounded-xl transition cursor-pointer self-end sm:self-auto inline-flex items-center gap-1 text-[11px] font-bold"
                      title={isRtl ? 'حذف النشاط بالكامل' : 'Delete entire post'}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      <span>{isRtl ? 'إزالة المنشور' : 'Remove Content'}</span>
                    </button>
                  )}
                </div>

                <div className="space-y-2">
                  <h2 className="text-md md:text-lg font-black text-slate-800 leading-snug">
                    {item.title}
                  </h2>
                  <p className="text-xs md:text-sm text-slate-600 leading-relaxed font-light whitespace-pre-wrap">
                    {item.content}
                  </p>
                </div>

                {/* Interactive Comment Zone */}
                <div className="pt-6 border-t border-slate-100 space-y-4">
                  <h4 className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                    <MessageSquare className="h-4 w-4 text-emerald-600" />
                    <span>{isRtl ? 'شريط الآراء والتعليقات:' : 'Feedback & Comments:'}</span>
                    <span className="text-[10px] bg-slate-50 text-slate-500 font-mono px-2 py-0.5 rounded-full font-bold">
                      {(item.comments || []).length}
                    </span>
                  </h4>

                  {/* List of existing Comments */}
                  <div className="space-y-3 max-h-[300px] overflow-y-auto scrollbar-thin pr-1">
                    {(item.comments || []).length === 0 ? (
                      <p className="text-[11px] text-gray-400 italic">
                        {isRtl ? 'لا توجد تعليقات بعد على هذا المرفق. اكتب أول تعليق بالأسفل!' : 'No feedback written yet on this multimedia. Be the first to review!'}
                      </p>
                    ) : (
                      item.comments.map((comment) => (
                        <div key={comment.id} className="bg-slate-50 rounded-2xl p-3 flex justify-between gap-3 text-right">
                          <div className="flex gap-2.5">
                            <span className="h-7 w-7 rounded-full bg-teal-100 flex items-center justify-center text-[10px] font-black text-teal-800 shrink-0 select-none">
                              {comment.userName.charAt(0).toUpperCase()}
                            </span>
                            <div className="space-y-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-[11px] font-black text-slate-800">{comment.userName}</span>
                                <span className="text-[9px] text-gray-400 font-mono">
                                  {new Date(comment.createdAt).toLocaleDateString(lang === 'ar' ? 'ar-IQ' : lang, {
                                    month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
                                  })}
                                </span>
                              </div>
                              <p className="text-xs text-slate-600 font-light leading-relaxed">{comment.content}</p>
                            </div>
                          </div>

                          {(isAdmin || currentUser?.email === comment.userEmail) && (
                            <button
                              onClick={() => handleDeleteComment(item.id, comment.id)}
                              className="text-slate-400 hover:text-red-500 p-1 rounded-lg transition self-start cursor-pointer"
                              title={isRtl ? 'حذف التعليق' : 'Delete comment'}
                            >
                              <X className="h-3.5 w-3.5" />
                            </button>
                          )}
                        </div>
                      ))
                    )}
                  </div>

                  {/* Comment Submission Form */}
                  <div className="flex items-center gap-2 pt-2">
                    <span className="h-8 w-8 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center text-xs font-black select-none shrink-0">
                      {(currentUser?.name || 'G').charAt(0).toUpperCase()}
                    </span>
                    <input
                      type="text"
                      value={commentInputs[item.id] || ''}
                      onChange={(e) => setCommentInputs(prev => ({ ...prev, [item.id]: e.target.value }))}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handlePostComment(item.id);
                      }}
                      placeholder={isRtl ? 'اكتب رأياً أو تعليقاً بنص مفسر للمحتوى...' : 'Write your technical feedback or comment on this...'}
                      className="flex-1 text-xs rounded-xl border border-slate-200 bg-slate-50/50 px-3 py-2.5 outline-none focus:bg-white focus:border-teal-500"
                    />
                    <button
                      onClick={() => handlePostComment(item.id)}
                      disabled={isCommentLoading[item.id] || !(commentInputs[item.id] || '').trim()}
                      className="bg-teal-600 hover:bg-teal-700 disabled:bg-slate-200 text-white disabled:text-slate-400 p-2.5 rounded-xl transition cursor-pointer shrink-0"
                    >
                      {isCommentLoading[item.id] ? (
                        <RefreshCw className="h-4 w-4 animate-spin" />
                      ) : (
                        <Send className={`h-4 w-4 ${isRtl ? 'transform rotate-180' : ''}`} />
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      )}
    </div>
  );
}
