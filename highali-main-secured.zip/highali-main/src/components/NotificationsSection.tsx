/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Bell, CheckCheck, Trash2, Calendar, ShieldAlert, Award, BookOpen, Monitor, Info, Wrench, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { AppNotification, User } from '../types';
import { getApiUrl } from '../lib/api';
import { triggerToast } from './ToastContainer';

interface NotificationsSectionProps {
  currentUser: User | null;
  lang: 'ar' | 'en' | 'de' | 'es';
  onNavigate: (section: string) => void;
}

export default function NotificationsSection({ currentUser, lang, onNavigate }: NotificationsSectionProps) {
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [readIds, setReadIds] = useState<string[]>([]);
  const [filterType, setFilterType] = useState<string>('all');
  const [isLoading, setIsLoading] = useState(true);

  const isAr = lang === 'ar';
  const t = {
    title: isAr ? 'صندوق الإشعارات والرسائل' : 'Notifications & Messages Inbox',
    subtitle: isAr ? 'أحدث التعاميم والتنبيهات الهندسية الخاصة بمنتسبي البصرة' : 'Latest engineering circulars and alerts for Basra registrants',
    markAllRead: isAr ? 'تحديد الكل كمقروء' : 'Mark all as read',
    noNotif: isAr ? 'قائمة الإشعارات فارغة حالياً' : 'No notifications in your inbox',
    typeAll: isAr ? 'الكل' : 'All',
    typeUpdate: isAr ? 'تحديثات' : 'Updates',
    typeAlert: isAr ? 'تنبيهات' : 'Alerts',
    typeAnnouncement: isAr ? 'إعلانات' : 'Announcements',
    typeMaintenance: isAr ? 'صيانة' : 'Maintenance',
    backBtn: isAr ? 'العودة للبوابة الرئيسية' : 'Return to Gateway',
    time: isAr ? 'منذ' : 'Ago',
    readStatus: isAr ? 'مقروء' : 'Read',
    unreadStatus: isAr ? 'غير مقروء' : 'Unread'
  };

  // Load read notifications
  useEffect(() => {
    try {
      const stored = localStorage.getItem('gce_read_notification_ids');
      if (stored) {
        setReadIds(JSON.parse(stored));
      }
    } catch (e) {
      console.error(e);
    }
  }, []);

  // Fetch notifications
  const loadNotifications = async () => {
    try {
      const res = await fetch(getApiUrl('/api/notifications'));
      if (res.ok) {
        const data: AppNotification[] = await res.json();
        // Filter target users if not for 'all'
        const filtered = data.filter(n => {
          if (!n.targetUsers || n.targetUsers === 'all') return true;
          if (Array.isArray(n.targetUsers)) {
            return n.targetUsers.includes(currentUser?.id || '');
          }
          return n.targetUsers === currentUser?.id;
        });
        setNotifications(filtered);
      }
    } catch (error) {
      console.error('Failed to load notifications', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Poll for real-time notifications
  useEffect(() => {
    loadNotifications();
    const interval = setInterval(() => {
      loadNotifications();
    }, 10000); // Polling every 10 seconds for real-time list
    return () => clearInterval(interval);
  }, [currentUser]);

  // Mark single as read
  const markAsRead = async (id: string) => {
    if (!readIds.includes(id)) {
      const updated = [...readIds, id];
      setReadIds(updated);
      localStorage.setItem('gce_read_notification_ids', JSON.stringify(updated));

      // Report to server to log status
      try {
        await fetch(getApiUrl(`/api/notifications/${id}/read`), {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + (currentUser?.token || '')
          }
        });
      } catch (err) {
        console.error('Error report read status', err);
      }
    }
  };

  // Mark all as read
  const markAllRead = async () => {
    const unread = notifications.filter(n => !readIds.includes(n.id));
    if (unread.length === 0) return;

    const allIds = notifications.map(n => n.id);
    setReadIds(allIds);
    localStorage.setItem('gce_read_notification_ids', JSON.stringify(allIds));

    try {
      await fetch(getApiUrl('/api/notifications/read-all'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + (currentUser?.token || '')
        }
      });
      triggerToast({
        title: isAr ? "تم قراءة الكل" : "Marked All Read",
        description: isAr ? "تم تحديد جميع الإشعارات كمقروءة بنجاح." : "All received notifications marked as read.",
        type: "success"
      });
    } catch (err) {
      console.error(err);
    }
  };

  // Filter list
  const filteredList = notifications.filter(n => {
    if (filterType === 'all') return true;
    return n.type === filterType;
  });

  return (
    <div className="space-y-6" dir={isAr ? 'rtl' : 'ltr'}>
      {/* Header Panel */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b pb-5">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigate('home')}
              className="p-1 px-2.5 rounded-lg border hover:bg-slate-100 flex items-center gap-1 text-[11px] font-bold text-slate-500 cursor-pointer"
            >
              <ArrowRight className={`h-3 w-3 ${isAr ? '' : 'rotate-180'}`} />
              <span>{t.backBtn}</span>
            </button>
          </div>
          <h2 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2 mt-2">
            <Bell className="h-6 w-6 text-teal-600" />
            <span>{t.title}</span>
          </h2>
          <p className="text-[11px] md:text-xs text-slate-500 font-bold">{t.subtitle}</p>
        </div>

        {notifications.length > 0 && (
          <button
            onClick={markAllRead}
            className="w-full md:w-auto shrink-0 bg-teal-50 hover:bg-teal-100 text-teal-800 font-black text-xs px-4 py-2.5 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs border border-teal-200/50"
          >
            <CheckCheck className="h-4 w-4" />
            <span>{t.markAllRead}</span>
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-1.5 bg-slate-100 p-1 rounded-xl w-fit">
        {[
          { id: 'all', label: t.typeAll },
          { id: 'update', label: t.typeUpdate },
          { id: 'alert', label: t.typeAlert },
          { id: 'announcement', label: t.typeAnnouncement },
          { id: 'maintenance', label: t.typeMaintenance }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setFilterType(tab.id)}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              filterType === tab.id 
                ? 'bg-white text-teal-800 shadow-xs border border-teal-100/50' 
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Notifications List */}
      <div className="grid gap-3 select-none">
        {isLoading ? (
          <div className="p-12 text-center text-gray-500 bg-white rounded-2xl border">
            <div className="h-6 w-6 border-2 border-teal-600 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
            <p className="text-xs font-bold">جاري تحميل صندوق الإشعارات...</p>
          </div>
        ) : filteredList.length === 0 ? (
          <div className="p-12 text-center rounded-2xl border border-dashed bg-slate-50/50 text-slate-400 space-y-3">
            <Bell className="h-10 w-10 mx-auto opacity-30 stroke-1" />
            <div>
              <p className="text-xs font-bold text-slate-700">{t.noNotif}</p>
              <p className="text-[10px] text-slate-400 font-light mt-1">
                {isAr ? 'سيصلك تنبيه تلقائي أو بريد إلكتروني حال إطلاق المسؤول لأي تعميم جديد.' : 'You are all caught up! No notifications available.'}
              </p>
            </div>
          </div>
        ) : (
          filteredList.map((notif, index) => {
            const isRead = readIds.includes(notif.id);
            const Icon = 
              notif.type === 'update' ? Award : 
              notif.type === 'alert' ? ShieldAlert : 
              notif.type === 'maintenance' ? Wrench : 
              notif.type === 'announcement' ? BookOpen : Info;

            const iconColors = 
              notif.type === 'update' ? 'text-teal-600 bg-teal-50' : 
              notif.type === 'alert' ? 'text-red-600 bg-red-50' :
              notif.type === 'maintenance' ? 'text-amber-600 bg-amber-50' :
              notif.type === 'announcement' ? 'text-sky-600 bg-sky-50' :
              'text-indigo-600 bg-indigo-50';

            return (
              <motion.div
                key={notif.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.04 }}
                onClick={() => markAsRead(notif.id)}
                className={`p-5 rounded-2xl border bg-white shadow-xs transition hover:shadow-md cursor-pointer flex gap-4 ${
                  !isRead ? 'ring-1 ring-teal-500 border-teal-200' : 'border-slate-150'
                }`}
              >
                <span className={`p-3 h-12 w-12 shrink-0 rounded-xl flex items-center justify-center ${iconColors}`}>
                  <Icon className="h-5 w-5" />
                </span>

                <div className="space-y-1.5 flex-1 min-w-0">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-black text-slate-905">
                        {isAr ? notif.title : (notif.titleEn || notif.title)}
                      </h3>
                      {!isRead ? (
                        <span className="rounded-full bg-teal-500 px-2 py-0.5 text-[8.5px] font-bold text-white uppercase animate-pulse">
                          {t.unreadStatus}
                        </span>
                      ) : (
                        <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[8.5px] font-bold text-slate-450">
                          {t.readStatus}
                        </span>
                      )}
                    </div>

                    <span className="text-[10px] text-slate-400 font-bold flex items-center gap-1 md:self-auto self-start">
                      <Calendar className="h-3 w-3" />
                      <span>
                        {new Date(notif.createdAt).toLocaleDateString(isAr ? 'ar-IQ' : 'en-US', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                    </span>
                  </div>

                  <p className="text-[11.5px] text-slate-650 leading-relaxed font-sans font-medium whitespace-pre-line">
                    {isAr ? notif.description : (notif.descriptionEn || notif.description)}
                  </p>

                  {/* Badges */}
                  <div className="flex items-center gap-2 pt-1 border-t border-slate-50 mt-2">
                    <span className={`text-[9.5px] font-black rounded-md px-2 py-0.5 uppercase ${
                      notif.type === 'update' ? 'bg-teal-50 text-teal-850' : 
                      notif.type === 'alert' ? 'bg-red-50 text-red-850' :
                      notif.type === 'maintenance' ? 'bg-amber-50 text-amber-850' :
                      'bg-sky-50 text-sky-850'
                    }`}>
                      {notif.type === 'update' ? t.typeUpdate : 
                       notif.type === 'alert' ? t.typeAlert :
                       notif.type === 'maintenance' ? t.typeMaintenance :
                       t.typeAnnouncement}
                    </span>

                    {notif.targetUsers && (
                      <span className="text-[9px] font-bold text-slate-400">
                        {isAr 
                          ? (notif.targetUsers === 'all' ? 'موجه لكافة المنتسبين عموماً' : 'إشعار مخصص ومحصور بمستخدمين محددين')
                          : (notif.targetUsers === 'all' ? 'Target: All registrants' : 'Target: Specific members')}
                      </span>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })
        )}
      </div>
    </div>
  );
}
