/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Monitor, Compass, ChevronLeft, ArrowRight, Sparkles, Send, 
  BookOpen, Play, CheckCircle, RefreshCw, AlertTriangle, MessageSquare, Award, FileText, ChevronRight, ExternalLink
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { DigitalPlatform, User } from '../types';
import { LanguageType } from '../locales';
import { getApiUrl } from '../lib/api';

interface PlatformsSectionProps {
  currentUser: User | null;
  platforms: DigitalPlatform[];
  onTrackAction: (action: string, platformId: string, platformName: string, details?: string) => void;
  lang: LanguageType;
  t: any;
}

export default function PlatformsSection({ currentUser, platforms, onTrackAction, lang, t }: PlatformsSectionProps) {
  const [selectedPlatformId, setSelectedPlatformId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [subTab, setSubTab] = useState<'live' | 'local'>('live');

  useEffect(() => {
    if (selectedPlatformId) {
      const platform = platforms.find(p => p.id === selectedPlatformId);
      if (platform && platform.url !== 'embedded') {
        setSubTab('live');
      } else {
        setSubTab('local');
      }
    }
  }, [selectedPlatformId, platforms]);
  
  // States for embedded platforms
  // 1. Thaker Summarizer
  const [summaryInput, setSummaryInput] = useState('');
  const [summaryResult, setSummaryResult] = useState('');
  const [isSummarizing, setIsSummarizing] = useState(false);

  // 2. Interview Prep Simulator
  const [interviewTopic, setInterviewTopic] = useState('');
  const [interviewStarted, setInterviewStarted] = useState(false);
  const [interviewInput, setInterviewInput] = useState('');
  const [interviewMessages, setInterviewMessages] = useState<{role: 'user' | 'assistant', content: string}[]>([]);
  const [isInterviewLoading, setIsInterviewLoading] = useState(false);

  // Set default interview topic based on active locale
  useEffect(() => {
    if (t && t.platforms && t.platforms.interview && t.platforms.interview.topics) {
      setInterviewTopic(t.platforms.interview.topics[0]);
    }
  }, [lang, t]);

  // 3. Digital Bot Chat
  const [botInput, setBotInput] = useState('');
  const [botMessages, setBotMessages] = useState<{role: 'user' | 'assistant', content: string}[]>([]);
  const [isBotLoading, setIsBotLoading] = useState(false);

  useEffect(() => {
    if (t) {
      setBotMessages([
        { role: 'assistant', content: t.platforms.bot.welcome }
      ]);
    }
  }, [lang, t]);

  // 4. Cleaners Detergents Mixer SIM
  const [simBaseActive, setSimBaseActive] = useState('ماء'); // water
  const [simAcidActive, setSimAcidActive] = useState(''); // LABSA, Texapon, NaOH
  const [simPh, setSimPh] = useState(7.0);
  const [simLog, setSimLog] = useState<string[]>([]);
  const [simReactionSuccess, setSimReactionSuccess] = useState(false);

  useEffect(() => {
    if (t) {
      setSimLog([t.platforms.detergents.logReady]);
    }
  }, [lang, t]);

  // 5. UV-Visible Sim
  const [uvWavelength, setUvWavelength] = useState(540);
  const [uvSample, setUvSample] = useState('');
  const [uvAbsorbance, setUvAbsorbance] = useState<number | null>(null);
  const [uvConcentration, setUvConcentration] = useState(1); // Molar
  const [uvIsMeasuring, setUvIsMeasuring] = useState(false);

  useEffect(() => {
    if (t && t.platforms && t.platforms.uvVis && t.platforms.uvVis.samples) {
      setUvSample(t.platforms.uvVis.samples[0]);
    }
  }, [lang, t]);

  // Duration active-tracking Ref / Effect
  const currentPlatformIdRef = useRef<string | null>(null);
  useEffect(() => {
    currentPlatformIdRef.current = selectedPlatformId;
  }, [selectedPlatformId]);

  useEffect(() => {
    if (!currentUser || !selectedPlatformId) return;

    const platform = platforms.find(p => p.id === selectedPlatformId);
    if (!platform) return;

    // Track initial click immediately
    onTrackAction('click_platform', platform.id, platform.name, 'بدء استخدام المحاكي والمنصة الفرعية');

    // Setup periodic duration heartbeat (every 5 seconds)
    const interval = setInterval(() => {
      if (currentPlatformIdRef.current === selectedPlatformId) {
        fetch(getApiUrl('/api/track/heartbeat'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: currentUser.id,
            platformId: platform.id,
            platformName: platform.name,
            seconds: 5
          })
        }).catch(err => console.error('Heartbeat failed:', err));
      }
    }, 5000);

    return () => {
      clearInterval(interval);
    };
  }, [selectedPlatformId, currentUser]);

  const isRtl = t.dir === 'rtl';

  // Map platform localized titles if matching IDs
  const getLocalizedPlatformDetails = (p: DigitalPlatform) => {
    if (p.id === 'thaker-summarizer') {
      return {
        name: t.sections.platforms + ' - ذاكر',
        desc: t.platforms.thaker.desc
      };
    } else if (p.id === 'interview-prep') {
      return {
        name: t.platforms.interview.title,
        desc: t.platforms.interview.desc
      };
    } else if (p.id === 'assistant-bot') {
      return {
        name: t.platforms.bot.title,
        desc: t.platforms.bot.instructions
      };
    } else if (p.id === 'detergents-lab') {
      return {
        name: t.platforms.detergents.title,
        desc: t.platforms.detergents.desc
      };
    } else if (p.id === 'uv-vis-lab') {
      return {
        name: t.platforms.uvVis.title,
        desc: t.platforms.uvVis.desc
      };
    } else if (p.id === 'hplc-sim-lab') {
      return {
        name: t.platforms.hplc.title,
        desc: t.platforms.hplc.desc
      };
    }
    // Return original if dynamic admin add
    return {
      name: p.name,
      desc: p.description
    };
  };

  // Clean filters
  const filteredPlatforms = platforms.filter(p => {
    const localized = getLocalizedPlatformDetails(p);
    return localized.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
           localized.desc.toLowerCase().includes(searchQuery.toLowerCase());
  });

  // Handle open exterior URLs in new tabs
  const handleOpenExteriorPlatform = (p: DigitalPlatform) => {
    onTrackAction('click_platform', p.id, p.name, `تم فتح الرابط الخارجي الموجه للمنصة: ${p.url}`);
    window.open(p.url, '_blank', 'noopener,noreferrer');
  };

  // Helper: call AI summary API
  const handleSummarize = async () => {
    if (!summaryInput.trim()) return;
    setIsSummarizing(true);
    setSummaryResult('');

    try {
      const response = await fetch(getApiUrl('/api/ai/summarize'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: summaryInput })
      });
      const data = await response.json();
      if (response.ok) {
        setSummaryResult(data.summary);
        onTrackAction('use_thaker_tool', 'thaker-summarizer', 'منصة ذاكر لتلخيص الملفات', 'تم تلخيص نص علمي كيميائي بنجاح باستخدام جيميناي');
      } else {
        setSummaryResult(`Error: ${data.error || 'Failed to summarize text.'}`);
      }
    } catch (err: any) {
      setSummaryResult(`Operation Error: ${err.message}`);
    } finally {
      setIsSummarizing(false);
    }
  };

  // Helper: Interview Start & Chat API
  const handleStartInterview = async () => {
    setInterviewStarted(true);
    setInterviewMessages([]);
    setIsInterviewLoading(true);

    try {
      const initPrompt = {
        role: 'user' as const,
        content: `Greetings chemical board interviewer. I am starting my test preparation in topic: ${interviewTopic}. Please ask the first question.`
      };

      const response = await fetch(getApiUrl('/api/ai/interview'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: interviewTopic,
          messages: [initPrompt]
        })
      });
      const data = await response.json();
      if (response.ok) {
        setInterviewMessages([
          { role: 'assistant', content: data.reply }
        ]);
        onTrackAction('interview_start', 'interview-prep', 'منصة المقابلات الهندسية', `تحفيز المقابلة الهندسية بموضوع: ${interviewTopic}`);
      } else {
        setInterviewMessages([
          { role: 'assistant', content: `Sorry, we hit an interview load error: ${data.error}` }
        ]);
      }
    } catch (err: any) {
      setInterviewMessages([
        { role: 'assistant', content: `Server connection error: ${err.message}` }
      ]);
    } finally {
      setIsInterviewLoading(false);
    }
  };

  const handleSendInterviewReply = async () => {
    if (!interviewInput.trim()) return;
    const currentInput = interviewInput;
    setInterviewInput('');

    // Append student reply
    const newHistory = [...interviewMessages, { role: 'user' as const, content: currentInput }];
    setInterviewMessages(newHistory);
    setIsInterviewLoading(true);

    try {
      const response = await fetch(getApiUrl('/api/ai/interview'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: interviewTopic,
          messages: newHistory
        })
      });
      const data = await response.json();
      if (response.ok) {
        setInterviewMessages([...newHistory, { role: 'assistant', content: data.reply }]);
        onTrackAction('interview_interaction', 'interview-prep', 'منصة المقابلات الهندسية', 'إجابة المرشح على تساؤل اللجنة التقنية');
      } else {
        setInterviewMessages([...newHistory, { role: 'assistant', content: `Error: ${data.error}` }]);
      }
    } catch (err: any) {
      setInterviewMessages([...newHistory, { role: 'assistant', content: `Analysis Error: ${err.message}` }]);
    } finally {
      setIsInterviewLoading(false);
    }
  };

  // Helper: call Bot generic API
  const handleSendBotMessage = async () => {
    if (!botInput.trim()) return;
    const currentInput = botInput;
    setBotInput('');

    const newHistory = [...botMessages, { role: 'user' as const, content: currentInput }];
    setBotMessages(newHistory);
    setIsBotLoading(true);

    try {
      // Re-use standard summarizer route or generic chatbot response with system directive
      const response = await fetch(getApiUrl('/api/ai/summarize'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: `The user asks you as a scientific virtual assistant representing the General Authority of Chemical Engineers in Basra.
            Chat history context: ${JSON.stringify(newHistory.slice(-5))}
            New query: "${currentInput}".
            Respond directly, clearly, and concisely in the user's querying language (Arabic, English, German, or Spanish).`
        })
      });
      const data = await response.json();
      if (response.ok) {
        setBotMessages([...newHistory, { role: 'assistant', content: data.summary }]);
        onTrackAction('bot_assistant_chat', 'assistant-bot', 'البوت الرقمي', 'توجيه استعلام علمي للبوت المساعد');
      } else {
        setBotMessages([...newHistory, { role: 'assistant', content: `Bot error: ${data.error}` }]);
      }
    } catch (err: any) {
      setBotMessages([...newHistory, { role: 'assistant', content: `Connection error: ${err.message}` }]);
    } finally {
      setIsBotLoading(false);
    }
  };

  // Detergents Simulator Actions
  const handleMixDetergents = () => {
    if (!simAcidActive) {
      setSimLog(prev => [...prev, t.platforms.detergents.logNoAcid]);
      return;
    }

    setSimLog(prev => [...prev, `${t.platforms.detergents.logPour} (${simAcidActive})`]);
    
    // Check chemically using relative indexes
    const matchedIdx = t.platforms.detergents.acids.indexOf(simAcidActive);

    if (matchedIdx === 0) {
      // LABSA acid
      setSimPh(3.2);
      setSimLog(prev => [
        ...prev, 
        t.platforms.detergents.logLabsa
      ]);
    } else if (matchedIdx === 1) {
      // NaOH base
      if (simPh < 5) {
        setSimPh(7.2);
        setSimReactionSuccess(true);
        setSimLog(prev => [
          ...prev,
          t.platforms.detergents.logNaohNeutral
        ]);
        onTrackAction('mix_detergent_sim_success', 'detergents-lab', 'مختبر انتاج المنظفات', 'إتمام تفاعل إنتاج الصابون السائل بنجاح');
      } else {
        setSimPh(11.5);
        setSimLog(prev => [
          ...prev,
          t.platforms.detergents.logNaohBase
        ]);
      }
    } else if (matchedIdx === 2) {
      // Texapon foam enhancer
      setSimLog(prev => [
        ...prev, 
        t.platforms.detergents.logTexapon
      ]);
    }
  };

  const handleResetDetergentSim = () => {
    setSimBaseActive('ماء');
    setSimAcidActive('');
    setSimPh(7.0);
    setSimReactionSuccess(false);
    setSimLog([t.platforms.detergents.logReady]);
  };

  // UV-Visible Spectrometer Simulator Actions
  const handleMeasureUv = () => {
    setUvIsMeasuring(true);
    setUvAbsorbance(null);

    setTimeout(() => {
      // Index of selected sample to be language-compliant
      const idx = t.platforms.uvVis.samples.indexOf(uvSample);
      let molarAbsorptivity = 0.45;

      if (idx === 0) {
        // Copper Sulfate: peak absorption near 600-800, so high around 650
        molarAbsorptivity = uvWavelength > 500 && uvWavelength < 700 ? 0.68 : 0.15;
      } else if (idx === 1) {
        // Potassium Dichromate: peak absorption near 350-450 (UV)
        molarAbsorptivity = uvWavelength < 450 ? 0.85 : 0.08;
      } else if (idx === 2) {
        // Phenolphthalein indicator
        molarAbsorptivity = uvWavelength > 520 && uvWavelength < 560 ? 0.95 : 0.03;
      }

      const calculatedAbsorbance = molarAbsorptivity * uvConcentration * 1.0; // 1cm path length
      setUvAbsorbance(Number(calculatedAbsorbance.toFixed(4)));
      setUvIsMeasuring(false);
      onTrackAction('measure_uv_spectre', 'uv-vis-lab', 'مختبر جهاز Uv visible', `قراءة امتصاص لـ: ${uvSample} عند طول موجي ${uvWavelength}nm`);
    }, 1500);
  };

  const currentSelectionPlatform = platforms.find(p => p.id === selectedPlatformId);
  const localizedHeader = currentSelectionPlatform ? getLocalizedPlatformDetails(currentSelectionPlatform) : null;

  return (
    <div className="space-y-6" dir={t.dir}>
      {/* Search Header */}
      {!selectedPlatformId && (
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-800">{t.platforms.title}</h1>
            <p className="text-sm text-gray-500">{t.platforms.subtitle}</p>
          </div>
          <div className="relative w-full max-w-xs">
            <input
              type="text"
              placeholder={t.platforms.searchPlat}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs shadow-xs focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none"
            />
          </div>
        </div>
      )}

      {/* Main Grid View */}
      {!selectedPlatformId ? (
        <motion.div 
          layout
          className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3"
        >
          {filteredPlatforms.map((platform) => {
            const locDetails = getLocalizedPlatformDetails(platform);
            return (
              <motion.div
                layout
                whileHover={{ y: -6, scale: 1.02 }}
                key={platform.id}
                className="relative overflow-hidden rounded-2xl border border-slate-100 bg-white shadow-xs hover:shadow-md transition flex flex-col h-[400px]"
                id={`platform-card-${platform.id}`}
              >
                <div className="relative h-44 w-full bg-slate-100 overflow-hidden shrink-0">
                  <img 
                    src={platform.image} 
                    alt={locDetails.name}
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover transition duration-500 hover:scale-105"
                  />
                  {platform.url === 'embedded' && (
                    <span className={`absolute top-3 ${isRtl ? 'right-3' : 'left-3'} inline-flex items-center gap-1 rounded-md bg-emerald-600 px-2 py-0.5 text-[10px] font-bold text-white shadow-xs`}>
                      <Sparkles className="h-3 w-3 animate-pulse" />
                      {t.platforms.integrated}
                    </span>
                  )}
                </div>
                
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div className="space-y-2">
                    <h3 className="text-md font-bold text-slate-800 line-clamp-1">{locDetails.name}</h3>
                    <p className="text-xs text-gray-500 leading-relaxed line-clamp-3 font-light">
                      {locDetails.desc}
                    </p>
                  </div>

                  <div className="pt-4 border-t border-slate-50 flex items-center justify-between">
                    <div className="text-[9px] font-bold text-gray-400 font-mono">
                      {platform.url === 'embedded' ? t.platforms.aiInteractive : t.platforms.externalWeb}
                    </div>
                    {platform.url === 'embedded' ? (
                      <button
                        onClick={() => setSelectedPlatformId(platform.id)}
                        className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 px-4 py-2 text-xs font-bold text-emerald-800 transition cursor-pointer"
                        id={`open-embedded-platform-${platform.id}`}
                      >
                        {t.platforms.enterSim}
                        {isRtl ? <ChevronLeft className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
                      </button>
                    ) : (
                      <button
                        onClick={() => handleOpenExteriorPlatform(platform)}
                        className="inline-flex items-center gap-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 px-4 py-2 text-xs font-bold text-white transition cursor-pointer hover:scale-[1.02]"
                        id={`open-ext-link-${platform.id}`}
                      >
                        {t.platforms.simulateBtn}
                        {isRtl ? <ChevronLeft className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      ) : (
        // Immersive Simulator Screens for Each Selected Platform
        <div className="space-y-4">
          {/* Active Header bar with Go back btn */}
          <div className="flex items-center justify-between rounded-2xl bg-white border border-slate-100 p-4 shadow-xs">
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setSelectedPlatformId(null)}
                className="inline-flex items-center justify-center p-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-gray-500 transition cursor-pointer"
                id="back-to-platforms-btn"
                title={t.platforms.backBtn}
              >
                {isRtl ? <ArrowRight className="h-5 w-5" /> : <ArrowRight className="h-5 w-5 transform rotate-180" />}
              </button>
              <div>
                <span className="text-[9px] font-bold text-teal-600 uppercase tracking-wider">{t.platforms.authorities}</span>
                <h2 className="text-base font-black text-slate-800">{localizedHeader?.name}</h2>
              </div>
            </div>
            <div className="hidden sm:block rounded-full bg-emerald-50 border border-emerald-200 px-3 py-1 text-[10px] text-emerald-800 font-bold font-mono">
              {t.platforms.statusOnline}
            </div>
          </div>

          {/* Sub Tab Bar for switching between Live Platform and Built-in Simulator */}
          {currentSelectionPlatform && currentSelectionPlatform.url !== 'embedded' && (
            <div className="flex bg-slate-100 p-1 rounded-2xl max-w-md mx-auto gap-1 self-center w-full">
              <button
                onClick={() => setSubTab('live')}
                className={`flex-1 py-2 rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 cursor-pointer ${
                  subTab === 'live' 
                    ? 'bg-teal-600 text-white shadow-xs animate-none' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
                id="view-live-app-tab"
              >
                <Monitor className="h-3.5 w-3.5" />
                {lang === 'ar' ? 'المنصة الرقمية المباشرة' : 'Live Platform'}
              </button>
              <button
                onClick={() => setSubTab('local')}
                className={`flex-1 py-2 rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 cursor-pointer ${
                  subTab === 'local' 
                    ? 'bg-teal-600 text-white shadow-xs animate-none' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
                id="view-integrated-sim-tab"
              >
                <Sparkles className="h-3.5 w-3.5" />
                {lang === 'ar' ? 'المحاكي / الأداة المدمجة بالبوابة' : 'Built-in Tool'}
              </button>
            </div>
          )}

          <div className="rounded-3xl border border-slate-100 bg-white p-6 md:p-8 shadow-sm">
            {subTab === 'live' && currentSelectionPlatform && currentSelectionPlatform.url !== 'embedded' ? (
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-gradient-to-r from-teal-50 to-emerald-50 border border-teal-100 rounded-2xl p-4">
                  <div className="text-right flex-1 w-full" dir="rtl">
                    <span className="text-[9px] font-bold text-teal-600 uppercase tracking-widest block mb-0.5">
                      {lang === 'ar' ? 'بيئة التشغيل السحابية المباشرة' : 'Live Cloud Environment'}
                    </span>
                    <p className="text-xs font-extrabold text-teal-950">
                      {lang === 'ar' 
                        ? 'تصفح بالكامل وتفاعل مع المنصة الرقمية الرسمية للهيئة عبر البوابة.' 
                        : 'Feel free to interact fully with the live system of the GCE Basra Academy.'}
                    </p>
                    <p className="text-[9px] text-teal-700 font-mono mt-1 break-all truncate select-all">
                      {currentSelectionPlatform.url}
                    </p>
                  </div>
                  
                  <button
                    onClick={() => handleOpenExteriorPlatform(currentSelectionPlatform)}
                    className="inline-flex items-center gap-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 px-4 py-2.5 text-xs font-bold text-white transition hover:shadow-xs cursor-pointer shrink-0"
                    id="open-external-window-btn"
                  >
                    <span>{lang === 'ar' ? 'فتح بملء الشاشة' : 'Launch Full Screen'}</span>
                    <ExternalLink className="h-3.5 w-3.5" />
                  </button>
                </div>

                <div className="w-full h-[650px] bg-slate-50 rounded-3xl border border-slate-200 overflow-hidden shadow-inner relative">
                  <iframe 
                    src={currentSelectionPlatform.url}
                    className="w-full h-full border-none"
                    title={currentSelectionPlatform.name}
                    id={`platform-frame-${currentSelectionPlatform.id}`}
                    allow="camera; microphone; geolocation"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>
            ) : (
              <>
                {/* 1. EMBEDDED PLATFORM: THAKER SUMMARIZER */}
            {selectedPlatformId === 'thaker-summarizer' && (
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <div className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-50 text-emerald-800 px-3 py-1 text-[11px] font-semibold">
                    <Sparkles className="h-4 w-4 text-emerald-600" />
                    {t.platforms.thaker.badge}
                  </div>
                  <h3 className="text-md font-bold text-slate-800">{t.platforms.thaker.title}</h3>
                  <p className="text-xs text-gray-500 font-light leading-relaxed">
                    {t.platforms.thaker.desc}
                  </p>
                  
                  <div className="space-y-2">
                    <textarea
                      value={summaryInput}
                      onChange={(e) => setSummaryInput(e.target.value)}
                      placeholder={t.platforms.thaker.placeholder}
                      className="w-full h-64 rounded-2xl border border-slate-200 bg-slate-50 p-4 text-xs font-normal focus:border-emerald-500 focus:bg-white focus:ring-1 focus:ring-emerald-500 outline-none resize-none"
                    />
                    <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                      <span className="text-[10px] text-gray-400 font-mono">{t.platforms.thaker.limits}</span>
                      <button
                        onClick={handleSummarize}
                        disabled={isSummarizing || !summaryInput.trim()}
                        className="flex items-center justify-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white text-xs font-bold px-6 py-3 shadow-md shadow-emerald-500/10 transition cursor-pointer"
                        id="run-thaker-summarize-btn"
                      >
                        {isSummarizing ? (
                          <>
                            <RefreshCw className="h-4 w-4 animate-spin" />
                            <span>{t.platforms.thaker.running}</span>
                          </>
                        ) : (
                          <>
                            <Sparkles className="h-4 w-4" />
                            <span>{t.platforms.thaker.runBtn}</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Summarization Results Container */}
                <div className="rounded-2xl border border-slate-100 bg-slate-50/50 p-5 flex flex-col h-[460px] overflow-hidden justify-between">
                  <div>
                    <h4 className="text-xs font-extrabold text-slate-700 tracking-wider flex items-center gap-1.5 px-1 py-1 border-b border-slate-200/50 mb-3">
                      <FileText className="h-4 w-4 text-emerald-600" />
                      {t.platforms.thaker.resultsTitle}
                    </h4>
                    <div className="overflow-y-auto max-h-[350px] pr-2 space-y-4 text-xs leading-relaxed text-slate-800">
                      {summaryResult ? (
                        <div className="whitespace-pre-line text-xs font-normal space-y-2 prose">
                          {summaryResult}
                        </div>
                      ) : (
                        <div className="h-48 flex flex-col items-center justify-center text-center text-gray-450 space-y-2">
                          <BookOpen className="h-10 w-10 stroke-1 opacity-60" />
                          <p className="font-light">{t.platforms.thaker.resultsPlaceholder}</p>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="text-[10px] text-left text-gray-400 pt-2 border-t border-slate-200/50 font-mono">
                    {t.platforms.thaker.poweredBy}
                  </div>
                </div>
              </div>
            )}

            {/* 2. EMBEDDED PLATFORM: INTERVIEW PREP */}
            {selectedPlatformId === 'interview-prep' && (
              <div className="space-y-6">
                {!interviewTopic ? (
                  <div className="text-center py-8">
                    <RefreshCw className="h-8 w-8 animate-spin mx-auto text-teal-600" />
                  </div>
                ) : !interviewStarted ? (
                  <div className="max-w-xl mx-auto text-center space-y-6 py-6" dir={t.dir}>
                    <div className="inline-flex p-3 rounded-2xl bg-teal-50 text-teal-800 shadow-sm animate-bounce">
                      <Award className="h-8 w-8 text-teal-600" />
                    </div>
                    <div className="space-y-2">
                      <h3 className="text-xl font-bold text-slate-800">{t.platforms.interview.title}</h3>
                      <p className="text-xs text-gray-500 font-light leading-relaxed">
                        {t.platforms.interview.desc}
                      </p>
                    </div>

                    <div className="space-y-3 text-right">
                      <label className="text-xs font-bold text-slate-700">{t.platforms.interview.topicLabel}</label>
                      <select
                        value={interviewTopic}
                        onChange={(e) => setInterviewTopic(e.target.value)}
                        className="w-full rounded-xl border border-slate-200 bg-white p-3 text-xs focus:border-teal-500 focus:ring-1 focus:ring-teal-500 outline-none"
                      >
                        {t.platforms.interview.topics.map((topic: string, i: number) => (
                          <option key={i} value={topic}>{topic}</option>
                        ))}
                      </select>
                    </div>

                    <button
                      onClick={handleStartInterview}
                      className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-xl bg-teal-600 hover:bg-teal-700 px-8 py-3 text-xs font-bold text-white shadow-lg shadow-teal-600/10 transition cursor-pointer"
                      id="start-interview-prep-btn"
                    >
                      <Play className="h-4 w-4" />
                      {t.platforms.interview.btnStart}
                    </button>
                  </div>
                ) : (
                  // Active Chat Interface
                  <div className="grid md:grid-cols-3 gap-6 h-[500px]" dir={t.dir}>
                    {/* Status & Help Panel */}
                    <div className="rounded-2xl border border-slate-100 bg-slate-50 p-5 flex flex-col justify-between">
                      <div className="space-y-4 text-xs">
                        <div className="flex items-center gap-1.5 text-teal-800 font-bold">
                          <CheckCircle className="h-4 w-4 text-teal-600" />
                          <span>{t.platforms.interview.activeTopic}</span>
                        </div>
                        <p className="font-semibold text-slate-700 bg-white border rounded-xl p-3 leading-relaxed">
                          {interviewTopic}
                        </p>
                        <div className="space-y-2 mt-4 text-gray-500 font-light">
                          <p className="font-extrabold text-slate-800">{t.platforms.interview.instructionsTitle}</p>
                          {t.platforms.interview.instructions.map((inst: string, i: number) => (
                            <p key={i}>{inst}</p>
                          ))}
                        </div>
                      </div>

                      <button
                        onClick={() => setInterviewStarted(false)}
                        className="w-full text-center text-xs font-medium bg-red-50 hover:bg-red-100 text-red-700 py-2.5 rounded-xl border border-red-100 transition cursor-pointer font-bold"
                      >
                        {t.platforms.interview.btnEnd}
                      </button>
                    </div>

                    {/* Conversational Screen Component */}
                    <div className="md:col-span-2 rounded-2xl border border-[#e2e8f0] bg-white flex flex-col h-full overflow-hidden justify-between shadow-xs">
                      {/* Chat messages */}
                      <div className="flex-1 p-4 overflow-y-auto space-y-4">
                        {interviewMessages.map((msg, idx) => (
                          <div
                            key={idx}
                            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                          >
                            <div
                              className={`max-w-[85%] rounded-2xl px-4 py-3 text-xs leading-relaxed shadow-xs ${
                                msg.role === 'user'
                                  ? 'bg-gradient-to-r from-teal-700 to-emerald-600 text-white rounded-br-none'
                                  : 'bg-slate-50 text-slate-800 border rounded-bl-none'
                              }`}
                            >
                              <div className="font-extrabold text-[10px] mb-1 opacity-75">
                                {msg.role === 'user' ? t.platforms.interview.chatUserHeader : t.platforms.interview.chatHeader}
                              </div>
                              <p className="whitespace-pre-line font-normal">{msg.content}</p>
                            </div>
                          </div>
                        ))}
                        {isInterviewLoading && (
                          <div className="flex justify-start">
                            <div className="bg-slate-50 border rounded-2xl px-4 py-3 text-xs text-gray-500 flex items-center gap-2">
                              <RefreshCw className="h-3.5 w-3.5 animate-spin text-teal-600" />
                              <span>{t.platforms.interview.loading}</span>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Input formulation bar */}
                      <div className="p-3 border-t bg-slate-50 flex gap-2">
                        <input
                          type="text"
                          value={interviewInput}
                          onChange={(e) => setInterviewInput(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && handleSendInterviewReply()}
                          placeholder={t.platforms.interview.chatPlaceholder}
                          className="flex-1 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs outline-none focus:border-teal-500"
                        />
                        <button
                          onClick={handleSendInterviewReply}
                          disabled={isInterviewLoading || !interviewInput.trim()}
                          className="rounded-xl bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 p-2.5 text-white transition shrink-0 cursor-pointer"
                          id="submit-interview-message-btn"
                        >
                          <Send className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 3. EMBEDDED PLATFORM: ASSISTANT BOT */}
            {selectedPlatformId === 'assistant-bot' && (
              <div className="max-w-3xl mx-auto space-y-4">
                <div className="rounded-2xl border border-slate-100 bg-slate-50 p-4 shadow-xs">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
                    <MessageSquare className="h-4 w-4 text-teal-600 animate-pulse" />
                    {t.platforms.bot.instructions}
                  </div>
                </div>

                <div className="border border-slate-100 rounded-2xl bg-white flex flex-col h-[450px] overflow-hidden justify-between shadow-xs">
                  <div className="flex-1 p-4 overflow-y-auto space-y-4">
                    {botMessages.map((msg, idx) => (
                      <div
                        key={idx}
                        className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[85%] rounded-2xl px-4 py-3 text-xs leading-relaxed shadow-xs ${
                            msg.role === 'user'
                              ? 'bg-gradient-to-r from-teal-800 to-emerald-700 text-white rounded-br-none'
                              : 'bg-slate-50 text-slate-800 border rounded-bl-none'
                          }`}
                        >
                          <p className="whitespace-pre-line font-normal">{msg.content}</p>
                        </div>
                      </div>
                    ))}
                    {isBotLoading && (
                      <div className="flex justify-start">
                        <div className="bg-slate-50 border rounded-2xl px-4 py-3 text-xs text-gray-500 flex items-center gap-2">
                          <RefreshCw className="h-3 w-3 animate-spin text-teal-600" />
                          <span>{t.platforms.bot.loading}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="p-3 border-t bg-slate-50 flex gap-2">
                    <input
                      type="text"
                      value={botInput}
                      onChange={(e) => setBotInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSendBotMessage()}
                      placeholder={t.platforms.bot.placeholder}
                      className="flex-1 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs outline-none focus:border-teal-500"
                    />
                    <button
                      onClick={handleSendBotMessage}
                      disabled={isBotLoading || !botInput.trim()}
                      className="rounded-xl bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 p-2.5 text-white transition cursor-pointer"
                      id="send-bot-query-btn"
                    >
                      <Send className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 4. MOCK PLATFORM: DETERGENTS MIXER SIM */}
            {selectedPlatformId === 'detergents-lab' && (
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-md font-bold text-slate-800 flex items-center gap-2">
                      <Compass className="h-5 w-5 text-emerald-600" />
                      {t.platforms.detergents.title}
                    </h3>
                    <p className="text-xs text-gray-500 font-light mt-1 leading-relaxed">
                      {t.platforms.detergents.desc}
                    </p>
                  </div>

                  {/* Reaction Settings Container */}
                  <div className="space-y-4 rounded-2xl bg-slate-50 border p-5">
                    <div className="space-y-1">
                      <span className="text-xs font-bold text-slate-700">{t.platforms.detergents.solTitle}</span>
                      <div className="w-full rounded-xl bg-white border p-3 text-xs text-slate-800 font-medium">
                        {t.platforms.detergents.waterSol}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <span className="text-xs font-bold text-slate-700">{t.platforms.detergents.acidTitle}</span>
                      <div className="grid grid-cols-1 gap-2">
                        {t.platforms.detergents.acids.map((acid: string, aIdx: number) => (
                          <button
                            key={aIdx}
                            onClick={() => setSimAcidActive(acid)}
                            className={`p-3 rounded-xl text-xs text-right border transition cursor-pointer ${
                              simAcidActive === acid 
                                ? 'bg-emerald-600 border-emerald-600 text-white font-bold' 
                                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                            }`}
                          >
                            {acid}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <button
                        onClick={handleMixDetergents}
                        className="flex-1 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-3 transition shadow-md shadow-emerald-500/10 cursor-pointer"
                        id="mix-chemicals-sim-btn"
                      >
                        {t.platforms.detergents.btnMix}
                      </button>
                      <button
                        onClick={handleResetDetergentSim}
                        className="rounded-xl border border-slate-200 hover:bg-slate-100 p-3 text-slate-650 transition cursor-pointer"
                        title="Reset Simulator"
                      >
                        <RefreshCw className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Simulated reaction output panel */}
                <div className="flex flex-col justify-between rounded-2xl border bg-slate-900 text-slate-200 p-6 shadow-md shadow-slate-950/20">
                  <div className="space-y-4">
                    <h4 className="text-xs font-mono font-bold tracking-widest text-emerald-400 border-b border-slate-800 pb-2">
                      REACTOR MONITOR_01
                    </h4>

                    {/* Graphical pH gauge representation */}
                    <div className="flex items-center gap-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
                      <div>
                        <div className="text-[9px] text-gray-500 font-mono">{t.platforms.detergents.phStatus}</div>
                        <div className="font-mono text-3xl font-extrabold text-emerald-300">
                          {simPh.toFixed(1)}
                        </div>
                      </div>
                      <div className="flex-1 h-3 rounded-full bg-slate-800 overflow-hidden relative">
                        <div 
                          className="h-full bg-gradient-to-r from-red-500 via-emerald-400 to-purple-600 transition-all duration-500"
                          style={{ width: `${(simPh / 14) * 100}%` }}
                        />
                        <div 
                          className="absolute bg-white h-5 w-1 border border-slate-930 rounded-full top-1/2 -translate-y-1/2"
                          style={{ left: `${(simPh / 14) * 105}%` }}
                        />
                      </div>
                    </div>

                    {/* Logs output console block */}
                    <div className="bg-slate-950 p-4 rounded-xl h-44 overflow-y-auto font-mono text-[10px] text-emerald-200/80 space-y-1.5 scrollbar-thin">
                      {simLog.map((log, lIdx) => (
                        <div key={lIdx} className="flex gap-1.5">
                          <span className="text-cyan-500 font-bold">&gt;&gt;</span>
                          <span className="leading-relaxed font-light">{log}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {simReactionSuccess && (
                     <div className="rounded-xl bg-emerald-950/30 border border-emerald-500/40 p-3 mt-4 text-emerald-300 text-xs flex items-center gap-2.5">
                       <CheckCircle className="h-5 w-5 text-emerald-400 shrink-0" />
                       <span className="leading-relaxed font-semibold">{t.platforms.detergents.reactionOk}</span>
                     </div>
                  )}
                </div>
              </div>
            )}

            {/* 5. MOCK PLATFORM: UV-VISIBLE SPECTROMETER */}
            {selectedPlatformId === 'uv-vis-lab' && (
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-md font-bold text-slate-800 flex items-center gap-2">
                      <Monitor className="h-5 w-5 text-cyan-600" />
                      {t.platforms.uvVis.title}
                    </h3>
                    <p className="text-xs text-gray-500 font-light mt-1 leading-relaxed">
                      {t.platforms.uvVis.desc}
                    </p>
                  </div>

                  <div className="space-y-4 rounded-2xl bg-slate-50 border p-5">
                    <div className="space-y-1">
                      <span className="text-xs font-bold text-slate-700">{t.platforms.uvVis.sampleLabel}</span>
                      <select
                        value={uvSample}
                        onChange={(e) => setUvSample(e.target.value)}
                        className="w-full rounded-xl border border-slate-200 bg-white p-2.5 text-xs focus:border-teal-500"
                      >
                        {t.platforms.uvVis.samples.map((sample: string, i: number) => (
                          <option key={i} value={sample}>{sample}</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-xs font-bold text-slate-700">
                        <span>{t.platforms.uvVis.waveLabel}</span>
                        <span className="font-mono text-cyan-600 font-extrabold">{uvWavelength} nm</span>
                      </div>
                      <input
                        type="range"
                        min="400"
                        max="800"
                        value={uvWavelength}
                        onChange={(e) => setUvWavelength(Number(e.target.value))}
                        className="w-full accents-teal-600"
                      />
                      <div className="flex justify-between text-[9px] text-gray-400 font-mono">
                        <span>400nm (UV/Violet)</span>
                        <span>800nm (Red/Near IR)</span>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-xs font-bold text-slate-700">
                        <span>{t.platforms.uvVis.concLabel}</span>
                        <span className="font-mono text-emerald-600 font-extrabold">{uvConcentration} M</span>
                      </div>
                      <input
                        type="range"
                        min="0.1"
                        max="3.0"
                        step="0.1"
                        value={uvConcentration}
                        onChange={(e) => setUvConcentration(Number(e.target.value))}
                        className="w-full accents-emerald-600"
                      />
                      <div className="flex justify-between text-[9px] text-gray-400 font-mono">
                        <span>0.1 M (Dilute)</span>
                        <span>3.0 M (Concentrated)</span>
                      </div>
                    </div>

                    <button
                      onClick={handleMeasureUv}
                      disabled={uvIsMeasuring}
                      className="w-full rounded-xl bg-cyan-600 hover:bg-cyan-700 disabled:bg-slate-300 text-white text-xs font-bold py-3 transition shadow-md shadow-cyan-500/10 cursor-pointer"
                      id="uv-visible-test-beams-btn"
                    >
                      {uvIsMeasuring ? (
                        <span className="inline-flex items-center gap-2">
                          <RefreshCw className="h-4 w-4 animate-spin" />
                          <span>{t.platforms.uvVis.measuring}</span>
                        </span>
                      ) : (
                        <span>{t.platforms.uvVis.btnMeasure}</span>
                      )}
                    </button>
                  </div>
                </div>

                {/* Spectrometer Results Grid representation */}
                <div className="flex flex-col justify-between rounded-2xl border bg-slate-900 text-slate-200 p-6 shadow-md shadow-slate-950/20">
                  <div className="space-y-5">
                    <h4 className="text-xs font-mono font-bold tracking-widest text-cyan-400 border-b border-slate-800 pb-2">
                      UV-VIS SPECTROPHOTOMETER_ANALYST_03
                    </h4>

                    {/* Active results */}
                    <div className="space-y-3">
                      <span className="text-xs font-bold text-gray-400 block">{t.platforms.uvVis.results}</span>
                      
                      {uvAbsorbance !== null ? (
                        <div className="grid grid-cols-2 gap-4">
                          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                            <span className="text-[10px] text-slate-500 block">{t.platforms.uvVis.absText}</span>
                            <span className="font-mono text-2xl font-extrabold text-cyan-300">{uvAbsorbance}</span>
                          </div>
                          
                          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                            <span className="text-[10px] text-slate-500 block">Transmission (%T):</span>
                            <span className="font-mono text-2xl font-extrabold text-teal-300">
                              {(Math.pow(10, -uvAbsorbance) * 100).toFixed(2)} %
                            </span>
                          </div>
                        </div>
                      ) : (
                        <div className="p-8 rounded-xl bg-slate-950 border border-slate-800 text-center text-xs text-slate-500 leading-relaxed font-light">
                          {t.platforms.uvVis.noAbs}
                        </div>
                      )}
                    </div>

                    {/* Scientific Beer Lambert formulation chart info */}
                    {uvAbsorbance !== null && (
                      <div className="rounded-xl bg-slate-950/40 p-4 border border-slate-800 text-xs text-slate-400 space-y-2 leading-relaxed">
                        <strong className="text-cyan-400 block">{t.platforms.uvVis.beerLawTitle}</strong>
                        <p className="font-light">
                          {t.platforms.uvVis.beerLawText}
                        </p>
                      </div>
                    )}
                  </div>

                  <div className="text-[9px] text-gray-500 font-mono pt-4 border-t border-slate-800 flex justify-between">
                    <span>PATH LENGTH (L): 1.0 cm</span>
                    <span>BEER-LAMBERT CRITERIA MODEL</span>
                  </div>
                </div>
              </div>
            )}
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
