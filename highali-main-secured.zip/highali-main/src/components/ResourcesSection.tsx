/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  BookOpen, Download, UploadCloud, Search, Plus, Trash2, 
  FileText, ShieldCheck, HardDrive, ArrowUp, ArrowDown, Edit, Lock, X, Eye
} from 'lucide-react';
import { EngineeringResource, User } from '../types';
import { motion } from 'motion/react';
import { LanguageType } from '../locales';

const getBookChapters = (title: string) => [
  {
    titleAr: 'المحور الأول: الأسس الكيميائية وصيغ المرجع',
    titleEn: 'Section I: Chemical Fundamentals & Reference Principles',
    contentAr: `مجلد تصفح ومطالعة علمي معد من لجان الهيئة للتطبيق النظري والميداني الفوري لمرجع "${title}".
يتناول هذا القسم موازين الحرارة، وضغط وتصميم شبكات نقل الغاز، والتفكيك الكروماتوغرافي للموائع العضوية.
التشغيل الآمن ومراقبة ميكانيكا المضخات الكيميائية وتفريغ الغليان هما حجر الأساس للعمليات المستمرة في تكرير النفط بالبصرة.`,
    contentEn: `Academic study booklet curated by the GCE committees for immediate theoretical review corresponding of: "${title}".
Covers thermodynamics balances, high-pressure natural gas grid hydraulics, and chromatographic oil fractional separation.
Safe plant operations and centrifugal pump cavitation control act as the core engineering shield for Basra petroleum refineries.`
  },
  {
    titleAr: 'المحور الثاني: ميكانيكا عمليات التكرير والفصل',
    titleEn: 'Section II: Refinery Processes & Phase Conversions',
    contentAr: `يتناول هذا الباب بالتنظير العلمي والدراسة التطبيقية عمليات التقطير المجزأ وأنظمة التكسير الحفزي (FCC) وتقدير كفاءة الصواني (Tray Efficiencies).
تم تدوين المعادلات الكيميائية ومخططات التدفق لحساب كميات الاستهلاك والفاقد لتوجيه الطلاب والمهندسين.
الصيغة العامة لنظرية ميكاب-ثيلي تم تسهيل صياغتها لتسهيل حساب أبراج الفصل بدقة.`,
    contentEn: `This section highlights fractional distillation columns, fluid catalytic cracking plant configurations, and tray hydraulic efficiency estimates.
Includes detailed dimensional layout representations, process flow diagrams, and volume estimates designed to aid senior graduation projects.`
  },
  {
    titleAr: 'المحور الثالث: دراسات فحص وضمان الجودة البيئية بالبصرة',
    titleEn: 'Section III: Environmental Quality & Basra Field Audits',
    contentAr: `يتطرق هذا الفصل إلى حل المشاكل التطبيقية بموقع العمل في شركات غاز وجولات تراخيص البصرة النفطية وتطبيقات الفحص المجهري والطيفي الحديثة.
يسعى المبحث لتعريف مهندس السلامة بمعايير معالجة المخلفات السائلة والمائية وسبل تبريد وتكثيف المنتجات بكفاءة تامة.`,
    contentEn: `Focuses on troubleshooting mechanical operations in Basra Petrochemicals, gas pipelines, and refining sectors.
Illustrates dynamic remediation procedures for chemical waste handling, cooling tower loads, and product condenser optimization.`
  }
];

interface ResourcesSectionProps {
  currentUser: User | null;
  resources: EngineeringResource[];
  onAddResource: (resource: { title: string; category: string; description: string; url: string; fileName: string; fileSize: number }) => void;
  onDeleteResource: (id: string) => void;
  onEditResource?: (id: string, updated: Partial<EngineeringResource>) => void;
  onReorderResources?: (orderedIds: string[]) => void;
  onTrackAction: (action: string, page: string, details?: string) => void;
  lang: LanguageType;
  t: any;
}

export default function ResourcesSection({ 
  currentUser, 
  resources, 
  onAddResource, 
  onDeleteResource, 
  onEditResource,
  onReorderResources,
  onTrackAction, 
  lang, 
  t 
}: ResourcesSectionProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(t.resources.categories[0] || 'All');

  // Secure document viewer states
  const [selectedViewResource, setSelectedViewResource] = useState<EngineeringResource | null>(null);
  const [activeViewPage, setActiveViewPage] = useState(0);

  // Edit resource states
  const [editingResource, setEditingResource] = useState<any | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editCategory, setEditCategory] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editExternalUrl, setEditExternalUrl] = useState('');
  const [editFileName, setEditFileName] = useState('');
  const [editFileSizeMB, setEditFileSizeMB] = useState('420');

  // Admin add resource panel state
  const [showAddResource, setShowAddResource] = useState(false);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Core Textbooks');
  const [description, setDescription] = useState('');
  const [externalUrl, setExternalUrl] = useState('');
  const [simulatedFile, setSimulatedFile] = useState<File | null>(null);
  const [customFileName, setCustomFileName] = useState('');
  const [customFileSizeMB, setCustomFileSizeMB] = useState('420'); // Default massive example matching 400MB+ requested
  
  // Progress states
  const [isUploading, setIsUploading] = useState(false);
  const [uploadPercent, setUploadPercent] = useState(0);
  const [uploadSpeed, setUploadSpeed] = useState(0);
  const [errorMsg, setErrorMsg] = useState('');

  const isAdmin = currentUser?.role === 'admin';

  const handleMoveUp = (resourceId: string) => {
    const trueIndex = resources.findIndex(r => r.id === resourceId);
    if (trueIndex <= 0) return;
    const reordered = [...resources];
    const temp = reordered[trueIndex];
    reordered[trueIndex] = reordered[trueIndex - 1];
    reordered[trueIndex - 1] = temp;
    if (onReorderResources) {
      onReorderResources(reordered.map(r => r.id));
    }
  };

  const handleMoveDown = (resourceId: string) => {
    const trueIndex = resources.findIndex(r => r.id === resourceId);
    if (trueIndex === -1 || trueIndex === resources.length - 1) return;
    const reordered = [...resources];
    const temp = reordered[trueIndex];
    reordered[trueIndex] = reordered[trueIndex + 1];
    reordered[trueIndex + 1] = temp;
    if (onReorderResources) {
      onReorderResources(reordered.map(r => r.id));
    }
  };

  const startEdit = (res: any) => {
    setEditingResource(res);
    setEditTitle(res.title);
    setEditCategory(res.category);
    setEditDescription(res.description || '');
    setEditExternalUrl(res.url || '');
    setEditFileName(res.fileName || '');
    setEditFileSizeMB((res.fileSize / (1024 * 1024)).toFixed(1));
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingResource) return;
    if (!editTitle.trim() || !editFileName.trim()) {
      setErrorMsg(t.resources.addModal.errorFill);
      return;
    }
    const finalSizeInBytes = Math.round(Number(editFileSizeMB) * 1024 * 1024);
    if (onEditResource) {
      onEditResource(editingResource.id, {
        title: editTitle,
        category: editCategory,
        description: editDescription,
        url: editExternalUrl,
        fileName: editFileName,
        fileSize: finalSizeInBytes
      });
    }
    setEditingResource(null);
  };

  // Translate categories
  const categories = t.resources.categories;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSimulatedFile(file);
      setCustomFileName(file.name);
      
      // Calculate real file size in MB
      const mbSize = (file.size / (1024 * 1024)).toFixed(1);
      setCustomFileSizeMB(mbSize);
    }
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!title.trim() || !customFileName.trim()) {
      setErrorMsg(t.resources.addModal.errorFill);
      return;
    }

    const finalSizeInBytes = Math.round(Number(customFileSizeMB) * 1024 * 1024);

    if (isNaN(finalSizeInBytes) || finalSizeInBytes <= 0) {
      setErrorMsg('Invalid file size.');
      return;
    }

    // Determine download URL (either external drive link or simulated url)
    const finalUrl = externalUrl.trim() || `https://gce-basra.org/storage/large_files/${encodeURIComponent(customFileName)}`;

    // Start chunky upload simulation to demonstrate the gorgeous 400MB+ upload bandwidth capability
    setIsUploading(true);
    setUploadPercent(0);
    setUploadSpeed(4.2); // MB/s simulated initial speed

    let currentProgress = 0;
    const interval = setInterval(() => {
      // Simulate fluctuation speed
      const speedOffset = (Math.random() * 2 - 1) * 0.5;
      const currentSpeed = Math.max(1.5, 4.2 + speedOffset);
      setUploadSpeed(currentSpeed);

      // Advance progress based on current speed relative to total file size
      const sizeMB = Number(customFileSizeMB);
      const step = (currentSpeed / sizeMB) * 100 * 8; // scaled multiplier for fluid, fast-built visual transition
      currentProgress += step;

      if (currentProgress >= 100) {
        clearInterval(interval);
        setUploadPercent(100);
        
        setTimeout(() => {
          onAddResource({
            title,
            category,
            description,
            url: finalUrl,
            fileName: customFileName,
            fileSize: finalSizeInBytes
          });

          onTrackAction('upload_resource', 'resources', `Uploaded resource: ${title} (${customFileSizeMB} MB)`);

          // Reset forms state
          setTitle('');
          setDescription('');
          setExternalUrl('');
          setSimulatedFile(null);
          setCustomFileName('');
          setCustomFileSizeMB('420');
          setIsUploading(false);
          setShowAddResource(false);
        }, 800);
      } else {
        setUploadPercent(Math.round(currentProgress));
      }
    }, 120);
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const dm = 1;
    const sizes = lang === 'ar' ? ['بايت', 'كيلوبايت', 'ميجابايت', 'جيجابايت'] : ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  };

  const filteredResources = resources.filter(res => {
    const matchesSearch = res.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          res.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          res.fileName.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Check if the database category matches the translated categories index
    // Or if it's selected as 'All' (which is selectedCategory index 0)
    const categoryIndex = categories.indexOf(selectedCategory);
    const matchesCategory = categoryIndex === 0 || res.category === categories[categoryIndex] || res.category === 'كتب ومناهج أساسية'; // Fallback mapping
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6" dir={t.dir}>
      {/* Header and Add controllers wrapper */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">{t.resources.title}</h1>
          <p className="text-sm text-gray-500">{t.resources.desc}</p>
        </div>

        {isAdmin && (
          <button
            onClick={() => setShowAddResource(true)}
            className="rounded-xl bg-teal-600 hover:bg-teal-700 font-bold text-white text-xs px-5 py-3 inline-flex items-center gap-1.5 shrink-0 transition shadow-md shadow-teal-600/10 cursor-pointer"
            id="admin-open-upload-modal"
          >
            <Plus className="h-4 w-4" />
            <span>{t.resources.newResourceBtn}</span>
          </button>
        )}
      </div>

      {/* Categories Horizontal filters */}
      <div className="flex flex-wrap gap-2 pb-1 border-b">
        {categories.map((cat: string) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition cursor-pointer ${
              selectedCategory === cat 
                ? 'bg-teal-800 text-white shadow-xs' 
                : 'bg-white border text-slate-600 hover:bg-slate-50'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Main filterable Search Input */}
      <div className="relative">
        <input
          type="text"
          placeholder={t.resources.search}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-xs outline-none focus:border-teal-500 text-right"
        />
      </div>

      {/* List Container Grid */}
      {filteredResources.length > 0 ? (
        <div className="grid gap-6 md:grid-cols-2">
          {filteredResources.map((res) => (
            <motion.div
              layout
              key={res.id}
              className="rounded-2xl border border-slate-100 bg-white p-6 shadow-xs hover:shadow-md transition flex flex-col justify-between text-right"
              id={`resource-item-${res.id}`}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="rounded-lg bg-slate-100 text-slate-700 px-2.5 py-1 text-[9px] font-bold">
                    {res.category}
                  </span>
                  
                  {isAdmin && (
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleMoveUp(res.id)}
                        className="p-1.5 rounded-lg bg-slate-50 text-slate-500 hover:bg-slate-100 transition cursor-pointer"
                        title="Move Up"
                        id={`move-up-resource-${res.id}`}
                      >
                        <ArrowUp className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => handleMoveDown(res.id)}
                        className="p-1.5 rounded-lg bg-slate-50 text-slate-500 hover:bg-slate-100 transition cursor-pointer"
                        title="Move Down"
                        id={`move-down-resource-${res.id}`}
                      >
                        <ArrowDown className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => startEdit(res)}
                        className="p-1.5 rounded-lg bg-teal-50 text-teal-600 hover:bg-teal-100 transition cursor-pointer"
                        title="Edit Reference"
                        id={`edit-resource-btn-${res.id}`}
                      >
                        <Edit className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => onDeleteResource(res.id)}
                        className="p-1.5 rounded-lg bg-red-50 text-red-500 hover:bg-red-100 hover:text-red-600 transition cursor-pointer"
                        title="Delete reference"
                        id={`delete-resource-btn-${res.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  )}
                </div>

                <div className="space-y-1">
                  <h3 className="text-md font-extrabold text-slate-800 flex items-center gap-2">
                    <FileText className="h-4 w-4 text-teal-600 shrink-0" />
                    <span>{res.title}</span>
                  </h3>
                  <div className="flex items-center gap-4 text-[9px] font-mono text-gray-400">
                    <div className="flex items-center gap-1">
                      <HardDrive className="h-3 w-3" />
                      <span>{formatBytes(res.fileSize)}</span>
                    </div>
                    <span className="truncate max-w-[200px]" title={res.fileName}>{res.fileName}</span>
                  </div>
                </div>

                <p className="text-xs text-gray-500 leading-relaxed font-light">
                  {res.description}
                </p>
              </div>

              <div className="pt-4 border-t border-slate-50 flex items-center justify-between mt-4">
                <span className="text-[9px] text-gray-400 font-mono">
                  {t.resources.dateAdded} {new Date(res.addedAt).toLocaleDateString(lang === 'ar' ? 'ar-IQ' : 'en-US')}
                </span>
                
                {!isAdmin ? (
                  <button
                    onClick={() => {
                      setSelectedViewResource(res);
                      setActiveViewPage(0);
                      onTrackAction('view_resource', 'resources', `User opened secure reader: ${res.title}`);
                    }}
                    className="rounded-xl bg-teal-50 hover:bg-teal-100 px-4 py-2 text-xs font-bold text-teal-850 inline-flex items-center gap-1.5 transition cursor-pointer"
                    id={`view-resource-btn-${res.id}`}
                  >
                    <BookOpen className="h-3.5 w-3.5" />
                    <span>{lang === 'ar' ? 'تصفح وقراءة الملف' : 'Browse & Read Document'}</span>
                  </button>
                ) : (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        setSelectedViewResource(res);
                        setActiveViewPage(0);
                        onTrackAction('view_resource', 'resources', `Admin opened secure reader: ${res.title}`);
                      }}
                      className="rounded-xl bg-teal-50 hover:bg-teal-100 px-3 py-2 text-xs font-bold text-teal-850 inline-flex items-center gap-1 cursor-pointer transition"
                      id={`view-resource-btn-${res.id}`}
                    >
                      <BookOpen className="h-3.5 w-3.5" />
                      <span>{lang === 'ar' ? 'تصفح' : 'Browse'}</span>
                    </button>
                    <a
                      href={res.url}
                      onClick={() => onTrackAction('download_resource', 'resources', `Admin downloaded file: ${res.title}`)}
                      target="_blank"
                      className="rounded-xl bg-slate-100 hover:bg-slate-200 px-3 py-2 text-xs font-bold text-slate-800 inline-flex items-center gap-1 transition"
                      download
                      id={`download-resource-link-${res.id}`}
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>{lang === 'ar' ? 'تحميل' : 'Download'}</span>
                    </a>
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="rounded-3xl border border-dashed border-slate-200 bg-white p-12 text-center text-gray-400 space-y-2">
          <BookOpen className="h-10 w-10 mx-auto opacity-50 stroke-1" />
          <p className="text-sm font-light">{t.resources.noResources}</p>
        </div>
      )}

      {/* Admin New Resource Modal with massive file chunks simulation uploader */}
      {showAddResource && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/40 backdrop-blur-xs">
          <div className="w-full max-w-lg rounded-2xl bg-white border border-slate-100 p-6 md:p-8 shadow-2xl relative space-y-4 max-h-[90vh] overflow-y-auto">
            <h3 className="text-md font-extrabold text-slate-800">{t.resources.addModal.title}</h3>
            
            {isUploading ? (
              // Progression simulated screen
              <div className="space-y-6 py-8 text-center">
                <div className="inline-flex p-4 rounded-full bg-teal-50 text-teal-600 animate-pulse relative">
                  <UploadCloud className="h-10 w-10" />
                </div>
                
                <div className="space-y-2">
                  <h4 className="text-sm font-extrabold text-slate-700">{t.resources.addModal.uploading}</h4>
                  <p className="text-xs text-gray-400 font-light">
                    {t.resources.addModal.uploadingDesc}
                  </p>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs font-mono font-bold text-gray-500 max-w-sm mx-auto">
                    <span>{uploadPercent}%</span>
                    <span>{t.resources.addModal.speed} {uploadSpeed.toFixed(1)} MB/s</span>
                  </div>
                  {/* Progress Line */}
                  <div className="w-full max-w-sm mx-auto h-2 bg-slate-100 rounded-full overflow-hidden border">
                    <div 
                      className="h-full bg-teal-600 transition-all duration-150"
                      style={{ width: `${uploadPercent}%` }}
                    />
                  </div>
                  <span className="text-[9px] text-gray-400 font-mono">
                    {t.resources.addModal.approximate} {((uploadPercent / 100) * Number(customFileSizeMB)).toFixed(1)} / {customFileSizeMB} MB
                  </span>
                </div>
              </div>
            ) : (
              // Form submission fields screen
              <form onSubmit={handleAddSubmit} className="space-y-4 text-right">
                {errorMsg && (
                  <div className="p-3 rounded-lg bg-red-105 text-red-700 text-xs text-center font-bold">
                    {errorMsg}
                  </div>
                )}

                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-600 block text-right">{t.resources.addModal.nameLabel}</label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder={t.resources.addModal.namePlaceholder}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs outline-none focus:border-teal-500 focus:bg-white animate-transition"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-600 block text-right">{t.resources.addModal.catLabel}</label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full rounded-xl border border-slate-200 bg-white p-2.5 text-xs focus:border-teal-500"
                    >
                      {categories.filter((_: string, idx: number) => idx > 0).map((catName: string) => (
                        <option value={catName} key={catName}>{catName}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-600 block text-right">{t.resources.addModal.sizeLabel}</label>
                    <input
                      type="number"
                      value={customFileSizeMB}
                      onChange={(e) => setCustomFileSizeMB(e.target.value)}
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs focus:bg-white focus:border-teal-500 font-mono"
                    />
                  </div>
                </div>

                {/* Drop uploader file selection */}
                <div className="border border-dashed border-slate-200 rounded-xl bg-slate-50/50 p-4 text-center cursor-pointer hover:bg-slate-50 transition relative">
                  <input
                    type="file"
                    onChange={handleFileChange}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                  <div className="space-y-1 text-gray-500">
                    <UploadCloud className="h-8 w-8 mx-auto text-gray-400 stroke-1" />
                    <p className="text-xs font-semibold">{t.resources.addModal.browseLabel}</p>
                    <p className="text-[10px] pb-1 font-light">{t.resources.addModal.browseSub}</p>
                  </div>
                </div>

                {customFileName && (
                  <div className="rounded-xl bg-cyan-50 border border-cyan-100 p-3 text-xs text-cyan-800 flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <FileText className="h-4 w-4" />
                      <strong>{customFileName}</strong>
                    </div>
                    <span className="font-mono text-[9px]">{customFileSizeMB} MB</span>
                  </div>
                )}

                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-gray-600 block text-right">{t.resources.addModal.driveLabel}</label>
                  </div>
                  <input
                    type="url"
                    value={externalUrl}
                    onChange={(e) => setExternalUrl(e.target.value)}
                    placeholder={t.resources.addModal.drivePlaceholder}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs outline-none focus:border-teal-500 focus:bg-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-600 block text-right">{t.resources.addModal.descLabel}</label>
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder={t.resources.addModal.descPlaceholder}
                    className="w-full h-20 rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs outline-none focus:border-teal-500 focus:bg-white resize-none"
                  />
                </div>

                <div className="rounded-lg bg-emerald-50 text-emerald-800 p-3 text-[10px] leading-relaxed flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4 text-emerald-600 shrink-0" />
                  <span>{t.resources.addModal.safetyText}</span>
                </div>

                <div className="rounded-xl border border-teal-200 bg-teal-50/50 p-3.5 text-right space-y-1">
                  <div className="flex items-center gap-1.5 text-teal-800 justify-end">
                    <span className="text-[10px] font-black">{lang === 'ar' ? 'سماحية الأحجام الفائقة نشطة للآدمن (+400MB)' : 'High Capacity Upload Permitted (+400MB)'}</span>
                    <ShieldCheck className="h-4 w-4 text-teal-600" />
                  </div>
                  <p className="text-[9.5px] text-teal-700 leading-normal">
                    {lang === 'ar' 
                      ? 'بصفتك مسؤولاً، يمكنك رفع الملفات والمراجع والمناهج الكيميائية بأي سعة وحجم دون حدود قصوى، حتى لو تجاوز الحجم 400 ميغابايت أو 1 جيجابايت. سيقوم السيرفر بتجزئة وحفظ الملف تلقائياً.'
                      : 'As an authorized administrator, you are allowed to upload chemical and methodology reference documents of any size with zero restrictions, including files exceeding 400 Megabytes.'}
                  </p>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="submit"
                    className="flex-1 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs py-2.5 transition cursor-pointer"
                    id="confirm-upload-resource-btn"
                  >
                    {t.resources.addModal.submitBtn}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowAddResource(false);
                      setErrorMsg('');
                    }}
                    className="flex-1 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs py-2.5 transition cursor-pointer"
                  >
                    {t.resources.addModal.cancelBtn}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {editingResource && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/40 backdrop-blur-xs">
          <div className="w-full max-w-lg rounded-2xl bg-white border border-slate-100 p-6 md:p-8 shadow-2xl relative space-y-4 max-h-[90vh] overflow-y-auto">
            <h3 className="text-md font-extrabold text-slate-800 text-right">تعديل مصدر مرجعي علمي</h3>
            
            <form onSubmit={handleEditSubmit} className="space-y-4 text-right">
              {errorMsg && (
                <div className="p-3 rounded-lg bg-red-100 text-red-700 text-xs text-center font-bold">
                  {errorMsg}
                </div>
              )}

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-600 block text-right">{t.resources.addModal.nameLabel}</label>
                <input
                  type="text"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs outline-none focus:border-teal-500 focus:bg-white animate-transition"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-600 block text-right">{t.resources.addModal.catLabel}</label>
                  <select
                    value={editCategory}
                    onChange={(e) => setEditCategory(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-white p-2.5 text-xs focus:border-teal-500"
                  >
                    {categories.filter((_: string, idx: number) => idx > 0).map((catName: string) => (
                      <option value={catName} key={catName}>{catName}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-600 block text-right">{t.resources.addModal.sizeLabel}</label>
                  <input
                    type="number"
                    value={editFileSizeMB}
                    onChange={(e) => setEditFileSizeMB(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs focus:bg-white focus:border-teal-500 font-mono"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-600 block text-right">اسم الملف المرجعي:</label>
                <input
                  type="text"
                  value={editFileName}
                  onChange={(e) => setEditFileName(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs outline-none focus:border-teal-500 focus:bg-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-600 block text-right">{t.resources.addModal.driveLabel}</label>
                <input
                  type="url"
                  value={editExternalUrl}
                  onChange={(e) => setEditExternalUrl(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-xs outline-none focus:border-teal-500 focus:bg-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-600 block text-right">{t.resources.addModal.descLabel}</label>
                <textarea
                  value={editDescription}
                  onChange={(e) => setEditDescription(e.target.value)}
                  className="w-full h-20 rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs outline-none focus:border-teal-500 focus:bg-white resize-none"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs py-2.5 transition cursor-pointer"
                  id="submit-edit-resource"
                >
                  حفظ التعديلات
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setEditingResource(null);
                    setErrorMsg('');
                  }}
                  className="flex-1 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs py-2.5 transition cursor-pointer"
                >
                  {t.resources.addModal.cancelBtn}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Dynamic Secure Reference Viewer Modal */}
      {selectedViewResource && (() => {
        const chapters = getBookChapters(selectedViewResource.title);
        const currentChapter = chapters[activeViewPage] || chapters[0];
        
        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/50 backdrop-blur-xs">
            <div className="w-full max-w-4xl rounded-2xl bg-white border border-slate-105 shadow-2xl overflow-hidden flex flex-col md:flex-row h-[85vh]">
              {/* Sidebar: Table of Contents */}
              <div className="w-full md:w-80 bg-slate-50 border-r border-slate-200 p-5 flex flex-col justify-between text-right">
                <div className="space-y-4">
                  {/* File meta & Title */}
                  <div className="pb-4 border-b border-slate-200">
                    <span className="rounded bg-teal-100 text-teal-800 text-[9px] font-black px-2 py-0.5">
                      {selectedViewResource.category}
                    </span>
                    <h4 className="text-sm font-black text-slate-800 mt-1.5 leading-snug">
                      {selectedViewResource.title}
                    </h4>
                    <p className="text-[10px] text-slate-400 font-mono mt-1">
                      {selectedViewResource.fileName} ({formatBytes(selectedViewResource.fileSize)})
                    </p>
                  </div>

                  {/* Chapters List */}
                  <div className="space-y-2">
                    <h5 className="text-[11px] font-black text-slate-400 mb-2">
                      {lang === 'ar' ? 'فهرس المحتويات الرقمي:' : 'Digital Table of Contents:'}
                    </h5>
                    {chapters.map((ch, idx) => (
                      <button
                        key={idx}
                        onClick={() => setActiveViewPage(idx)}
                        className={`w-full text-right p-3 rounded-xl text-xs font-bold transition flex items-start gap-2.5 cursor-pointer ${
                          activeViewPage === idx 
                            ? 'bg-teal-600 text-white shadow-md shadow-teal-500/10' 
                            : 'bg-white border text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <span className="font-mono opacity-60">0{idx + 1}.</span>
                        <span className="leading-tight">{lang === 'ar' ? ch.titleAr : ch.titleEn}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Secure warning / lock check */}
                <div className="bg-amber-50 border border-amber-200/50 rounded-xl p-3 text-right space-y-1 mt-4">
                  <div className="flex items-center gap-1 text-amber-800 justify-end">
                    <span className="text-[10px] font-black">
                      {lang === 'ar' ? 'تصفح آمن نشط' : 'Secure View Mode'}
                    </span>
                    <Lock className="h-3.5 w-3.5 text-amber-600" />
                  </div>
                  <p className="text-[9px] text-amber-700 font-light leading-snug">
                    {lang === 'ar' 
                      ? 'التنزيل المباشر وتصدير المستند غير متاح للمستخدمين لحماية وتأمين مقررات وملخصات الهيئة.'
                      : 'Direct download is restricted for safety and copyright security of GCE. Read-only permitted.'}
                  </p>
                </div>
              </div>

              {/* Reading Space */}
              <div className="flex-1 p-6 md:p-8 flex flex-col justify-between overflow-y-auto bg-slate-50/20 text-right">
                <div className="space-y-6">
                  {/* Exit header row */}
                  <div className="flex items-center justify-between border-b pb-4">
                    <button
                      onClick={() => setSelectedViewResource(null)}
                      className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-500 transition cursor-pointer"
                      title={lang === 'ar' ? 'إغلاق القارئ' : 'Close reader'}
                    >
                      <X className="h-4 w-4" />
                    </button>
                    
                    <div className="text-right">
                      <span className="text-[10px] text-teal-600 font-bold">
                        {lang === 'ar' ? 'منصة تصفح الكتب الكيميائية' : 'GCE Chemical Books Portal'}
                      </span>
                      <h4 className="text-md font-extrabold text-slate-800">
                        {lang === 'ar' ? currentChapter.titleAr : currentChapter.titleEn}
                      </h4>
                    </div>
                  </div>

                  {/* Reading canvas book simulation */}
                  <div className="bg-white rounded-2xl border p-6 md:p-8 shadow-xs space-y-5 leading-relaxed text-slate-700 min-h-[40vh] font-light max-w-2xl mx-auto prose dark:prose-invert">
                    <p className="text-xs whitespace-pre-line leading-relaxed text-slate-650">
                      {lang === 'ar' ? currentChapter.contentAr : currentChapter.contentEn}
                    </p>

                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-2 mt-6">
                      <h6 className="text-[10px] font-bold text-slate-500 font-mono">
                        {lang === 'ar' ? '💡 الملاحظات الفنية للمراجعة:' : '💡 SECURE AUDITING PARAMETERS:'}
                      </h6>
                      <ul className="text-[10px] text-slate-500 list-disc list-inside space-y-1">
                        {lang === 'ar' ? (
                          <>
                            <li>التدفق التصميمي المعتمد يعادل 3,400 برميل باليوم بوحدات معالجة مصفى البصرة.</li>
                            <li>معاملات الأمان والضغط التفاضلي مطابقة تماماً للمواصفات القياسية ASTM.</li>
                          </>
                        ) : (
                          <>
                            <li>Standard process design flow is set to 3,400 BPD at Shuaiba unit.</li>
                            <li>Critical delta-P factors audited strictly matching ASME B31.3.</li>
                          </>
                        )}
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Footer section & Admin bypass inside viewer */}
                <div className="mt-8 border-t pt-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-slate-400 text-[10px]">
                  {isAdmin && (
                    <a
                      href={selectedViewResource.url}
                      onClick={() => onTrackAction('download_resource', 'resources', `Admin downloaded from viewer: ${selectedViewResource.title}`)}
                      className="rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs px-4 py-2 flex items-center gap-1 cursor-pointer transition shadow-sm"
                      download
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>{lang === 'ar' ? 'تنزيل كمسؤول (تخطي الحظر)' : 'Download as Admin (Bypass)'}</span>
                    </a>
                  )}
                  
                  <span className="font-mono text-[9px] mr-auto">
                    {lang === 'ar' ? 'الاتحاد الكيميائي بالبصرة' : 'Basra Chemists Association'} © {new Date().getFullYear()}
                  </span>
                </div>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
}
