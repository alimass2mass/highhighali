/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Home, Monitor, Award, BookOpen, Share2, Info, LayoutDashboard, 
  LogOut, Landmark, User as UserIcon, Globe, ChevronDown, Check, X,
  Sun, Moon, Newspaper, Shield, Bell
} from 'lucide-react';
import { User } from '../types';
import { LanguageType } from '../locales';

interface SidebarProps {
  currentUser: User | null;
  activeSection: string;
  onNavigate: (section: string) => void;
  onLogout: () => void;
  lang: LanguageType;
  setLang: (lang: LanguageType) => void;
  t: any;
  isOpen: boolean;
  onClose: () => void;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
}

export default function Sidebar({ 
  currentUser, 
  activeSection, 
  onNavigate, 
  onLogout,
  lang,
  setLang,
  t,
  isOpen,
  onClose,
  theme,
  onToggleTheme
}: SidebarProps) {
  const isAdmin = currentUser?.role === 'admin';
  const [isLangDropdownOpen, setIsLangDropdownOpen] = useState(false);

  const menuItems = [
    { id: 'home', label: t.sections.home, icon: Home, badge: null },
    { id: 'platforms', label: t.sections.platforms, icon: Monitor, badge: t.platforms.integrated },
    { id: 'courses', label: t.sections.courses, icon: Award, badge: null },
    { id: 'resources', label: t.sections.resources, icon: BookOpen, badge: '400MB+' },
    { id: 'news', label: t.sections.news, icon: Newspaper, badge: null },
    { id: 'notifications', label: lang === 'ar' ? 'صندوق الإشعارات' : 'Notifications', icon: Bell, badge: null },
    { id: 'accounts', label: t.sections.accounts, icon: Share2, badge: null },
    { id: 'security_settings', label: lang === 'ar' ? 'درع الأمان (2FA)' : 'Security (2FA)', icon: Shield, badge: null },
    { id: 'about', label: t.sections.about, icon: Info, badge: null },
  ];

  const languages: { code: LanguageType; name: string }[] = [
    { code: 'ar', name: 'العربية' },
    { code: 'en', name: 'English' },
    { code: 'de', name: 'Deutsch' },
    { code: 'es', name: 'Español' }
  ];

  const isRtl = t.dir === 'rtl';

  // Responsive sidebar wrappers: overlay on mobile, permanent dock on desktop
  return (
    <>
      {/* Mobile Drawer Overlay Backdrop */}
      {isOpen && (
        <div 
          onClick={onClose}
          className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-50 md:hidden"
        />
      )}

      <aside 
        className={`fixed md:sticky top-0 bottom-0 z-50 w-80 bg-slate-900 text-slate-300 flex flex-col justify-between h-screen shrink-0 overflow-y-auto scrollbar-thin transition-transform duration-300 md:translate-x-0 ${
          isRtl 
            ? 'border-l border-slate-800' 
            : 'border-r border-slate-800'
        } ${
          isOpen 
            ? 'translate-x-0' 
            : isRtl 
              ? 'translate-x-[100%]' 
              : '-translate-x-[100%]'
        }`}
        dir={t.dir}
      >
        <div>
          {/* Sidebar Brand Header */}
          <div className="p-6 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="p-2.5 rounded-xl bg-teal-600/20 border border-teal-500/30 text-emerald-300 flex items-center justify-center shadow-inner">
                <Landmark className="h-5 w-5" />
              </span>
              <div className="space-y-0.5">
                <h1 className="text-sm font-black text-white hover:text-emerald-300 transition-colors leading-tight">
                  {t.appSubName}
                </h1>
                <p className="text-[9px] text-teal-400 font-bold leading-none tracking-tight">
                  {t.certifiedPlatform}
                </p>
              </div>
            </div>

            {/* Close button on mobile overlay */}
            <button 
              onClick={onClose}
              className="p-1.5 rounded-lg hover:bg-slate-800 md:hidden text-slate-400 hover:text-white transition"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Elegant Language Switcher Widget inside sidebar */}
          <div className="px-5 py-4 border-b border-slate-800/60 relative space-y-4">
            <div>
              <span className="text-[9px] font-bold text-gray-500 tracking-wider uppercase block mb-1.5 align-right">
                {lang === 'ar' ? 'لغة الواجهة / LANGUAGE' : 'INTERFACE LANGUAGE'}
              </span>
              <button
                onClick={() => setIsLangDropdownOpen(!isLangDropdownOpen)}
                className="w-full rounded-xl bg-slate-950/35 border border-slate-800 hover:border-slate-700 px-3 py-2 text-xs font-semibold text-slate-200 flex items-center justify-between transition cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <Globe className="h-4 w-4 text-teal-500" />
                  <span>{languages.find(l => l.code === lang)?.name}</span>
                </div>
                <ChevronDown className="h-3.5 w-3.5 text-slate-500" />
              </button>

              {isLangDropdownOpen && (
                <div className="absolute left-5 right-5 mt-1 rounded-xl bg-slate-800 border border-slate-700 shadow-xl py-1 z-55">
                  {languages.map((l) => (
                    <button
                      key={l.code}
                      onClick={() => {
                        setLang(l.code);
                        setIsLangDropdownOpen(false);
                      }}
                      className={`w-full text-right px-4 py-2 text-xs font-semibold flex items-center justify-between transition ${
                        lang === l.code 
                          ? 'bg-slate-700 text-teal-300' 
                          : 'hover:bg-slate-700/55 text-slate-300'
                      }`}
                    >
                      <span>{l.name}</span>
                      {lang === l.code && <Check className="h-3.5 w-3.5 text-teal-400" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Premium Theme Switcher Block (يومي / ليلي) */}
            <div>
              <span className="text-[9px] font-bold text-gray-500 tracking-wider uppercase block mb-1.5 align-right">
                {lang === 'ar' ? 'مظهر المنصة / THEME' : 'INTERFACE THEME'}
              </span>
              
              <div className="p-1 rounded-xl bg-slate-950/45 border border-slate-800 flex items-center gap-1">
                <button
                  onClick={() => theme === 'dark' && onToggleTheme()}
                  className={`flex-1 rounded-lg py-1.5 px-2 text-[11px] font-bold transition-all duration-200 flex items-center justify-center gap-1.5 cursor-pointer ${
                    theme === 'light'
                      ? 'bg-gradient-to-r from-teal-500 to-emerald-500 text-slate-950 shadow-md shadow-teal-500/10'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Sun className="h-3.5 w-3.5" />
                  <span>
                    {lang === 'ar' ? 'نهاري' : lang === 'en' ? 'Light' : lang === 'de' ? 'Hell' : 'Claro'}
                  </span>
                </button>

                <button
                  onClick={() => theme === 'light' && onToggleTheme()}
                  className={`flex-1 rounded-lg py-1.5 px-2 text-[11px] font-bold transition-all duration-200 flex items-center justify-center gap-1.5 cursor-pointer ${
                    theme === 'dark'
                      ? 'bg-slate-800 text-teal-300 border border-slate-700 shadow-inner'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Moon className="h-3.5 w-3.5" />
                  <span>
                    {lang === 'ar' ? 'ليلي' : lang === 'en' ? 'Dark' : lang === 'de' ? 'Dunkel' : 'Oscuro'}
                  </span>
                </button>
              </div>
            </div>
          </div>

          {/* Sidebar Menu list */}
          <nav className="p-4 space-y-1">
            <span className="text-[10px] font-bold text-gray-500 tracking-wider uppercase px-3 block mb-2">
              {lang === 'ar' ? 'أقسام المنصة' : 'Syllabus Portals'}
            </span>
            
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  onClose();
                }}
                className={`w-full rounded-xl px-4 py-3 text-xs font-bold transition flex items-center justify-between group ${
                  activeSection === item.id 
                    ? `bg-gradient-to-r from-teal-800 to-emerald-800 text-white shadow-md shadow-teal-900/40 border-teal-400 ${isRtl ? 'border-r-4' : 'border-l-4'}` 
                    : 'hover:bg-slate-800/60 hover:text-white text-slate-400'
                }`}
                id={`nav-${item.id}`}
              >
                <div className="flex items-center gap-3">
                  <item.icon className={`h-4.5 w-4.5 transition ${
                    activeSection === item.id ? 'text-teal-300' : 'text-slate-500 group-hover:text-slate-300'
                  }`} />
                  <span>{item.label}</span>
                </div>

                {item.badge && (
                  <span className={`rounded-md px-1.5 py-0.5 text-[8px] font-mono leading-none ${
                    activeSection === item.id ? 'bg-teal-700 text-white' : 'bg-slate-800 text-teal-400 font-bold'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            ))}

            {/* Admin panel menu split link */}
            {isAdmin && (
              <div className="pt-4 mt-4 border-t border-slate-800/60 space-y-1">
                <span className="text-[10px] font-bold text-red-500/80 tracking-wider uppercase px-3 block mb-2">
                  {lang === 'ar' ? 'إدارة الهيئة' : 'ADMINISTRATOR'}
                </span>
                <button
                  onClick={() => {
                    onNavigate('admin');
                    onClose();
                  }}
                  className={`w-full rounded-xl px-4 py-3 text-xs font-bold transition flex items-center gap-3 ${
                    activeSection === 'admin' 
                      ? 'bg-red-950/40 text-red-300 border-r-4 border-red-500 font-black shadow-inner' 
                      : 'hover:bg-slate-800/60 text-slate-500 hover:text-red-300'
                  }`}
                  id="nav-admin"
                >
                  <LayoutDashboard className="h-4.5 w-4.5 shrink-0" />
                  <span>{t.adminPanel}</span>
                </button>
              </div>
            )}
          </nav>
        </div>

        {/* User Session Detail Widget */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/20">
          <div className="rounded-xl bg-slate-950/40 p-3 flex items-center justify-between gap-3 shadow-inner">
            <div className="flex items-center gap-2.5 min-w-0">
              <span className="h-9 w-9 rounded-lg bg-teal-800/30 border border-teal-600/20 text-teal-400 flex items-center justify-center font-bold shrink-0">
                <UserIcon className="h-4.5 w-4.5" />
              </span>
              <div className="space-y-0.5 min-w-0">
                <h4 className="text-[11px] font-extrabold text-white truncate">{currentUser?.name}</h4>
                <p className="text-[9px] text-teal-400 font-bold leading-none truncate">
                  {currentUser?.role === 'admin' ? t.adminRole : t.studentRole}
                </p>
              </div>
            </div>

            <button
              onClick={onLogout}
              className="p-1.5 rounded-lg hover:bg-red-950/60 text-slate-500 hover:text-red-400 transition shrink-0"
              title={t.logout}
              id="sidebar-logout-btn"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
