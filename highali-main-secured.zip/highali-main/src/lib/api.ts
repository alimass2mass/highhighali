export function getApiUrl(path: string): string {
  // If the path is already an absolute URL, return as-is
  if (path.startsWith('http://') || path.startsWith('https://')) {
    return path;
  }

  let origin = '';

  // 1. Try standard window.location.origin
  try {
    if (window.location.origin && window.location.origin !== 'null' && window.location.origin !== 'about:') {
      origin = window.location.origin;
    }
  } catch (e) {
    // Ignore restricted reading
  }

  // 2. Try parsing window.location.href with regex (robust even in sandboxes if loaded with src)
  if (!origin) {
    try {
      const href = window.location.href;
      if (href && (href.startsWith('http://') || href.startsWith('https://'))) {
        const match = href.match(/^(https?:\/\/[^\/]+)/);
        if (match) {
          origin = match[1];
        }
      }
    } catch (e) {
      // Ignore
    }
  }

  // 3. Try parsing document.URL with regex
  if (!origin) {
    try {
      const docUrl = document.URL;
      if (docUrl && (docUrl.startsWith('http://') || docUrl.startsWith('https://'))) {
        const match = docUrl.match(/^(https?:\/\/[^\/]+)/);
        if (match) {
          origin = match[1];
        }
      }
    } catch (e) {
      // Ignore
    }
  }

  // 4. Try looking at script or link tags in the page load to extract the container domain
  if (!origin) {
    try {
      const elements = [
        ...Array.from(document.getElementsByTagName('script')),
        ...Array.from(document.getElementsByTagName('link'))
      ];
      for (const el of elements) {
        const src = (el as any).src || (el as any).href;
        if (src && (src.startsWith('http://') || src.startsWith('https://'))) {
          const match = src.match(/^(https?:\/\/[^\/]+)/);
          if (match) {
            const domain = match[1];
            const isExternal = 
              domain.includes('google.com') || 
              domain.includes('gstatic.com') || 
              domain.includes('aistudio.google.com') ||
              domain.includes('cdnjs.cloudflare.com') ||
              domain.includes('unpkg.com') ||
              domain.includes('jsdelivr.net') ||
              domain.includes('bootstrapcdn.com') ||
              domain.includes('fontawesome.com') ||
              domain.includes('unsplash.com') ||
              domain.includes('tailwindcss.com');
            
            if (!isExternal) {
              origin = domain;
              break;
            }
          }
        }
      }
    } catch (e) {
      // Ignore
    }
  }

  // 5. Fallback if the iframe is in about:srcdoc or about:blank sandbox without other sources
  if (!origin) {
    origin = 'https://ais-dev-gz7ew7j2bw3xxvjp5etqvn-761735451663.europe-west2.run.app';
  }

  const cleanPath = path.startsWith('/') ? path : `/${path}`;
  const cleanOrigin = origin.endsWith('/') ? origin.slice(0, -1) : origin;
  return `${cleanOrigin}${cleanPath}`;
}
