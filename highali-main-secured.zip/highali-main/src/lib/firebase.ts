import { initializeApp, getApp, getApps } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

let app;
let auth: any;
let db: any;
let isFirebaseValid = false;

try {
  // Check if API key is not placeholder and behaves as a real config
  if (firebaseConfig && firebaseConfig.apiKey && !firebaseConfig.apiKey.includes('Dummy')) {
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    auth = getAuth(app);
    db = getFirestore(app);
    isFirebaseValid = true;
    console.log("Firebase initialized successfully using your live configured platform.");
  } else {
    console.warn("Using baseline secure client configuration sandbox. Complete live Firebase UI activation to stream to live cloud.");
  }
} catch (error) {
  console.error("Firebase startup check deferred gracefully. Activating baseline local sandbox mode:", error);
}

export { auth, db, isFirebaseValid };
export default app;
