/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type LanguageType = 'ar' | 'en' | 'de' | 'es';

export const locales = {
  ar: {
    dir: 'rtl',
    langName: 'العربية',
    appName: 'الهيئة العامة للمهندسين الكيميائيين بالبصرة',
    appSubName: 'الكيميائيين في البصرة',
    certifiedPlatform: 'منصة معتمدة وموثقة لمهندسي البصرة',
    logout: 'تسجيل خروج',
    login: 'تسجيل الدخول',
    register: 'تسجيل حساب جديد',
    adminPanel: 'لوحة التحكم (الادمن)',
    studentRole: 'طالب',
    adminRole: 'مدير المنصة',
    sections: {
      home: 'الواجهة الرئيسية',
      platforms: 'المنصات والمختبرات الرقمية',
      courses: 'الحقائب والدورات',
      resources: 'المصادر الهندسية',
      accounts: 'حسابات الرسمية للاتحاد',
      news: 'الأخبار والنشاطات',
      about: 'من نحن والمطور',
      admin: 'لوحة تحكم المشرف'
    },
    auth: {
      welcome: 'مرحباً بك في المنصة الشاملة',
      subtitle: 'قم بتسجيل الدخول كخريج أو طالب أو مشرف بالهيئة لدخول فصول التدريب والمصادر الكيميائية',
      email: 'البريد الإلكتروني:',
      password: 'كلمة المرور:',
      name: 'الاسم الكامل:',
      academicYear: 'المرحلة الأكاديمية أو المستوى:',
      loginBtn: 'دخول للمنصة التعليمية',
      registerBtn: 'تأكيد التسجيل وإنشاء الحساب',
      hasAccount: 'أملك حساباً (دخول)',
      newAccount: 'تسجيل حساب جديد',
      testLogins: 'خيارات الدخول السريعة للاختبار:',
      testAdmin: 'حساب المشرف (الآدمن):',
      testStudent: 'حساب طالب تجريبي:',
      adminRoleText: 'مشرف الهيئة العامة',
      passwordtext: 'كلمة السر:',
      loading: 'جاري التحقق والمصادقة...',
      agreeDetails: 'بالتسجيل، أنت توافق على شروط وقوانين الهيئة الكيميائية العامة بالبصرة.',
      errorAllFields: 'الرجاء توفير جميع المتطلبات الأساسية للتسجيل.',
      errorMissingCreds: 'الرجاء إدخال البريد الإلكتروني وكلمة المرور.',
      studentPhase1: 'المرحلة الأولى - هندسة كيميائية',
      studentPhase2: 'المرحلة الثانية - هندسة كيميائية',
      studentPhase3: 'المرحلة الثالثة - هندسة كيميائية',
      studentPhase4: 'المرحلة الرابعة - هندسة كيميائية',
      graduate: 'خريج هندسة كيميائية',
      practitioner: 'مهندس ممارس في القطاع النفطي/الصناعي'
    },
    home: {
      title: 'الهيئة العامة للمهندسين الكيميائيين في البصرة',
      subtitle: 'المنصة التعليمية الشاملة لتمكين الطلبة والمهندسين وتطوير خبراتهم العلمية في مجالات الصناعات النفطية، تكنولوجيا المنظفات وعلوم التجميل الحديثة في عاصمة العراق الاقتصادية.',
      explorePlatforms: 'استكشف المنصات الرقمية',
      whoAreWe: 'من نحن؟',
      stats: {
        labs: 'المختبرات والمنصات',
        labsUnit: 'منصات ومحاكيات',
        courses: 'الدورات الهندسية المتاحة',
        coursesUnit: 'تخصصات تدريبية',
        resources: 'المصادر والكتب المنهجية',
        resourcesUnit: 'مراجع علمية ضخمة',
        members: 'المنتسبين والمهندسين',
        membersUnit: 'مهندس ومهندسة'
      },
      announcements: 'الإعلانات وأخبار الهيئة العامة بالبصرة',
      news: [
        {
          title: 'إطلاق معرض ومختبر الصابون السائل والمنظفات الأول بالبصرة',
          date: 'منذ يومين',
          desc: 'تدعو الهيئة العامة للمهندسين الكيميائيين كافة الخريجين للمشاركة في ورشة العمل المقامة عملياً بمقر الهيئة لتعليم أسس معايرة وخلط وتصميم مستحضرات تنظيف الصابون.',
          tag: 'مختبر عملي'
        },
        {
          title: 'التعاون المستمر مع الكفاءات الميدانية',
          date: 'منذ 5 أيام',
          desc: 'التعاون مستمر مع المهندسين العاملين في شتى الحقول النفطية المحلية و العالمية.',
          tag: 'تعاون دولي ومحلي'
        },
        {
          title: 'فتح باب التبرع بالمراجع والكتب الورقية الكيميائية لمكتبة البصرة',
          date: 'منذ أسبوع',
          desc: 'ضمن حملة علمية كبرى، يتبرع المهندسون والاستشاريون بنسخ نادرة من مراجع لندل، مكيب، وبيري؛ لإتاحتها كملفات مسح ضوئي عالية الجودة للتحميل في موقع الهيئة.',
          tag: 'نشر المعرفة'
        }
      ],
      safety: 'التوجيهات الهندسية للسلامة والبيئة',
      safetyText: 'تؤكد لجنة السلامة والبيئة المهنية بالهيئة على ضرورة قراءة كافة إجراءات الوقاية الذاتية والارتداء التام لـ PPE بمجرد الدخول إلى المختبرات الميدانية.',
      safetyPoints: [
        'لبس معطف المختبر والأقنعة الفموية الواقية.',
        'الانتباه الجيد لمخارج تسريب الغاز الكيميائي.',
        'مراجعة بطاقة السلامة MSDS لكل وعاء مذيب كيميائي.'
      ],
      visitLabs: 'الدخول لمختبرات المحاكاة الرقمية',
      thakerActivity: 'نشاط سريع: منصة ذاكر لتلخيص الأبحاث',
      thakerDesc: 'التقط مادة درسك الطويلة، الصقها في الذكاء الاصطناعي للحصول على ملخص فوري للمعادلات والمصطلحات الكيميائية.',
      openThaker: 'افتح ذاكر الهندسية تلخيص'
    },
    platforms: {
      title: 'قسم المنصات الرقمية والمختبرات',
      subtitle: 'اختر المنصة أو مختبر المحاكاة الكيميائية لبدء التطوير العملي',
      searchPlat: 'ابحث عن منصة أو مختبر...',
      integrated: 'مدمج ذكي',
      aiInteractive: 'AI INTERACTIVE',
      externalWeb: 'EXTERNAL WEB APP',
      enterSim: 'دخول المحاكي الذكي',
      simulateBtn: 'تشغيل المحاكاة',
      externalBtn: 'رابط خارجي',
      backBtn: 'العودة للمنصات الرقمية',
      authorities: 'مختبرات الهيئة الكيميائية الرقمية بالبصرة',
      statusOnline: 'حالة الاتصال: ONLINE',
      thaker: {
        badge: 'محرك التلخيص الذكي المدعوم بـ Gemini 3.5',
        title: 'أدخل ورقتك البحثية أو تقريرك العلمي للتلخيص',
        desc: 'من خلال منصة ذاكر الهندسية، يمكنك لصق أي محتوى كيميائي طويل (تصل إلى مقاطع صفحات كاملة) لاستخلاص موازين وتفاعلات وصيغ ومفاهيم الهندسة الكيميائية الفورية.',
        placeholder: 'الصق النص العلمي الكيميائي هنا للبدء بالتحليل والتلخيص التلقائي باستخدام الذكاء الاصطناعي...',
        limits: 'حجم المدخلات الموصى بها: 100 - 10,000 كلمة',
        runBtn: 'بدء التلخيص الهيكلي',
        running: 'جاري تحليل التقرير وتصميم الفصول...',
        resultsTitle: 'نتائج التلخيص الهندسية المستخلصة',
        resultsPlaceholder: 'اكتب النص في الحقل المقابل، ثم اضغط على زر التلخيص لرؤية الهيكلة العلمية الكاملة والمعادلات والمصطلحات الأساسية.',
        poweredBy: 'مدعوم بتقنية جيميناي 3.5 فلاش السحابية'
      },
      interview: {
        title: 'محاكي مقابلات الوظائف الهندسية الكيميائية',
        desc: 'اختر التخصص الكيميائي أو جهة المقابلة، وسيجري معك ممثلو لجنة التوظيف بالهيئة العامة اختباراً تقنياً في مهارات موازين التصميم، تقييم الأثر البيئي، والمعدات لتهيئتك لمقابلات العمل النفطية والصناعية بالبصرة.',
        topicLabel: 'تحديد موضوع المقابلة كخلفية لـ AI:',
        topics: [
          'تكرير النفط وعمليات مصفى الشعيبة ومبدأ أبراج التقطير الكسرية',
          'مبادئ معالجة وإنتاج الغاز الطبيعي السائل والجاف في حقول البصرة (شركة غاز البصرة BGC)',
          'التحول الكيميائي الحراري لمعادلة الأحماض والمذيبات في معامل المنظفات',
          'معدات وموازين انتقال المادة والحرارة المتقدمة Heat & Mass Transfer',
          'أساسيات جهاز UV visible ومقاييس فحص عينات المياه الملوثة بالبصرة'
        ],
        btnStart: 'بدء جلسة المقابلة التقنية الآن',
        activeTopic: 'الموضوع النشط للمقابلة:',
        instructionsTitle: '💡 تعليمات للطلبة:',
        instructions: [
          'أجب عن تساؤلات اللجنة بمهنية ووضوح باللغة العربية أو مصطلحات المهنة الإنجليزية.',
          'لا تتردد في شرح المعادلات الكيميائية؛ فالمهندسون المقابلون يطالبون بمعرفة الآلية التفصيلية للتصميم.'
        ],
        btnEnd: 'إنهاء هذه الجلسة والرجوع',
        chatHeader: 'لجنة توظيف الهيئة بالبصرة:',
        chatUserHeader: 'إجابتك (المرشح):',
        chatPlaceholder: 'اكتب إجابتك التقنية الموضحة هنا للجنة التقييم...',
        loading: 'أعضاء اللجنة يقومون بتقييم إجابتك وصياغة سؤال كيميائي جديد مخصص...'
      },
      bot: {
        title: 'البوت الكيميائي المساعد الرقمي للهيئة',
        welcome: 'مرحباً بك مهندسنا البصري الكريم! أنا البوت الرقمي العلمي للهيئة الكيميائية. يمكنك سؤالي عن موازنة المادة (Material Balance)، تفاعلات الثرموديناميكا، أو معايرة المركبات الكيميائية.',
        instructions: 'استشارة بوت الهيئة العامة الرقمي لتوجيه وحل المسائل العلمية كيميائياً',
        placeholder: 'اسأل البوت: ما هي صيغة الصابون السائل؟ أو كيف نحسب التدفق الحراري للتصاميم المعززة؟',
        loading: 'البوت الرقمي يستحضر القواعد والمعادلات الهندسية لحل مسألتك...'
      },
      detergents: {
        title: 'المحاكاة ثلاثية الأبعاد لخلط وإنتاج المنظفات السائلة والمطهرات',
        desc: 'صمم محلول صابون آمن ومثالي وفق معايير الجودة العراقية عبر تحديد المذيب وموازنة درجة الحموضة pH.',
        solTitle: '1. المذيب الأساسي:',
        waterSol: '💧 ماء هيدروجيني معقم ومقطر (1 لتر)',
        acidTitle: '2. اختر المادة الفعالة للإضافة في المفاعل:',
        acids: [
          'حمض السلفونيك (LABSA)',
          'هيدروكسيد الصوديوم (NaOH)',
          'التكسابون المعزز للرغوة'
        ],
        btnMix: 'صب المزيج وفعّل التفاعل',
        phStatus: 'مقياس الـ pH المقاس:',
        reactionOk: 'تفاعل آمن ومتكامل! الصابون صالح للتشغيل والاستخدام المنزلي والترخيص.',
        logReady: 'مستعد لبدء خلط المكونات الكيميائية.',
        logNoAcid: 'الرجاء اختيار المادة الفعالة للإضافة في المفاعل أولاً.',
        logPour: 'تم صب كمية مدروسة من المادة المضافة في الوسط المائي.',
        logLabsa: 'انخفضت درجة الحموضة pH إلى 3.2. الوسط الآن حمضي وقوي جداً! المطلوب الآن معادلة حمض السلفونيك عبر إضافة صودا كاوية أو هيدروكسيد الصوديوم تدريجياً للوصول للتعادل الرغوي.',
        logNaohNeutral: 'تمت الإضافة بنجاح! حدث تفاعل تعادل حمض-قاعدة نتج عنه سالفونيت الصوديوم الرغوي والماء المالح. تفاعلت الجزيئات بنجاح ووصلت درجة الـ pH إلى 7.2 (آمن للجلد ومثالي للصابون ومزيل الدهون). رائع! لقد أكملت تكوين رغوة الصابون السائل وفق معايير الجودة العراقية بالبصرة!',
        logNaohBase: 'ارتفعت درجة الحموضة pH إلى 11.5! المحلول الآن قاعدي حارق وضار بالبشرة. الرجاء تصحيح المعادلة بمذيب حامضي تدريجياً.',
        logTexapon: 'تم تعزيز الرغوة واللزوجة بإضافة مادة التكسابون، الوسط متماسك ومثالي للرغوة الفعالة والمنظفات.'
      },
      uvVis: {
        title: 'محاكي لوحة فحص وتدريب جهاز UV-Visible Spectrometer الطيفي',
        desc: 'فرّز تراكيز المركبات الكيميائية وامتصاص الضوء لعينات المياه والمذيبات وفق قانون بير-لامبرت الكهروضوئي.',
        sampleLabel: '1. اختر عينة الفحص الطيفي بالخلية (Cuvette):',
        samples: [
          'محلول كبريتات النحاس',
          'محلول بيكرومات البوتاسيوم',
          'محلول الفينول فثالين والكاشف الكيميائي'
        ],
        waveLabel: '2. قم بمعايرة الطول الموجي المطلوب (400nm - 800nm):',
        concLabel: '3. حدد مستوى التركيز المولي الكيميائي للوسط (Molar):',
        btnMeasure: 'تأكيد الضوء وبدء القراءة الطيفية',
        measuring: 'جاري تشغيل الأشعة الفوق بنفسجية وقراءة الامتصاصية الطيفية لـ Cuvette...',
        results: 'نتائج الاختبار والمعايرة الطيفية المسجلة للجهاز:',
        absText: 'قيمة الامتصاصية المقروءة (Absorbance - A):',
        beerLawTitle: '📌 تقييم قانون بير-لامبرت للعينات بالبصرة:',
        beerLawText: 'بتطبيق المعادلة A = ε * C * L، القراءة تظهر تفاعلاً مستقراً وطيفاً دقيقاً ومطابقاً لخصائص الوسط للنمذجة الكيميائية البيئية بالبصرة.',
        noAbs: 'الجهاز مغلق حالياً. يرجى تهيئة العينات والضغط على معايرة الأشعة لبدء القراءة.'
      },
      hplc: {
        title: 'مختبر محاكي جهاز HPLC',
        desc: 'تطبيق محاكاة هندسي كيميائي تفاعلي لفهم خطوات تشغيل جهاز الكروماتوغرافيا السائلة عالية الأداء HPLC، برمجة الضخ، وقراءة الكروماتوغرام - مبني على المحتوى العلمي لدورة المهندس علي سيف الدين حيدر.'
      }
    },
    courses: {
      title: 'الحقائب التدريبية والدورات التخصصية بالهيئة',
      desc: 'مجموعة من الدورات المهنية والتقنية التي تنظمها الهيئة لرفع كفاءة المهندسين الكيميائيين والطلبة بالبصرة.',
      search: 'ابحث عن دورة أو حقيبة تدريبية...',
      newCourseBtn: 'إضافة دورة جديدة',
      instructor: 'المدرب:',
      dateAdded: 'تاريخ الرفع:',
      accessBtn: 'الوصول للحقيبة والدورة',
      noCourses: 'لم نجد أي مراجع تدريبية مطابقة لبحثك.',
      addModal: {
        title: 'إضافة حقيبة تدريبية ودورة جديدة للموقع',
        nameLabel: 'اسم أو عنوان الدورة التدريبية:',
        namePlaceholder: 'مثال: دورة التحليل الكيميائي لفرز متبقيات الغاز',
        urlLabel: 'رابط الوصول للحقيبة والدورة:',
        urlPlaceholder: 'رابط المنهاج، Google Drive أو YouTube',
        instructorLabel: 'اسم المدرب أو المحاضر:',
        instructorPlaceholder: 'أو تترك افتراضي باسم لجان الهيئة بالبصرة',
        descLabel: 'وصف قصير للحقيبة ومحتواها:',
        descPlaceholder: 'توصيف مبادئ الدورة وأهداف التأهيل الكهروكيميائي لمهندسي البصرة',
        confirmBtn: 'تأكيد الإضافة',
        cancelBtn: 'إلغاء الأمر',
        errorFill: 'الرجاء تعبئة العنوان ورابط الوصول للملخص.'
      }
    },
    resources: {
      title: 'مستودع المصادر الهندسية والكتب (400MB+)',
      desc: 'مكتبة رقمية متكاملة لتحميل الكتب المنهجية والملاحظات وحلول المسائل الكيميائية وتكرير البترول بالبصرة.',
      categories: ['الكل', 'كتب ومناهج أساسية', 'تصميم المصانع والمفاعلات', 'تقنيات النفط والغاز', 'هندسة البيئة والمياه', 'أبحاث ومقالات علمية'],
      search: 'ابحث بالاسم، التوصيف، التفاصيل أو كتاب بيري المنهجي...',
      newResourceBtn: 'رفع مصدر علمي جديد',
      fileSize: 'حجم الملف:',
      dateAdded: 'تاريخ الرفع:',
      downloadBtn: 'تحميل الملف المنهجي',
      noResources: 'لم يتم إيجاد مصادر أو كتب تطابق رغبتك الكروماتوغرافية والبحثية.',
      addModal: {
        title: 'تحميل وتوثيق الكتب والمصادر الهندسية',
        uploading: 'جاري معالجة ورفع الملف الكيميائي الضخم لخدمة الهيئة بالبصرة',
        uploadingDesc: 'قد يستغرق ذلك بضع ثوانٍ للملفات الكبيرة (أكثر من 400 ميغابايت) لتهيئة التخزين والاتصالات السحابية المجزأة بالبصرة.',
        speed: 'سرعة النقل:',
        approximate: 'المرفوع التقريبي:',
        nameLabel: 'اسم المرجع أو مستودع الفحص:',
        namePlaceholder: 'مثال: مبادئ الديناميكا الحرارية الكيميائية لفرانك',
        catLabel: 'تصنيف المرجع الدراسي للكتاب:',
        sizeLabel: 'تقدير حجم الملف بالميجابايت:',
        browseLabel: 'تصفح ملف PDF أو مستند هندسي مدرج',
        browseSub: 'بلا حدود قصوى: مدعوم بالكامل للآدمن لرفع أي حجم (فوق 400 ميغابايت وحتى 1.5 جيجابايت) بأمان وسرعة فائقة',
        driveLabel: 'رابط تخزين سحابي بديل (اختياري / موصى به للسرعة الكبرى):',
        drivePlaceholder: 'ضع رابط التنزيل المباشر كـ Google Drive/OneDrive أو ابقه خالياً وسيتم توليد رابط تلقائي',
        descLabel: 'عن الكتاب والمنهاج الكيميائي لمطالعة الطلبة:',
        descPlaceholder: 'اكتب أهداف الكتاب والفصول الكيميائية والمصطلحات المساعدة للتحميل والتبسيط الدراسي للأجيال...',
        safetyText: 'نظام التخزين الرقمي يضمن تجزئة ورفع كامل للمجلدات ذات الأحجام العملاقة (أكثر من 400MB) دون انقطاع الاتصال بالسيرفر.',
        submitBtn: 'رابط وتفعيل رفع المصدر',
        cancelBtn: 'إلغاء الأمر',
        errorFill: 'الرجاء تعبئة اسم المرجع الكيميائي واسم الملف المدرج وحجمه الصالح.'
      }
    },
    accounts: {
      title: 'حسابات وقنوات الهيئة العامة الرسمية بالبصرة',
      desc: 'تواصل مع اللجان العلمية والممثليين الرسميين للهيئة العامة في البصرة عبر مختلف المنصات والقنوات الاجتماعية.',
      editBtn: 'تعديل روابط التواصل للادمن',
      modalTitle: 'لوحة التحكم في روابط قنوات الهيئة العامة بالبصرة',
      modalSub: 'يمكنك تعديل روابط قنوات الهيئة المتاحة للطلبة لرسم روابط جديدة بلمسة واحدة.',
      telegram: 'رابط قناة التلجرام الرسمية:',
      facebook: 'رابط صفحة الفيسبوك الرئيسي:',
      whatsapp: 'رابط خدمة الواتساب الفورية (رقم الهاتف):',
      youtube: 'رابط أكاديمية الهيئة باليوتيوب:',
      linkedin: 'رابط صفحة لينكدإن للمهندسين بالبصرة:',
      website: 'رابط الموقع الإلكتروني المرجعي الرسمي للهيئة:',
      saveBtn: 'حفظ التغييرات الجديدة وتعمِيمها للطلبة',
      saving: 'جاري تحديث الروابط بقاعدة البيانات...',
      cancelBtn: 'إلغاء',
      channelLabel: 'اضغط للذهاب للقناة الرسمية للهيئة &larr;',
      channels: [
        { name: 'قناة التلجرام الرسمية', desc: 'لنشر قرارات الهيئة والمصادر والمناقشات العلمية والطلابية اليومية.' },
        { name: 'بيج الفيسبوك الرئيسي', desc: 'التغطية الإعلامية للندوات والمحاضرات الهندسية المقامة بالبصرة.' },
        { name: 'أكاديمية الهيئة باليوتيوب', desc: 'بث المحاضرات وتفريغ حصص المعايرة الكيميائية وأجهزة HPLC الطيفية.' },
        { name: 'صفحة لينكدإن للمهندسين', desc: 'لتأمين فرص التوظيف والشراكات مع ممثلي شركات جولات التراخيص النفطية.' },
        { name: 'الموقع الإلكتروني الرسمي', desc: 'موقع الهيئة المرجعي لإصدار اللوائح والتعميدات والشهادات الكيميائية المصدقة.' }
      ]
    },
    about: {
      introTitle: 'التعريف والهيكل التنظيمي والريادي',
      title: 'عن الهيئة العامة للمهندسين الكيميائيين في البصرة',
      p1: 'تأسست الهيئة العامة للمهندسين الكيميائيين في البصرة ككيان تخصصي تنظيمي رائد يهدف لتأطير ودعم الطاقات الإبداعية لمهندسي الكيمياء وطلبة هندسة العمليات والصناعات الكيميائية والبتروكيميائية وتصفية الغاز في جنوب العراق المعطاء عاصمة الاقتصاد العراقي والخليجي.',
      p2: 'تسعى الهيئة من خلال منصاتها وبواباتها الرقمية ومختبرات المحاكاة وعمليات التدريب لتقليص الفجوة الميدانية بين الملاكات العلمية الناشئة ومتطلبات سوق العمل المحلي بالبصرة، لاسيما في شركات عقود التراخيص، مصافي تكرير النفط بالجنوب، ومعامل المذيبات والمنظفات والمستحضرات الكيميائية التخصصية.',
      cards: [
        { title: 'رؤيتنا الهندسية', desc: 'ابتكار أحدث مناهج وبرامج المحاكاة الهندسية لتأمين تدريب ذكي وتفاعلي في برامج التصميم للمهندسين الكيميائيين والطلبة بمخرجات جودة عالمية.' },
        { title: 'رسالتنا المجتمعية', desc: 'دعم الطلبة والخريجين وتوفير المراجع النادرة وكتب بيري لموازين المادة والمقالات الكيميائية مجاناً.' },
        { title: 'أهدافنا الاستراتيجية', desc: 'بناء شراكات مستدامة لتوفير فرص تدريبية في مصفى الشعيبة، معامل المنظفات، ومصانع الأسمدة المحلية ومحطات تحلية مياه البصرة.' }
      ],
      devBadge: 'مطور ومصمم المنصة التعليمية المتكاملة للهيئة',
      devName: 'ENG.ALI SAIF ALDIN HAIDER -AlNAWFAL @2026 LIMITED',
      devTitle: 'Full-Stack Software Analyst & AI Engineer',
      devDesc: 'تم تخطيط وبرمجة هذه المنصة التعليمية الرقمية المتقدمة للهيئة الكيميائية بالبصرة بصفة تطوعية ابتكارية لتمكين الطلبة، وتسهيل أدوات التحميل الفائق لملفات Perry البالغة أكثر من 400MB مع دمج أقوى مساعدي وأدوات جيميناي 3.5 لفرز المصطلحات الطبية والصناعية ودعم مقابلات التراخيص.',
      devContact: 'تطوير حلول برمجية ذكية لمهندسي البصرة',
      devStudio: 'ARABIC DEV STUDIO'
    },
    admin: {
      title: 'بيئة الإدارة ولوحة التحكم الشاملة للهيئة',
      desc: 'مراقبة وفحص أنشطة الطلبة والمستويات الأكاديمية والتحكم في منصات ومختبرات الهيئة بشكل كامل.',
      tabs: {
        tracking: 'سجل المراقبة والنشاطات كيميائياً',
        platforms: 'إدارة وتخصيص المنصات الفعالة'
      },
      searchUser: 'ابحث عن عضو بالإيميل أو الاسم للتأكد...',
      usersTitle: 'سجل مستخدمي وطلبة المنصة المسجلين بالموقع:',
      loading: 'جاري جمع وتحليل السجلات السحابية بالبصرة من قاعدة البيانات الفورية...',
      table: {
        name: 'اسم الطالب / العضو',
        email: 'البريد الإلكتروني',
        role: 'الصفة / الدور الممنوح',
        clicks: 'النقرات الكلية والنشاط',
        duration: 'إجمالي البقاء للتأهيل',
        btnDetail: 'عرض تفاصيل النشاط'
      },
      inspectTitle: 'مراقبة الملف والتحصيل الأكاديمي المفرد للعضو:',
      inspectSub: 'انقر على زر "تفاصيل" لأي طالب في الجدول لمراجعة مستشعرات البقاء والتفاعل الفوري لمرحلته الأكاديمية طردياً.',
      individual: {
        registered: 'تاريخ العضوية المعتمد:',
        clicksSum: 'إجمالي النقرات الفعالة بالصفحات',
        timeSum: 'زمن البقاء والتحصيل الطردي',
        staysTitle: 'ساعات البقاء والدخول للمنصات والمحاكيات الرقمية الفرعية',
        clicksCount: 'النقرات لتشغيل المحاكي:',
        noStays: 'لم يزر العضو أي من مختبرات المحاكاة الرقمية أو المنصات المدعومة حتى الآن.',
        timelineTitle: 'سجل النشاط الزمني المفصل ومسارات الطلب الفوري',
        noTimeline: 'لا توجد سجلات حالية للعضو المختار.'
      },
      managePlat: {
        addTitle: 'إضافة منصة رقمية أو مختبر جديد لموقع الهيئة العامة بالبصرة',
        editTitle: 'تعديل المنصة الرقمية المحددة بالاتحاد',
        formDesc: 'قم بتكييف وتخصيص وحفظ منصتك التعليمية الجديدة وتحديد الروابط وصورة الغلاف لتظهر فورا للطلبة بكل سلاسة.',
        platName: 'اسم المنصة أو المختبر العلمي الجديد:',
        platUrl: 'رابط المنصة أو اكتب embedded للمحتوى الداخلي الذكي:',
        platImg: 'رابط غلاف صورة المنصة التخصصي (أو اتركه فارغاً وسيتم إعطاء غلاف رائع):',
        platDesc: 'وصف موجز للمنصة وآليات تفعيلها وخوارزميات الاختبار للطلبة:',
        btnSubmitAdd: 'إدراج وتفعيل المنصة الرقمية الكيميائية',
        btnSubmitEdit: 'تأكيد وحفظ التغييرات الكبرى وتحديثها',
        btnCancel: 'إلغاء التعديل والصفحة',
        listTitle: 'قائمة المنصات الفعالة بموقع الهيئة الكيميائية',
        editTooltip: 'تعديل تخصصات المنصة الحالية',
        deleteTooltip: 'إبادة/حذف المنصة التعليمية نهائياً'
      }
    }
  },
  en: {
    dir: 'ltr',
    langName: 'English',
    appName: 'General Authority of Chemical Engineers in Basra',
    appSubName: 'Chemists in Basra',
    certifiedPlatform: 'Certified Platform for Basra Engineers',
    logout: 'Sign Out',
    login: 'Sign In',
    register: 'Create Account',
    adminPanel: 'Admin Dashboard',
    studentRole: 'Student',
    adminRole: 'Platform Admin',
    sections: {
      home: 'Main Dashboard',
      platforms: 'Digital Platforms & Labs',
      courses: 'Syllabus & Courses',
      resources: 'Engineering Resources',
      accounts: 'Official Channels',
      news: 'News & Activities',
      about: 'About & Developer',
      admin: 'Admin Center'
    },
    auth: {
      welcome: 'Welcome to the Comprehensive Portal',
      subtitle: 'Sign in as a graduate, student, or admin to access chemical engineering training classes and premium resources',
      email: 'Email address:',
      password: 'Password:',
      name: 'Full Name:',
      academicYear: 'Academic Year or Rank:',
      loginBtn: 'Sign In to Platform',
      registerBtn: 'Confirm & Register Account',
      hasAccount: 'I have an account (Login)',
      newAccount: 'Register New Account',
      testLogins: 'Quick test login accounts:',
      testAdmin: 'Admin account credentials:',
      testStudent: 'Demo student credentials:',
      adminRoleText: 'General Authority Admin',
      passwordtext: 'Password:',
      loading: 'Authorizing and verifying credentials...',
      agreeDetails: 'By registering, you agree to the terms and regulations of the Chemical Engineering Authority in Basra.',
      errorAllFields: 'Please formulate all registration criteria.',
      errorMissingCreds: 'Please enter both email address and password.',
      studentPhase1: 'Year 1 - Chemical Engineering',
      studentPhase2: 'Year 2 - Chemical Engineering',
      studentPhase3: 'Year 3 - Chemical Engineering',
      studentPhase4: 'Year 4 - Chemical Engineering',
      graduate: 'Chemical Engineering Graduate',
      practitioner: 'Practicing Engineer in Oil/Industrial Sector'
    },
    home: {
      title: 'General Authority of Chemical Engineers in Basra',
      subtitle: 'The ultimate academic educational portal empowering students and practicing engineers in Basra, southern Iraq. Advancing skills in Petroleum refining, gas processing, cosmetics science, and detergent manufacturing methodologies.',
      explorePlatforms: 'Explore Digital Playgrounds',
      whoAreWe: 'Who Are We?',
      stats: {
        labs: 'Simulators & Labs',
        labsUnit: 'Apps & Systems',
        courses: 'Available Courses',
        coursesUnit: 'Active Modules',
        resources: 'Academic Materials',
        resourcesUnit: 'Massive Reference Files',
        members: 'Registered Members',
        membersUnit: 'Active Engineers'
      },
      announcements: 'Announcements & News Board',
      news: [
        {
          title: 'Opening of Liquid Soap & Detergents Lab in Basra',
          date: '2 days ago',
          desc: 'The Authority calls upon all young chemists and members to participate in this hands-on workshop to master the science of surfactant blending and standardization.',
          tag: 'Practical Workshop'
        },
        {
          title: 'Ongoing Collaboration with Field Engineering Experts',
          date: '5 days ago',
          desc: 'Continuous collaboration with professional engineers working in various local and international oil fields.',
          tag: 'Global & Local'
        },
        {
          title: 'Paper Book Donation Drive for Basra Engineering Library',
          date: '1 week ago',
          desc: 'Senior professors are donating rare hardcopies of McCabe, Sinnott, and Perry handbooks to be scanned and uploaded as high-quality PDFs to our digital repository.',
          tag: 'Knowledge Sharing'
        }
      ],
      safety: 'EHS Engineering & Personal Safety Regulations',
      safetyText: 'The environmental health and safety committee asserts that reading safety pamphlets and wearing proper Personal Protective Equipment (PPE) is strictly required upon entry to physical labs.',
      safetyPoints: [
        'Wear premium chemical resistant coats and particulate masks.',
        'Always verify gas detector status and escape routes.',
        'Review Material Safety Data Sheet (MSDS) guidelines for every reagent.'
      ],
      visitLabs: 'Launch Virtual Chemistry Labs',
      thakerActivity: 'Quick Tool: Thaker Engineering Summarizer',
      thakerDesc: 'Take any massive chemical journal, process report, or book chapter and get structured AI insights, formulas, and terminology lists instantly.',
      openThaker: 'Open Thaker AI Summarizer'
    },
    platforms: {
      title: 'Digital Platforms & Interactive Simulators',
      subtitle: 'Select any digital tool or virtual laboratory below to enrich your process automation skills',
      searchPlat: 'Search interactive simulators...',
      integrated: 'AI Integrated',
      aiInteractive: 'AI INTERACTIVE',
      externalWeb: 'EXTERNAL WEB APP',
      enterSim: 'Launch Simulator',
      simulateBtn: 'Simulate Tool',
      externalBtn: 'External Link',
      backBtn: 'Back to Platform Listing',
      authorities: 'Basra Chemical Engineering Virtual Labs',
      statusOnline: 'COMMUNICATION STATUS: ONLINE',
      thaker: {
        badge: 'Intelligent Blazing Summarizer powered by Gemini 3.5',
        title: 'Paste Your Engineering Research Paper or report',
        desc: 'Leverage the Thaker summarizer to break down massive chemical design files, extract mass balance formulas, reaction constants, and process charts in seconds flat.',
        placeholder: 'Paste your chemical or mechanical engineering manuscript block here to get structured AI summarization...',
        limits: 'Recommended limits range from 100 to 10,000 words.',
        runBtn: 'Fulfill AI Summarization',
        running: 'Generating structured chapters, formulas, and insights...',
        resultsTitle: 'Extracted Engineering Insights',
        resultsPlaceholder: 'Input your textbook content on the left, then click the trigger to inspect detailed AI breakdowns.',
        poweredBy: 'Powered by Gemini 3.5 Flash server'
      },
      interview: {
        title: 'Chemical Engineering Workforce Interview Simulator',
        desc: 'Select your preferred professional direction. AI recruiters representing the Basra Chemical Engineering Authority will conduct an adaptive, realistic technical drill to prepare you for job hunts in global petroleum corporations.',
        topicLabel: 'Determine interview background topic:',
        topics: [
          'Petroleum refining processes, Southern Shuaiba Refinery, and Fractional Distillation Towers',
          'Natural gas processing, LNG liquefaction, and dry-gas purification (Basra Gas Company - BGC)',
          'Chemical synthesis and stabilization reaction of acidic surfactants in detergent labs',
          'Advanced Heat and Mass Transfer equations and industrial Unit Operations',
          'UV-Visible spectroscopic spectrophotometry, absorbance laws, and water sample analysis'
        ],
        btnStart: 'Start Technical Board Interview Now',
        activeTopic: 'Active Recruiter Board Subject:',
        instructionsTitle: '💡 Guidelines for Applicants:',
        instructions: [
          'Formulate your replies clearly. Feel free to use industrial English terminologies or Arabic equations.',
          'Always explain your mass balance assumptions; structural recruiters highly value detailed process parameters.'
        ],
        btnEnd: 'End Recruitment Session',
        chatHeader: 'Basra Recruitment Selection Committee:',
        chatUserHeader: 'Your response (Candidate):',
        chatPlaceholder: 'Formulate your technical answer here with structural clarity...',
        loading: 'The recruiters are evaluating your answer and drafting a tailored scientific question...'
      },
      bot: {
        title: 'Digital Assistant Scientific Chatbot',
        welcome: 'Greetings chemical engineer! I am your scientific digital assistant from the Basra Chemical Engineering Board. Ask me about Mass Balance equations, thermodynamic formulas, or chemical calibration workflows.',
        instructions: 'Consult the Authority Smart Assistant for instant formula definitions and equations',
        placeholder: 'Ask the bot: What is the molecular model of liquid soap? Or how do we compute heat flux?',
        loading: 'Interrogating scientific libraries to resolve your equation...'
      },
      detergents: {
        title: 'Chemical Detergent & Liquid Soap Blending Simulator',
        desc: 'Verify and model surfactant viscosity and formula stability according to Iraqi national quality indices.',
        solTitle: '1. Neutral Carrier Solvent:',
        waterSol: '💧 Deionized & Distilled pure Water Carrier (1 Litre)',
        acidTitle: '2. Select Active Component to Feed Reactor:',
        acids: [
          'Linear Alkylbenzene Sulfonic Acid (LABSA)',
          'Active Sodium Hydroxide (NaOH)',
          'Texapon Foam Booster'
        ],
        btnMix: 'Load Material & Feed Reactor',
        phStatus: 'Observed pH Index:',
        reactionOk: 'Reaction achieved successfully. Surfactants are fully stable, skin-safe, and ready for licensing.',
        logReady: 'Reactor idle. Ready for active component feed.',
        logNoAcid: 'Please select an active chemical surfactant to feed first.',
        logPour: 'Poured a calibrated quantity of active component into the neutral water bed.',
        logLabsa: 'pH value dropped to 3.2. Solution is strongly acidic! Neutralization with soda ash or sodium hydroxide is now required to form sodium sulfonate foam.',
        logNaohNeutral: 'Reaction achieved! Neutral acid-base reaction produced de-alkalized sodium sulfonate lather and water. pH finalized at 7.2 (Skin safe, optimized, and detergent ready). Blending cycle finished!',
        logNaohBase: 'pH value surged to 11.5! Solution is highly basic, caustic, and hazardous to skin. Neutralize gradually with LABSA acid.',
        logTexapon: 'Texapon foam booster added. Viscosity index is stabilized. Exceptional foaming qualities observed.'
      },
      uvVis: {
        title: 'UV-Visible Spectrophotometer Digital Simulator',
        desc: 'Measure spectroscopic absorbance values of organic solutes according to the Beer-Lambert opto-chemical law.',
        sampleLabel: '1. Load Solute Sample into Quartz Cuvette:',
        samples: [
          'Copper Sulfate (CuSO4) Solute',
          'Potassium Dichromate (K2Cr2O7) Solution',
          'Phenolphthalein Indicator & Reagent'
        ],
        waveLabel: '2. Calibrate Incident Light Wavelength (400nm - 800nm):',
        concLabel: '3. Formulate Solute Concentration Index (Molar):',
        btnMeasure: 'Transmit Wavelength & Read Absorbance',
        measuring: 'Transmitting monochromatic light beam... Reading Absorbance (A)...',
        results: 'Spectrophotometer Measured Parameters:',
        absText: 'Solute Measured Absorbance Value (A):',
        beerLawTitle: '📌 Beer-Lambert Analytical Valuation:',
        beerLawText: 'Applying A = ε * C * L. The spectrum verified highly stable molecular absorbance. Solute dispersion is in ideal agreement with standard environmental databases.',
        noAbs: 'Device uncalibrated. Load your cuvette and trigger the incident wavelength to observe absorption spectrum.'
      },
      hplc: {
        title: 'HPLC Simulator Laboratory',
        desc: 'An interactive chemical engineering simulator to understand the Standard Operating Procedures (SOP), pump programming, and chromatogram analysis of a High-Performance Liquid Chromatograph (HPLC) - based on the scientific content of Eng. Ali Saif Aldin Haider\'s course.'
      }
    },
    courses: {
      title: 'Training Syllabus & Professional Courses',
      desc: 'Expert-led technical modules organized by the training board to qualify students and fresh graduates in Basra.',
      search: 'Search coursework packages...',
      newCourseBtn: 'Add New Course',
      instructor: 'Instructor:',
      dateAdded: 'Date Uploaded:',
      accessBtn: 'Access Study Folder',
      noCourses: 'No matching training syllabus found.',
      addModal: {
        title: 'Add New Coursework Package to Repository',
        nameLabel: 'Course or Syllabus Title:',
        namePlaceholder: 'e.g., Natural Gas Cryogenic Treatment & Fractionation',
        urlLabel: 'Access URL for Training Materials:',
        urlPlaceholder: 'Syllabus, Google Drive reference, or YouTube series link',
        instructorLabel: 'Assigned Instructor Name:',
        instructorPlaceholder: 'Leave empty for official Basra Board representation',
        descLabel: 'Coursework Syllabus Overview:',
        descPlaceholder: 'Provide learning goals, course schedule, and chemical certifications covered',
        confirmBtn: 'Confirm & Deploy Course',
        cancelBtn: 'Cancel',
        errorFill: 'Syllabus title and active access URL are strictly required.'
      }
    },
    resources: {
      title: 'Structural Reference Literature (400MB+)',
      desc: 'Comprehensive digital library providing access to classical text-books, solved problems, and plant design manuals.',
      categories: ['All', 'Core Textbooks', 'Reactor & Plant Design', 'Oil & Gas Refining', 'Environmental & Water', 'Research Papers'],
      search: 'Search literature, author names, or Perry references...',
      newResourceBtn: 'Publish Reference Literature',
      fileSize: 'File Volume:',
      dateAdded: 'Date Uploaded:',
      downloadBtn: 'Retrieve PDF Document',
      noResources: 'No engineering textbooks match your active search.',
      addModal: {
        title: 'Publish Reference Document or PDF Literature',
        uploading: 'Uploading Massive Engineering Document File to Basra Cluster',
        uploadingDesc: 'Processing. Uploading substantial reference files (over 400MB) can take some seconds as we segment the file for reliable s3 transit.',
        speed: 'Upload Velocity:',
        approximate: 'Segment Transfer Status:',
        nameLabel: 'Literature Reference Title:',
        namePlaceholder: 'e.g., Perry Chemical Engineers Handbook - 9th Edition',
        catLabel: 'Textbook Academic Category:',
        sizeLabel: 'Estimated File Volume (Megabytes):',
        browseLabel: 'Browse PDF Document File from Drive',
        browseSub: 'Unbounded Volume: Admins can upload any file size (well over 400MB up to 1.5GB) with cloud chunking and no hard caps',
        driveLabel: 'Alternate Direct Download Link (Recommended for high speed):',
        drivePlaceholder: 'Google Drive, OneDrive, or Dropbox public link',
        descLabel: 'Document description & syllabus outline:',
        descPlaceholder: 'Provide table of contents, book author, publication date, and helpful chapter hints...',
        safetyText: 'Our upload manager reliably processes massive, heavy files (400MB+) via segmented parallel chunk arrays to secure seamless upload.',
        submitBtn: 'Fulfill File Allocation',
        cancelBtn: 'Cancel',
        errorFill: 'Reference title, file name, and estimated volume are strictly required.'
      }
    },
    accounts: {
      title: 'Official General Authority Channels (Basra)',
      desc: 'Connect with technical committees, student representatives, and official Basra directors.',
      editBtn: 'Manage Channel Links',
      modalTitle: 'Official Board Link Administration Portal',
      modalSub: 'Update destination links for our official communication endpoints easily.',
      telegram: 'Telegram Official Channel Link:',
      facebook: 'Facebook Main Community Page:',
      whatsapp: 'WhatsApp Support Service (Telephone):',
      youtube: 'YouTube Streaming Academy Channel:',
      linkedin: 'LinkedIn Corporate Engineers Link:',
      website: 'Official Authority Main Website URL:',
      saveBtn: 'Authorize Links Update & Broadcast',
      saving: 'Updating remote channel database fields...',
      cancelBtn: 'Cancel',
      channelLabel: 'Navigate to Official Channel &larr;',
      channels: [
        { name: 'Official Telegram Channel', desc: 'Used for immediate announcements, book distributions, and educational notices.' },
        { name: 'Facebook Community Hub', desc: 'Covers media press, conferences, and technical workshops held at Basra HQ.' },
        { name: 'YouTube Video Academy', desc: 'Hosting recorded lectures, chemical equipment calibration sessions, and HPLC tutorials.' },
        { name: 'LinkedIn Professional Desk', desc: 'Linking senior members and fresh graduates directly with hiring managers in oil fields.' },
        { name: 'Official Web Domain', desc: 'The reference desk of the Authority for certificates validation and official circulars.' }
      ]
    },
    about: {
      introTitle: 'Organizational & Strategic Charter',
      title: 'Chemical Engineering Authority (Basra)',
      p1: 'The General Authority of Chemical Engineers in Basra stands as a premium technical institution. We represent chemical engineers, process technology practitioners, and gas refining professionals across Basra Governorate, the economic capital of Iraq.',
      p2: 'The charter of the Authority is to bridge the gap between fresh academic outputs and active industrial parameters. We build virtual labs, organize local workshops, and partner with regional oil refineries to create qualified, safety-aware process operators.',
      cards: [
        { title: 'Corporate Vision', desc: 'Model state-of-the-art interactive labs and automation syllabus to train chemical specialists according to international standards.' },
        { title: 'Knowledge Mission', desc: 'Provide free, premium access to classical reference handbooks (Sinnott, Perry, McCabe) and analytical software workflows for all students.' },
        { title: 'Strategic Goals', desc: 'Structure close bonds with Southern Refineries (Shuaiba), Basra Gas Company, and domestic fertilizer plants to enhance internship placement arrays.' }
      ],
      devBadge: 'Educational Platform Developer & Systems Architect',
      devName: 'ENG.ALI SAIF ALDIN HAIDER -AlNAWFAL @2026 LIMITED',
      devTitle: 'Full-Stack Software Analyst & AI Engineer',
      devDesc: 'This educational platform was built on a volunteer basis to support young chemical engineers in Iraq. Featuring parallel segment uploading mechanics to easily download huge +400MB PDF books, and hosting state-of-the-art Gemini 3.5 AI APIs to facilitate resume formatting, terminology filtering, and test interview runs.',
      devContact: 'Developing intelligent systems for Basra chemical community',
      devStudio: 'ARABIC DEV STUDIO'
    },
    admin: {
      title: 'Basra Authority Operations Control Dashboard',
      desc: 'Observe user active timelines, analyze learning analytics, and manage active chemistry modules.',
      tabs: {
        tracking: 'Student Learning Analytics',
        platforms: 'Syllabus Modules Control'
      },
      searchUser: 'Search member lists by name or email account...',
      usersTitle: 'Registered Student & Practitioner Registry:',
      loading: 'Compiling real-time tracking metrics and audit databases from the server...',
      table: {
        name: 'Member/Student Item',
        email: 'Registered Email Address',
        role: 'Assigned Role',
        clicks: 'Interactions',
        duration: 'Time Spent Studying',
        btnDetail: 'Review Analytics Profile'
      },
      inspectTitle: 'Individual Learning Analytics Feed:',
      inspectSub: 'Select the profile button for any member on the left to analyze real-time platform stays, action logs, and exact study hours.',
      individual: {
        registered: 'Account Creation Date:',
        clicksSum: 'Total Action Clicks',
        timeSum: 'Aggregate Time Studying',
        staysTitle: 'Time Spent In Chemistry Syms & Labs',
        clicksCount: 'Sim Launch Cycles:',
        noStays: 'This member has not accessed virtual labs or simulators yet.',
        timelineTitle: 'Detailed Learning Action Timeline',
        noTimeline: 'No active timelines reported for selected member.'
      },
      managePlat: {
        addTitle: 'Deploy Brand-New Digital Platform Module',
        editTitle: 'Modify Active Platform Criteria',
        formDesc: 'Add or modify any simulator to the active student dashboard by defining its name, custom cover photo, and entry route parameters.',
        platName: 'Simulator/Platform Scientific Name:',
        platUrl: 'Route Endpoint (External Link or keyword embedded):',
        platImg: 'Platform Cover Image URL (or leave empty for default cover):',
        platDesc: 'Brief Description & target learnings:',
        btnSubmitAdd: 'Deploy Platform Module',
        btnSubmitEdit: 'Confirm & Update Module Criteria',
        btnCancel: 'Cancel Modifications',
        listTitle: 'Live Modules on Student Dashboard',
        editTooltip: 'Modify design criteria',
        deleteTooltip: 'Destroy module from database'
      }
    }
  },
  de: {
    dir: 'ltr',
    langName: 'Deutsch',
    appName: 'Chemische Ingenieurbehörde in Basra',
    appSubName: 'Chemiker in Basra',
    certifiedPlatform: 'Zertifizierte Plattform für Basra-Ingenieure',
    logout: 'Abmelden',
    login: 'Anmelden',
    register: 'Konto erstellen',
    adminPanel: 'Admin-Zentrum',
    studentRole: 'Student',
    adminRole: 'Plattform-Admin',
    sections: {
      home: 'Haupt-Dashboard',
      platforms: 'Plattformen & Labore',
      courses: 'Lehrpläne & Kurse',
      resources: 'Literatur & Quellen',
      accounts: 'Offizielle Kanäle',
      news: 'News & Aktivitäten',
      about: 'Über uns & Entwickler',
      admin: 'Admin-Zentrum'
    },
    auth: {
      welcome: 'Willkommen beim Schulungsportal',
      subtitle: 'Melden Sie sich als Absolvent, Student oder Administrator an, um auf Kurse und Literatur zuzugreifen',
      email: 'E-Mail-Adresse:',
      password: 'Passwort:',
      name: 'Vollständiger Name:',
      academicYear: 'Akademisches Jahr oder Rang:',
      loginBtn: 'Anmelden',
      registerBtn: 'Registrieren',
      hasAccount: 'Ich habe ein Konto (Login)',
      newAccount: 'Neues Konto erstellen',
      testLogins: 'Schnelltests für Konten:',
      testAdmin: 'Admin-Konto:',
      testStudent: 'Studenten-Konto:',
      adminRoleText: 'Behörden-Administrator',
      passwordtext: 'Passwort:',
      loading: 'Anmeldedaten werden überprüft...',
      agreeDetails: 'Mit der Registrierung stimmen Sie den Bedingungen der chemischen Ingenieurbehörde in Basra zu.',
      errorAllFields: 'Bitte füllen Sie alle Registrierungsfelder aus.',
      errorMissingCreds: 'Bitte geben Sie E-Mail und Passwort ein.',
      studentPhase1: 'Jahr 1 - Chemieingenieurwesen',
      studentPhase2: 'Jahr 2 - Chemieingenieurwesen',
      studentPhase3: 'Jahr 3 - Chemieingenieurwesen',
      studentPhase4: 'Jahr 4 - Chemieingenieurwesen',
      graduate: 'Absolvent Chemieingenieurwesen',
      practitioner: 'Praktizierender Ingenieur im Öl-/Industriesektor'
    },
    home: {
      title: 'Allgemeine Behörde für Chemieingenieure in Basra',
      subtitle: 'Das umfassende Schulungsportal für Studenten und Ingenieure in Basra, Süd-Irak. Förderung von Kompetenzen in Erdölraffination, Gasverarbeitung, Kosmetikwissenschaften und Waschmittelherstellung.',
      explorePlatforms: 'Plattformen erkunden',
      whoAreWe: 'Über uns',
      stats: {
        labs: 'Simulatoren & Labore',
        labsUnit: 'Anwendungen',
        courses: 'Verfügbare Kurse',
        coursesUnit: 'Module',
        resources: 'Literatur & Fachbücher',
        resourcesUnit: 'Massive Dokumente',
        members: 'Registrierte Mitglieder',
        membersUnit: 'Ingenieure'
      },
      announcements: 'Ankündigungen & Neuigkeiten',
      news: [
        {
          title: 'Eröffnung des Waschmittel-Labors in Basra',
          date: 'vor 2 Tagen',
          desc: 'Die Behörde lädt alle jungen Chemiker ein, theoretisches und praktisches Wissen über Tensidformulierung und Sicherheitsstandards zu erwerben.',
          tag: 'Praktischer Workshop'
        },
        {
          title: 'Fortlaufende Kooperation mit Ölfeld-Ingenieuren',
          date: 'vor 5 Tagen',
          desc: 'Kontinuierliche Zusammenarbeit mit professionellen Ingenieuren in verschiedenen lokalen und internationalen Ölfeldern.',
          tag: 'Kollaboration'
        },
        {
          title: 'Buchspendenaktion für die Basra-Bibliothek',
          date: 'vor 1 Woche',
          desc: 'Professoren spenden wertvolle Fachbücher (McCabe, Sinnott, Perry), um sie als hochwertige PDFs für Studenten bereitzustellen.',
          tag: 'Wissen teilen'
        }
      ],
      safety: 'EHS-Vorschriften & Arbeitsschutz',
      safetyText: 'Die EHS-Kommission weist darauf hin, dass das Tragen von persönlicher Schutzausrüstung (PSA) und das Lesen der Richtlinien beim Betreten realer Labore zwingend erforderlich sind.',
      safetyPoints: [
        'Laborkittel und Atemschutzmasken tragen.',
        'Gasdetektoren und Notausgänge überprüfen.',
        'Sicherheitsdatenblätter (MSDS) jedes Reagenz lesen.'
      ],
      visitLabs: 'Virtuelle Labore öffnen',
      thakerActivity: 'KI-Tool: Thaker Fachbericht-Zusammenfasser',
      thakerDesc: 'Fügen Sie umfangreiche chemische Arbeiten oder Berichte ein und erhalten Sie sofort strukturierte Zusammenfassungen und Fachbegriffe.',
      openThaker: 'Thaker Zusammenfassung öffnen'
    },
    platforms: {
      title: 'Digitale Plattformen & Simulatoren',
      subtitle: 'Wählen Sie ein Werkzeug oder ein virtuelles Labor aus, um mit dem Lernen zu beginnen',
      searchPlat: 'Nach Simulatoren suchen...',
      integrated: 'KI-Integriert',
      aiInteractive: 'KI INTERAKTIV',
      externalWeb: 'EXTERNE APP',
      enterSim: 'Simulator starten',
      simulateBtn: 'Simulieren',
      externalBtn: 'Externer Link',
      backBtn: 'Zurück zur Übersicht',
      authorities: 'Virtuelle Labore von Basra',
      statusOnline: 'KOMMUNIKATIONSSTATUS: ONLINE',
      thaker: {
        badge: 'Intelligenter Zusammenfasser powered by Gemini 3.5',
        title: 'Fügen Sie Ihren Text oder Ihre wissenschaftliche Arbeit ein',
        desc: 'Verwenden Sie Thaker, um Formeln, Stoffbilanzen und Laborberichte in Sekundenschnelle strukturiert aufzubereiten.',
        placeholder: 'Fügen Sie Ihren englischen oder arabischen Fachtext hier ein, um eine KI-Zusammenfassung zu erhalten...',
        limits: 'Empfohlen: 100 bis 10.000 Wörter.',
        runBtn: 'Zusammenfassung starten',
        running: 'Inhalte, Formeln und Schlüsselbegriffe werden extrahiert...',
        resultsTitle: 'Strukturierte extrahierte Einblicke',
        resultsPlaceholder: 'Fügen Sie Text links ein und klicken Sie auf Starten, um Analyseergebnisse anzuzeigen.',
        poweredBy: 'Aktiviert über Gemini 3.5 Flash s3'
      },
      interview: {
        title: 'Recruiting-Simulator für Chemieingenieure',
        desc: 'Simulieren Sie ein fachliches Bewerbungsgespräch mit einem virtuellen Komitee für die regionalen und internationalen Ölgesellschaften im Irak.',
        topicLabel: 'Thema des Vorstellungsgesprächs wählen:',
        topics: [
          'Erdölraffination, Shuaiba-Raffinerie und Rektifikationskolonnen',
          'Erdgasaufbereitung, LNG und Reinigung (Basra Gas Company - BGC)',
          'Waschmittelchemie, Formulierung und Stabilisierung von Tensiden',
          'Erweiterte Wärme- und Stoffübertragung (Unit Operations)',
          'UV-Vis-Spektrophotometrie, Absorptionsgesetze und Wasseranalyse'
        ],
        btnStart: 'Interview starten',
        activeTopic: 'Aktives Thema:',
        instructionsTitle: '💡 Richtlinien für Bewerber:',
        instructions: [
          'Formulieren Sie Fachbegriffe präzise in Englisch oder Deutsch.',
          'Erklären Sie Stoffbilanzen im Detail; Recruiter schätzen fundierte Parameter.'
        ],
        btnEnd: 'Gespräch beenden',
        chatHeader: 'Bewerbungskomitee Basra:',
        chatUserHeader: 'Ihre Antwort (Bewerber):',
        chatPlaceholder: 'Schreiben Sie Ihre präzise Antwort hier...',
        loading: 'Komitee analysiert Ihre Antwort und formuliert das nächste Fachthema...'
      },
      bot: {
        title: 'Wissenschaftlicher KI-Assistent',
        welcome: 'Hallo! Ich bin der KI-Assistent der Chemieingenieurbehörde in Basra. Fragen Sie mich nach Stoffbilanzen, Thermodynamik oder chemischer Analyse.',
        instructions: 'Fragen Sie den KI-Assistenten nach Formeln und thermodynamischen Prozessen',
        placeholder: 'Frage stellen: Wie lautet die chemische Formulierung für Seife? Wie berechnet man den Wärmestrom?',
        loading: 'Bibliotheken werden nach Gleichungen durchsucht...'
      },
      detergents: {
        title: 'Produktions-Simulator für Tenside und Seifen',
        desc: 'Testen und modellieren Sie Tensidmischungen und kontrollieren Sie den pH-Wert nach Industriestandards.',
        solTitle: '1. Neutrales Lösungsmittel:',
        waterSol: '💧 Reinstwasser (1 Liter)',
        acidTitle: '2. Aktive Substanz in den Reaktor einspeisen:',
        acids: [
          'Alkylbenzolsulfonsäure (LABSA)',
          'Natriumhydroxid (NaOH)',
          'Texapon Schaumbooster'
        ],
        btnMix: 'Substanz einfüllen',
        phStatus: 'Gemessener pH-Wert:',
        reactionOk: 'Reaktion erfolgreich abgeschlossen. Formulierung ist stabil und hautfreundlich.',
        logReady: 'Reaktor bereit zur Befüllung.',
        logNoAcid: 'Bitte wählen Sie zuerst eine aktive Substanz aus.',
        logPour: 'Eine abgemessene Menge der Substanz wurde in den Reaktor gegeben.',
        logLabsa: 'pH-Wert auf 3.2 gesunken (sauer). Eine Neutralisation ist erforderlich, um stabiles Natriumsulfonat zu bilden.',
        logNaohNeutral: 'Säure-Basen-Neutralisationsreaktion erfolgreich abgeschlossen! pH-Wert liegt bei idealen 7.2. Blasenfreie Synthese beendet!',
        logNaohBase: 'pH-Wert auf 11.5 gestiegen (hochbasisch). Reizend und schädlich für die Haut. Mit LABSA korrigieren.',
        logTexapon: 'Texapon (Schaumstabilisator) hinzugefügt. Viskosität erhöht, ausgezeichnete Schaumbildung beobachtet.'
      },
      uvVis: {
        title: 'UV-Vis-Spektrophotometer-Simulator',
        desc: 'Messen Sie die Lichtabsorption flüssiger Proben nach dem Lambert-Beerschen Gesetz für qualitative Analysen.',
        sampleLabel: '1. Probe in die Quarzküvette füllen:',
        samples: [
          'Kupfersulfat-Lösung (CuSO4)',
          'Kaliumdichromat (K2Cr2O7)',
          'Phenolphthalein-Indikator'
        ],
        waveLabel: '2. Wellenlänge kalibrieren (400nm - 800nm):',
        concLabel: '3. Konzentration einstellen (Molar):',
        btnMeasure: 'Lichtimpuls senden & Absorption messen',
        measuring: 'Monochromatischer Lichtstrahl wird gesendet... Absorption (A) wird ermittelt...',
        results: 'Analysedaten UV-Vis-Spektrometer:',
        absText: 'Gemessene Absorption (A):',
        beerLawTitle: '📌 Lambert-Beersche Analyse:',
        beerLawText: 'Werte stabil. Absorption entspricht der gewählten Konzentration. Ideal für hydrochemische Spezifikationsmodelle.',
        noAbs: 'Gerät inaktiv. Probe einlegen und Wellenlänge starten, um eine Messung durchzuführen.'
      },
      hplc: {
        title: 'HPLC-Simulator-Labor',
        desc: 'Ein interaktiver Simulator der chemischen Verfahrenstechnik zum Verständnis der Standardarbeitsanweisungen (SOP), der Pumpenprogrammierung und der Chromatogrammanalyse eines Hochleistungs-Flüssigkeitschromatographen (HPLC) - basierend auf den wissenschaftlichen Inhalten des Kurses von Eng. Ali Saif Aldin Haider.'
      }
    },
    courses: {
      title: 'Ausbildungsprogramme & Fortbildungen',
      desc: 'Spezialisierte Fachmodule zur Förderung junger Absolventen der Verfahrenstechnik.',
      search: 'Nach Lehrgängen suchen...',
      newCourseBtn: 'Kurs hinzufügen',
      instructor: 'Dozent:',
      dateAdded: 'Erstellt am:',
      accessBtn: 'Dokumente öffnen',
      noCourses: 'Keine passenden Qualifizierungsangebote gefunden.',
      addModal: {
        title: 'Neuen Lehrgang zum System hinzufügen',
        nameLabel: 'Titel des Kurses:',
        namePlaceholder: 'z.B. Kryogene Erdgasverarbeitung & Kryoverfahren',
        urlLabel: 'Link zu Lernmaterialien:',
        urlPlaceholder: 'Syllabus, Google Drive oder Playlist-Link',
        instructorLabel: 'Dozentenname:',
        instructorPlaceholder: 'Leer lassen für Vertretung durch die Behörde',
        descLabel: 'Kurzbeschreibung und Ziele:',
        descPlaceholder: 'Geben Sie Module, Voraussetzungen und Prüfungsdetails an',
        confirmBtn: 'Kurs veröffentlichen',
        cancelBtn: 'Abbrechen',
        errorFill: 'Titel und Download-Link sind erforderlich.'
      }
    },
    resources: {
      title: 'Wissenschaftliches Literaturarchiv (+400MB)',
      desc: 'Umfangreiche Bibliothek für Fachliteratur, Regelwerke und anspruchsvolle Handbücher.',
      categories: ['All', 'Core Textbooks', 'Reactor & Plant Design', 'Oil & Gas Refining', 'Environmental & Water', 'Research Papers'],
      search: 'Literatur, Autoren oder Perry-Handbücher durchsuchen...',
      newResourceBtn: 'Literatur hinzufügen',
      fileSize: 'Dateigröße:',
      dateAdded: 'Erstellt am:',
      downloadBtn: 'PDF herunterladen',
      noResources: 'Keine Fachbücher gefunden, die der Suche entsprechen.',
      addModal: {
        title: 'Fachbuch oder PDF-Dokument hinzufügen',
        uploading: 'Großes Dokument wird in den Basra-Speicher geladen',
        uploadingDesc: 'Verarbeitung läuft. Dateien über 400MB werden segmentiert übertragen, um Verbindungsabbrüche zu vermeiden.',
        speed: 'Upload-Geschwindigkeit:',
        approximate: 'Übertragungsstatus:',
        nameLabel: 'Titel des Fachbuchs:',
        namePlaceholder: 'z.B. Perry\'s Chemical Engineers\' Handbook',
        catLabel: 'Kategorie:',
        sizeLabel: 'Ungefähre Größe (Megabytes):',
        browseLabel: 'PDF ausführen',
        browseSub: 'Keine Obergrenzen: Admins können beliebige Dateigrößen (über 400 MB) sicher übertragen',
        driveLabel: 'Alternativer Download-Link (Schneller):',
        drivePlaceholder: 'Google Drive, OneDrive oder Dropbox-Link',
        descLabel: 'Zusammenfassung & Kapitelübersicht:',
        descPlaceholder: 'Fügen Sie Inhaltsverzeichnisse und Autorennotizen hinzu...',
        safetyText: 'Unser System segmentiert Dateien über 400MB automatisch, um einen reibungslosen Upload zu gewährleisten.',
        submitBtn: 'Dokumente hinzufügen',
        cancelBtn: 'Abbrechen',
        errorFill: 'Titel, Dateiname und geschätztes Volumen sind erforderlich.'
      }
    },
    accounts: {
      title: 'Offizielle Kontaktkanäle der Behörde',
      desc: 'Vernetzen Sie sich mit Fachausschüssen und Vertretern der Behörde.',
      editBtn: 'Links bearbeiten',
      modalTitle: 'Verwaltung der Kontakt- und Kanallinks',
      modalSub: 'Bearbeiten Sie Ziel-Links für Informationsangebote von Studenten.',
      telegram: 'Telegram-Zieladresse:',
      facebook: 'Facebook-Präsenz:',
      whatsapp: 'WhatsApp Support-Nummer:',
      youtube: 'YouTube Streaming-Kanal:',
      linkedin: 'LinkedIn Karriere-Plattform:',
      website: 'Offizielle Homepage-URL:',
      saveBtn: 'Änderungen speichern',
      saving: 'Laden...',
      cancelBtn: 'Abbrechen',
      channelLabel: 'Kanal öffnen &larr;',
      channels: [
        { name: 'Offizielles Telegram', desc: 'Schnelle Ankündigungen, Buchempfehlungen und Ankündigungen.' },
        { name: 'Facebook Community', desc: 'Besprechungsberichte und Ankündigungen vor Ort in Basra.' },
        { name: 'YouTube Video-Akademie', desc: 'Vorlesungsaufzeichnungen und HPLC-Geräte-Tutorials.' },
        { name: 'LinkedIn Berufskanal', desc: 'Netzwerkbetrieb mit Experten in den irakischen Ölfeldern.' },
        { name: 'Offizielle Web-Domain', desc: 'Authentizitätsprüfung von Qualifikationsnachweisen.' }
      ]
    },
    about: {
      introTitle: 'Hintergrund & Leitbild der Behörde',
      title: 'Chemieingenieurwesen Basra',
      p1: 'Die Allgemeine Behörde für Chemieingenieure in Basra ist eine professionelle Institution, die Spezialisten der erdölnahen Verfahrenstechnik im Südirak vertritt.',
      p2: 'Wir minimieren die Kluft zwischen theoretischer Ausbildung und industrieller Realität durch virtuelle Labore und exklusive Fortbildungsprogramme mit führenden Technikern.',
      cards: [
        { title: 'Unsere Vision', desc: 'Implementierung fortschrittlicher Simulationsmethoden zur fachlichen Qualifizierung nach globalen Qualitätsindikatoren.' },
        { title: 'Unsere Mission', desc: 'Zielgerichtete Förderung des Ingenieurnachwuchses durch kostenfreien Zugang zu wichtiger Primärliteratur.' },
        { title: 'Strategische Ziele', desc: 'Kooperationen mit Raffinerien (Shuaiba), Düngemittelherstellern und Kläranlagen der Küstenregion.' }
      ],
      devBadge: 'Lehrplattform Entwickler & Systemarchitekt',
      devName: 'ENG.ALI SAIF ALDIN HAIDER -AlNAWFAL @2026 LIMITED',
      devTitle: 'Full-Stack Software Analyst & KI-Entwickler',
      devDesc: 'Diese Lernplattform wurde ehrenamtlich entwickelt, um junge Chemieingenieure im Irak zu unterstützen. Sie bietet optimierten Download von über 400 MB großen Perry-Lehrbüchern und integriert Gemini 3.5-KI-Schnittstellen für Bewerbungstrainings und Fachbegriffssynthesen.',
      devContact: 'Softwarelösungen für Fortbildung im Irak',
      devStudio: 'ARABIC DEV STUDIO'
    },
    admin: {
      title: 'Systemüberwachung & Administrations-Dashboard',
      desc: 'Analysieren Sie Studienzeiten, Interaktionen und verwalten Sie Kursmodule im irakischen Portal.',
      tabs: {
        tracking: 'Studienaktivitäten & Zeiterfassung',
        platforms: 'Dashboard-Module konfigurieren'
      },
      searchUser: 'Registrierte Mitglieder suchen...',
      usersTitle: 'Benutzer- und Studierendenverzeichnis:',
      loading: 'Sitzungsverläufe und Analysen werden geladen...',
      table: {
        name: 'Mitglied',
        email: 'Registrierte E-Mail',
        role: 'Rolle',
        clicks: 'Interaktivität',
        duration: 'Studienstunden',
        btnDetail: 'Analyse anzeigen'
      },
      inspectTitle: 'Detailliertes Benutzerprofil (Lernzeit):',
      inspectSub: 'Klicken Sie auf "Details", um genaue Analysen einzusehen.',
      individual: {
        registered: 'Mitglied seit:',
        clicksSum: 'Interaktionen im System',
        timeSum: 'Aktive Studienzeit',
        staysTitle: 'Zeit in Simulationslaboren',
        clicksCount: 'Sim-Aufrufe:',
        noStays: 'Dieses Mitglied hat bisher keine Laborsimulatoren gestartet.',
        timelineTitle: 'Ereignisprotokoll des Benutzers',
        noTimeline: 'Keine Aktivitäten protokolliert.'
      },
      managePlat: {
        addTitle: 'Neuen Simulator hinzufügen',
        editTitle: 'Simulatordaten konfigurieren',
        formDesc: 'Simulator für Studierende bereitstellen, indem Sie ID, URL und einen passenden Screenshot hinterlegen.',
        platName: 'Bezeichnung des Simulators:',
        platUrl: 'Route / Ziel-URL (oder "embedded" eintragen):',
        platImg: 'Screenshot-Bildlink (oder leer lassen):',
        platDesc: 'Lernziele & Kurzbeschreibung:',
        btnSubmitAdd: 'Simulator bereitstellen',
        btnSubmitEdit: 'Daten aktualisieren',
        btnCancel: 'Abbrechen',
        listTitle: 'Aktive Module auf der Lernplattform',
        editTooltip: 'Konfiguration bearbeiten',
        deleteTooltip: 'Modul entfernen'
      }
    }
  },
  es: {
    dir: 'ltr',
    langName: 'Español',
    appName: 'Autoridad General de Ingenieros Químicos en Basora',
    appSubName: 'Químicos en Basora',
    certifiedPlatform: 'Plataforma Certificada para Ingenieros de Basora',
    logout: 'Cerrar Sesión',
    login: 'Iniciar Sesión',
    register: 'Crear Cuenta',
    adminPanel: 'Panel de Control',
    studentRole: 'Estudiante',
    adminRole: 'Administrador',
    sections: {
      home: 'Inicio',
      platforms: 'Laboratorios Digitales',
      courses: 'Cursos & Talleres',
      resources: 'Recursos Científicos',
      accounts: 'Canales Oficiales',
      news: 'Noticias y Actividades',
      about: 'Nosotros & Autor',
      admin: 'Administración'
    },
    auth: {
      welcome: 'Bienvenido al Portal Educativo',
      subtitle: 'Inicie sesión como graduado, estudiante o administrador para acceder a clases de capacitación y recursos premium',
      email: 'Correo electrónico:',
      password: 'Contraseña:',
      name: 'Nombre Completo:',
      academicYear: 'Año Académico o Categoría:',
      loginBtn: 'Ingresar al Portal',
      registerBtn: 'Confirmar y Crear Cuenta',
      hasAccount: 'Tengo una cuenta (Login)',
      newAccount: 'Registrar nueva cuenta',
      testLogins: 'Cuentas de prueba rápida:',
      testAdmin: 'Cuenta de Administrador:',
      testStudent: 'Cuenta de Estudiante demo:',
      adminRoleText: 'Administrador de la Autoridad',
      passwordtext: 'Contraseña:',
      loading: 'Verificando credenciales de acceso...',
      agreeDetails: 'Al registrarse, acepta los términos y reglamentos de la Autoridad de Ingeniería Química de Basora.',
      errorAllFields: 'Por favor complete todos los datos requeridos.',
      errorMissingCreds: 'Por favor ingrese su correo y contraseña.',
      studentPhase1: 'Año 1 - Ingeniería Química',
      studentPhase2: 'Año 2 - Ingeniería Química',
      studentPhase3: 'Año 3 - Ingeniería Química',
      studentPhase4: 'Año 4 - Ingeniería Química',
      graduate: 'Graduado en Ingeniería Química',
      practitioner: 'Ingeniero en sector petrolero/industrial'
    },
    home: {
      title: 'Autoridad General de Ingenieros Químicos en Basora',
      subtitle: 'El portal académico para ingenieros y estudiantes en Basora, Irak. Desarrollando capacidades en refinación de petróleo, licuefacción planetaria, cosmética cuántica y metodologías experimentales de detergentes.',
      explorePlatforms: 'Explorar Simuladores',
      whoAreWe: '¿Quiénes Somos?',
      stats: {
        labs: 'Laboratorios & Simulación',
        labsUnit: 'Plataformas',
        courses: 'Cursos Técnicos',
        coursesUnit: 'Módulos Activos',
        resources: 'Bibliografía del Campo',
        resourcesUnit: 'Documentos Pesados',
        members: 'Miembros Registrados',
        membersUnit: 'Profesionales'
      },
      announcements: 'Tablón de Anuncios y Noticias',
      news: [
        {
          title: 'Apertura del Taller de Detergentes Líquidos en Basora',
          date: 'hace 2 días',
          desc: 'La junta directiva de la Autoridad invita a los estudiantes a masterizar la tecnología de agentes tensoactivos y estándares nacionales.',
          tag: 'Taller Práctico'
        },
        {
          title: 'Colaboración Continua con Expertos e Ingenieros de Campo',
          date: 'hace 5 días',
          desc: 'Colaboración constante con ingenieros profesionales que trabajan en diversos campos petroleros locales e internacionales.',
          tag: 'Colaboración'
        },
        {
          title: 'Campaña de Donación de Libros para la Biblioteca de Basora',
          date: 'hace 1 semana',
          desc: 'Profesores donan copias raras físicas de McCabe y Perry para digitalizar en PDFs de alta calidad para estudiantes.',
          tag: 'Compartir Conocimiento'
        }
      ],
      safety: 'Regulaciones de Seguridad Industrial y Medio Ambiente',
      safetyText: 'La comisión de salud y seguridad ambiental afirma que vestir Equipo de Protección Personal (EPP) es obligatorio para entrar a los laboratorios.',
      safetyPoints: [
        'Vestir batas de laboratorio y mascarillas con respirador.',
        'Verificar extintores, extractores y salidas de evacuación.',
        'Revisar las hojas de datos de seguridad (MSDS) para cada reactivo.'
      ],
      visitLabs: 'Clonar Lab Virtual',
      thakerActivity: 'Herramienta: Resumidor Inteligente Thaker',
      thakerDesc: 'Coloque cualquier manual extenso o reporte orgánico para extraer interpretaciones clave de ecuaciones y conceptos.',
      openThaker: 'Abrir Resumidor Thaker'
    },
    platforms: {
      title: 'Plataformas Científicas & Simuladores',
      subtitle: 'Seleccione un módulo interactivo para potenciar sus capacidades experimentales',
      searchPlat: 'Buscar simuladores...',
      integrated: 'Conectado a IA',
      aiInteractive: 'INTERACTIVO CON IA',
      externalWeb: 'ENLACE EXTERNO',
      enterSim: 'Iniciar Simulación',
      simulateBtn: 'Simular',
      externalBtn: 'Enlace Web',
      backBtn: 'Regresar a la Lista',
      authorities: 'Laboratorios Virtuales de Basora',
      statusOnline: 'CONEXIÓN: ONLINE',
      thaker: {
        badge: 'Resumidor avanzado con soporte de Gemini 3.5',
        title: 'Pegue su Reporte Científico o Tesis',
        desc: 'Permite procesar extensas secuencias y balances de masa para identificar ecuaciones de transferencia térmica.',
        placeholder: 'Pegue su texto científico aquí para estructurar un resumen analítico con la IA...',
        limits: 'Recomendado: 100 a 10,000 palabras.',
        runBtn: 'Ejecutar Procesamiento',
        running: 'Extrayendo fórmulas, constantes y variables termodinámicas...',
        resultsTitle: 'Resultados e Interpretaciones Clave',
        resultsPlaceholder: 'Pegue texto en la izquierda y clique en Ejecutar para observar los balances simplificados.',
        poweredBy: 'Servidor s3 implementado en Gemini 3.5 Flash'
      },
      interview: {
        title: 'Simulador de Entrevistas para Ingenieros',
        desc: 'Interactúe con un jurado virtual basado en IA que simula procesos reales de selección laboral en consorcios petroleros.',
        topicLabel: 'Seleccione dirección técnica de reclutamiento:',
        topics: [
          'Ecuaciones de Refinación de Petróleo y Torres de Destilación',
          'Licuefacción y Tratamiento de Gas Natural (Basra Gas Company - BGC)',
          'Sintetización química y balance de tensoactivos en detergentes',
          'Transmisión de calor y masa en operaciones unitarias de planta',
          'Espectrofotometría UV-Vis, Ley de Beer-Lambert y análisis de aguas'
        ],
        btnStart: 'Iniciar Entrevista de Evaluación',
        activeTopic: 'Área Activa de Reclutamiento:',
        instructionsTitle: '💡 Recomendaciones para Postulantes:',
        instructions: [
          'Responda con precisión destacando términos en inglés o alemán si lo requiere.',
          'Fundamente cada masa balanceada; los evaluadores estiman rigurosamente los cálculos.'
        ],
        btnEnd: 'Finalizar Evaluación',
        chatHeader: 'Comité de Reclutamiento de Basora:',
        chatUserHeader: 'Su respuesta (Candidato):',
        chatPlaceholder: 'Redacte su respuesta técnica aquí...',
        loading: 'El comité evalúa su aporte y prepara una pregunta personalizada de procesos...'
      },
      bot: {
        title: 'Asistente Digital Científico',
        welcome: '¡Hola! Soy el asistente virtual de la Autoridad Química de Basora. Consúlteme sobre balances, termodinámica o procesos de destilación.',
        instructions: 'Consulte al asistente para explicaciones de procesos industriales complejos',
        placeholder: 'Preguntar: ¿Cuál es el modelo molecular del jabón líquido? ¿Cómo se calcula el calor latente?',
        loading: 'Interrogando bases científicas para su ecuación...'
      },
      detergents: {
        title: 'Simulador de Mezclado de Detergentes y Emulsiones',
        desc: 'Monitoree reacciones de viscosidad y nivele el pH bajo estándares internacionales de seguridad.',
        solTitle: '1. Solvente Transportador Neutro:',
        waterSol: '💧 Agua Desionizada Destilada (1 Litro)',
        acidTitle: '2. Alimentar Reactor con Compuesto Activo:',
        acids: [
          'Ácido Alquilbenceno Sulfónico (LABSA)',
          'Hidróxido de Sodio (NaOH) activo',
          'Texapon Potenciador de Espuma'
        ],
        btnMix: 'Inyectar Compuesto',
        phStatus: 'Nivel de pH Registrado:',
        reactionOk: 'Balance neutralizado. Solución estable, segura para la piel y aprobada.',
        logReady: 'Reactor inerte. Listo para alimentación activa.',
        logNoAcid: 'Seleccione un compuesto activo para inyectar al solvente neutro.',
        logPour: 'Se dosificó el compuesto activo en el reactor de agua.',
        logLabsa: 'pH desciende a 3.2 (ácido). Se requiere inyección de base (NaOH) para reaccionar sulfonato de sodio.',
        logNaohNeutral: '¡Neutralización ácido-base exitosa! pH se estabiliza en ideal 7.2. ¡Reacción completada con éxito!',
        logNaohBase: 'pH asciende a 11.5 (altamente alcalino). Corrosivo y nocivo para el cutis. Corrija con LABSA.',
        logTexapon: 'Texapon inyectado. Viscosidad y nivel espumoso mejorados sustancialmente.'
      },
      uvVis: {
        title: 'Simulador Espectrofotométrico UV-Vis',
        desc: 'Mida coeficientes de absorción de solutos bajo el soporte de la ley de Beer-Lambert.',
        sampleLabel: '1. Cargar Soluto en la Cubeta de Cuarzo:',
        samples: [
          'Sulfato de Cobre (CuSO4)',
          'Dicromato de Potasio (K2Cr2O7)',
          'Indicador de Fenolftaleína'
        ],
        waveLabel: '2. Calibrar Longitud de Onda Incidente (400nm - 800nm):',
        concLabel: '3. Nivel molar del Soluto (Molar Concentration):',
        btnMeasure: 'Transmitir Fotones y Leer Espectro',
        measuring: 'Transmitiendo haz de luz monocromática... Computando constante de absorción (A)...',
        results: 'Parámetros del Espectrofotómetro UV-Vis:',
        absText: 'Absorción Medida (A):',
        beerLawTitle: '📌 Ley de Beer-Lambert Verificada:',
        beerLawText: 'Lectura estable. El coeficiente obtenido valida la concentración de la celda de cuarzo. Óptimo para modelado ambiental.',
        noAbs: 'Célula vacía o equipo inactivo. Cargue soluto y clique en calentar láser para observar absorbencia.'
      },
      hplc: {
        title: 'Laboratorio Simulador HPLC',
        desc: 'Un simulador interactivo de ingeniería química para comprender los Procedimientos Operativos Estándar (SOP), la programación de bombas y el análisis de cromatogramas de un Cromatógrafo Líquido de Alta Resolución (HPLC) - basado en el contenido científico del curso de Eng. Ali Saif Aldin Haider.'
      }
    },
    courses: {
      title: 'Capacitaciones y Talleres de Especialización',
      desc: 'Módulos diseñados por comités de planta para capacitar ingenieros jóvenes en Basora.',
      search: 'Buscar talleres de capacitación...',
      newCourseBtn: 'Publicar Curso',
      instructor: 'Docente:',
      dateAdded: 'Fecha de publicación:',
      accessBtn: 'Consultar Carpeta Académica',
      noCourses: 'No se encontraron materias que correspondan a su búsqueda.',
      addModal: {
        title: 'Publicar Nuevo Material Académico',
        nameLabel: 'Título de la Materia:',
        namePlaceholder: 'Ej. Tratamientos de lodos activos y fluidificación',
        urlLabel: 'Enlace de descarga de carpeta:',
        urlPlaceholder: 'Syllabus, carpeta en Google Drive o YouTube',
        instructorLabel: 'Profesional a cargo:',
        instructorPlaceholder: 'Deje vacío para representación de la junta',
        descLabel: 'Resumen o programa detallado:',
        descPlaceholder: 'Garantice metas de aprendizaje y conceptos del módulo...',
        confirmBtn: 'Confirmar y Desplegar',
        cancelBtn: 'Cancelar',
        errorFill: 'Título y Enlace de descarga obligatorio.'
      }
    },
    resources: {
      title: 'Literatura Científica y Manuales (+400MB)',
      desc: 'Acceda a copias digitales de manuales clásicos resueltos para el diseño de reactores.',
      categories: ['All', 'Core Textbooks', 'Reactor & Plant Design', 'Oil & Gas Refining', 'Environmental & Water', 'Research Papers'],
      search: 'Buscar referencias u obras por título o autor (ej. Perry)...',
      newResourceBtn: 'Añadir literatura',
      fileSize: 'Tamaño del Archivo:',
      dateAdded: 'Fecha de publicación:',
      downloadBtn: 'Descargar Documento PDF',
      noResources: 'No se encontraron referencias científicas.',
      addModal: {
        title: 'Añadir Material Científico o Manual en PDF',
        uploading: 'Transfiriendo archivo pesado al servidor...',
        uploadingDesc: 'Espere por favor. Documentos masivos mayores a 400MB se segmentan en bloques paralelos para evitar desconexiones en Basora.',
        speed: 'Tasa de transferencia:',
        approximate: 'Estado de transferencia:',
        nameLabel: 'Título de la obra referenciada:',
        namePlaceholder: 'Ej. Perry Manual del Ingeniero Químico - 9na Ed.',
        catLabel: 'Categoría académica:',
        sizeLabel: 'Tamaño estimado de archivo (Megabytes):',
        browseLabel: 'Verificar PDF local',
        browseSub: 'Sin límites estrictos: Los administradores pueden subir archivos de cualquier tamaño (más de 400MB)',
        driveLabel: 'Enlace alternativo directo (Recomendado para rapidez):',
        drivePlaceholder: 'Google Drive, Dropbox o OneDrive enlace público',
        descLabel: 'Resumen e índice bibliográfico:',
        descPlaceholder: 'Detalle capítulos de Reactores, Balances de Masa o Ingeniería de Gas...',
        safetyText: 'Estructurado con segmentador paralelo automático para archivos pesados (400MB+) salvaguardando la sesión.',
        submitBtn: 'Aceptar y Publicar',
        cancelBtn: 'Cancelar',
        errorFill: 'Título de obra, nombre de archivo y estimado de peso obligatorio.'
      }
    },
    accounts: {
      title: 'Canales de Comunicación de la Autoridad',
      desc: 'Manténgase en contacto con representantes de la junta química en Basora.',
      editBtn: 'Modificar Canales',
      modalTitle: 'Consola de Administración de Redes del Portal',
      modalSub: 'Edite enlaces de destino para el panel de estudiantes fácilmente.',
      telegram: 'Enlace Telegram Oficial:',
      facebook: 'Página de Facebook:',
      whatsapp: 'Contacto Directo WhatsApp (Número):',
      youtube: 'Plataforma YouTube de Videos:',
      linkedin: 'Linkedin Profesional:',
      website: 'Sitio Web Principal (Dominio):',
      saveBtn: 'Guardar cambios',
      saving: 'Guardando datos...',
      cancelBtn: 'Cancelar',
      channelLabel: 'Abrir canal oficial &larr;',
      channels: [
        { name: 'Canal Telegram Oficial', desc: 'Alertas inmediatas, entrega de problemas resueltos y anuncios académicos.' },
        { name: 'Página Facebook', desc: 'Galería de eventos y seminarios dictados por directores de planta.' },
        { name: 'Academia YouTube', desc: 'Repositorio de lecciones filmadas y guías de calibración espectrofotométrica.' },
        { name: 'LinkedIn Profesional', desc: 'Vínculos corporativos para becas y empleos en refinerías.' },
        { name: 'Dominio Web Principal', desc: 'Validación legal de firmas académicas y certificaciones oficiales.' }
      ]
    },
    about: {
      introTitle: 'Carta Orgánica y Objetivos Estratégicos',
      title: 'Asociación de Ingenieros de Basora',
      p1: 'La Autoridad de Ingenieros en Basora representa el núcleo de veracidad científica e industrial para graduados en petróleo, gas y automatización química.',
      p2: 'Conectamos la academia teórica con los procesos de campo gracias a laboratorios interactivos y becas firmadas con consorcios petroleros.',
      cards: [
        { title: 'Visión de Planta', desc: 'Enseñar herramientas avanzadas de modelado según parámetros mundiales de calidad y seguridad.' },
        { title: 'Misión del Conocimiento', desc: 'Garantizar el acceso gratuito a manuales clásicos pesados (como Perry de 400MB) para incentivar la investigación.' },
        { title: 'Alianzas Estratégicas', desc: 'Coordinar cursos prácticos en refinerías, plantas desalinizadoras y complejos petroquímicos.' }
      ],
      devBadge: 'Arquitecto de Soluciones de Aprendizaje y Sistemas',
      devName: 'ENG.ALI SAIF ALDIN HAIDER -AlNAWFAL @2026 LIMITED',
      devTitle: 'Full-Stack Software Analyst & AI Architect',
      devDesc: 'Esta plataforma fue diseñada de forma altruista para capacitar a los jóvenes químicos del Irak. Incorpora segmentación paralela para descarga de manuales pesados de Perry superiores a 400MB e integra Gemini 3.5 para evaluaciones laborales simuladas y filtrado avanzado.',
      devContact: 'Soluciones de capacitación inteligente para el Irak',
      devStudio: 'ARABIC DEV STUDIO'
    },
    admin: {
      title: 'Centro de Operaciones y Estadísticas',
      desc: 'Analice tiempos reales de aprendizaje, interactividad estudiantil y configure módulos en el portal.',
      tabs: {
        tracking: 'Analíticas de Participación',
        platforms: 'Configuración de Módulos'
      },
      searchUser: 'Filtrar miembros por nombre o correo electrónico...',
      usersTitle: 'Registro de Miembros y Estudiantes Activos:',
      loading: 'Compilando registros interactivos remotos y bases de auditoría...',
      table: {
        name: 'Miembro',
        email: 'Dirección de Correo',
        role: 'Clasificación',
        clicks: 'Interacciones',
        duration: 'Tiempo de Estudio',
        btnDetail: 'Ver Perfil y Actividades'
      },
      inspectTitle: 'Boleta Analítica de Participación Estudiantil:',
      inspectSub: 'Seleccione "Ver Perfil" de cualquier miembro en la izquierda para observar su bitácora detallada de clics y tiempos.',
      individual: {
        registered: 'Creado el:',
        clicksSum: 'Interacciones en Plataforma',
        timeSum: 'Tiempo de Capacitación Total',
        staysTitle: 'Tiempo dedicado a Laboratorios Virtuales',
        clicksCount: 'Veces abiertas:',
        noStays: 'Este miembro aún no ha ejecutado simulaciones en los laboratorios.',
        timelineTitle: 'Bitácora Histórica de Pasos e Inicios',
        noTimeline: 'Sin registros de pasos reportados.'
      },
      managePlat: {
        addTitle: 'Añadir Módulo de Simulación Interactiva',
        editTitle: 'Calibrar Parámetros de Plataforma Activa',
        formDesc: 'Despliegue simuladores en el tablero principal completando el nombre, un screenshot de portada y la ruta de acceso.',
        platName: 'Nombre Científico del Simulador:',
        platUrl: 'Enlace / Endpoint (use "embedded" para el resumidor/bot):',
        platImg: 'URL del Screenshot representativo (o deje vacío):',
        platDesc: 'Indicaciones y objetivo del módulo:',
        btnSubmitAdd: 'Añadir Módulo',
        btnSubmitEdit: 'Confirmar Calibración',
        btnCancel: 'Cancelar',
        listTitle: 'Módulos Desplegados en el Tablero Estudiantil',
        editTooltip: 'Calibrar portada',
        deleteTooltip: 'Retirar módulo de base de datos'
      }
    }
  }
};
